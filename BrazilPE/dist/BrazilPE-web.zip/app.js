import { attachGeometry } from './geometry.js';
import { attachMovement } from './movement.js';
const input = document.querySelector('#dimension');
const radiusLabel = document.querySelector('#radius');
const status = document.querySelector('#status');
const canvas = document.querySelector('#scene');

try {
  const response = await fetch('core.wasm');
  if (!response.ok) throw new Error(`Falha ao carregar módulo: HTTP ${response.status}`);
  const { instance } = await WebAssembly.instantiate(await response.arrayBuffer(), {});
  const api = instance.exports;
  if (typeof api.brazilpe_shadow_radius !== 'function' ||
      api.brazilpe_player_type() !== 319 ||
      api.brazilpe_original_pick_margin() !== Math.fround(0.1)) {
    throw new Error('Módulo inesperado ou inválido.');
  }
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas indisponível.');
  function draw() {
    const value = Number(input.value);
    if (!Number.isFinite(value) || value < 0 || value > 4) return;
    const radius = api.brazilpe_shadow_radius(value);
    document.querySelector('#input-value').textContent = value.toFixed(2).replace('.', ',');
    radiusLabel.textContent = radius.toFixed(3).replace('.', ',');
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.strokeStyle = '#2d4652';
    for (let x = 0; x <= 640; x += 40) {
      context.beginPath(); context.moveTo(x, 0); context.lineTo(x, 320); context.stroke();
    }
    for (let y = 0; y <= 320; y += 40) {
      context.beginPath(); context.moveTo(0, y); context.lineTo(640, y); context.stroke();
    }
    if (radius > 0) {
      context.fillStyle = '#080e1680';
      context.beginPath(); context.ellipse(320, 240, radius * 90, radius * 28, 0, 0, Math.PI * 2); context.fill();
    }
    context.fillStyle = '#83e4b0';
    context.fillRect(320 - value * 35, 180 - value * 20, value * 70, value * 40);
  }
  input.disabled = false;
  input.addEventListener('input', draw);
  draw();
  attachGeometry(api);
  attachMovement(api);
  status.textContent = 'Módulo WebAssembly carregado.';
} catch (error) {
  input.disabled = true;
  document.querySelector('#position').disabled = true;
  document.querySelector('#movement').disabled = true;
  for (const selector of ['#step-horizontal', '#step-vertical', '#step-bypass']) {
    document.querySelector(selector).disabled = true;
  }
  status.textContent = error instanceof Error ? error.message : 'Falha ao iniciar demonstração.';
}
