export function attachPressureRuntime(api) {
  const names = ['mode', 'variant', 'type', 'x'];
  const inputs = names.map(name => document.querySelector(`#sensor-${name}`));
  const output = document.querySelector('#sensor-result'), trace = document.querySelector('#sensor-trace');
  let metadata = 0, tick = 0;
  api.brazilpe_scheduler_reset(0, 0);
  function deadline() {
    if (api.brazilpe_scheduler_count() === 0) return 'nenhuma';
    return new DataView(api.memory.buffer).getBigUint64(api.brazilpe_scheduler_buffer() + 16, true).toString();
  }
  function detect() {
    const [mode, variant, type, offset] = inputs.map(input => Number(input.value));
    new Int32Array(api.memory.buffer, api.brazilpe_pressure_position(), 3).set([5, 2, -3]);
    const x = 5 + offset;
    new Float32Array(api.memory.buffer, api.brazilpe_pressure_candidates(), 6).set([x - 0.125, 2, -2.625, x + 0.125, 3.8, -2.375]);
    new Int32Array(api.memory.buffer, api.brazilpe_pressure_types(), 1)[0] = type;
    const signal = api.brazilpe_pressure_detect(mode, variant, 1, 15);
    if (signal < 0) throw new Error('Entrada sensora inválida.');
    return { mode, signal };
  }
  function draw() {
    const { signal } = detect();
    output.textContent = `Sinal detectado: ${signal} · Metadado: ${metadata} · Tick: ${tick} · Próxima avaliação: ${deadline()}`;
  }
  function evaluate() {
    const { mode, signal } = detect();
    if (api.brazilpe_pressure_tick(mode, metadata, signal, 0) !== 1) throw new Error('Atualização inválida.');
    const events = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_pressure_events(), 8));
    metadata = events[5];
    if (events[7]) {
      const id = mode ? 147 : 70;
      if (api.brazilpe_scheduler_add(5, 2, -3, id, events[7], 1, id) !== 1) throw new Error('Fila de ticks cheia ou inválida.');
    }
    const labels = ['','atualizar componente','escrever metadado','solicitar som','agendar avaliação'];
    trace.textContent = events.slice(1, 1 + events[0]).map(kind => labels[kind]).join(' → ');
    draw();
  }
  inputs.forEach(input => { input.disabled = false; input.addEventListener('input', draw); });
  inputs[0].addEventListener('change', () => { metadata = 0; tick = 0; api.brazilpe_scheduler_reset(0, 0); trace.textContent = 'Estado reiniciado ao mudar o tipo.'; draw(); });
  for (const name of ['evaluate', 'advance', 'reset']) document.querySelector(`#sensor-${name}`).disabled = false;
  document.querySelector('#sensor-evaluate').addEventListener('click', evaluate);
  document.querySelector('#sensor-advance').addEventListener('click', () => {
    tick++;
    const id = Number(inputs[0].value) ? 147 : 70;
    const result = api.brazilpe_scheduler_process(tick, 0, 128, 1, id);
    if (result < 0) throw new Error('Passo do agendador inválido.');
    const due = api.brazilpe_scheduler_dispatch_count();
    for (let i = 0; i < due; i++) evaluate();
    if (due === 0) draw();
  });
  document.querySelector('#sensor-reset').addEventListener('click', () => {
    metadata = 0; tick = 0; api.brazilpe_scheduler_reset(0, 0); trace.textContent = 'Estado reiniciado.'; draw();
  });
  draw();
}
