export function attachPressureRuntime(api) {
  const names = ['mode', 'variant', 'type', 'x'];
  const inputs = names.map(name => document.querySelector(`#sensor-${name}`));
  const output = document.querySelector('#sensor-result'), trace = document.querySelector('#sensor-trace');
  let metadata = 0, tick = 0, deadline = null;
  function detect() {
    const [mode, variant, type, offset] = inputs.map(input => Number(input.value));
    new Int32Array(api.memory.buffer, api.brazilpe_pressure_position(), 3).set([5, 2, -3]);
    const x = 5 + offset;
    new Float32Array(api.memory.buffer, api.brazilpe_pressure_candidates(), 6).set([x - 0.125, 2, -2.625, x + 0.125, 3.8, -2.375]);
    new Int32Array(api.memory.buffer, api.brazilpe_pressure_types(), 1)[0] = type;
    const signal = api.brazilpe_pressure_detect(mode, variant, 1, 15);
    if (signal < 0) throw new Error('Entrada sensora inválida.');
    return { mode, signal };
  }
  function draw() {
    const { signal } = detect();
    output.textContent = `Sinal detectado: ${signal} · Metadado: ${metadata} · Tick: ${tick} · Próxima avaliação: ${deadline ?? 'nenhuma'}`;
  }
  function evaluate() {
    const { mode, signal } = detect();
    if (api.brazilpe_pressure_tick(mode, metadata, signal, 0) !== 1) throw new Error('Atualização inválida.');
    const events = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_pressure_events(), 8));
    metadata = events[5];
    deadline = events[7] ? tick + events[7] : null;
    const labels = ['','atualizar componente','escrever metadado','solicitar som','agendar avaliação'];
    trace.textContent = events.slice(1, 1 + events[0]).map(kind => labels[kind]).join(' → ');
    draw();
  }
  inputs.forEach(input => { input.disabled = false; input.addEventListener('input', draw); });
  inputs[0].addEventListener('change', () => { metadata = 0; tick = 0; deadline = null; trace.textContent = 'Estado reiniciado ao mudar o tipo.'; draw(); });
  for (const name of ['evaluate', 'advance', 'reset']) document.querySelector(`#sensor-${name}`).disabled = false;
  document.querySelector('#sensor-evaluate').addEventListener('click', evaluate);
  document.querySelector('#sensor-advance').addEventListener('click', () => {
    // Laboratory queue advances exactly one tick; native scheduler internals are not used.
    tick++; if (deadline !== null && tick >= deadline) evaluate(); else draw();
  });
  document.querySelector('#sensor-reset').addEventListener('click', () => {
    metadata = 0; tick = 0; deadline = null; trace.textContent = 'Estado reiniciado.'; draw();
  });
  draw();
}
