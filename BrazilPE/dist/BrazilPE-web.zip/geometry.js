export function scenario(api, x, desired) {
  if (![x, desired].every(value => Number.isFinite(value) && Number.isFinite(Math.fround(value)))) {
    throw new Error('Entrada geométrica inválida.');
  }
  const offset = api.brazilpe_geometry_buffer();
  if (!Number.isInteger(offset) || offset < 0 || offset % 4 !== 0 || offset + 128 > api.memory.buffer.byteLength) {
    throw new Error('Memória geométrica inválida.');
  }
  const memory = new Float32Array(api.memory.buffer, offset, 32);
  const obstacle = [0, 0, 0, 1, 1, 1];
  const moving = [x, 0.2, 0.2, x + 0.6, 0.8, 0.8];
  memory.set(obstacle, 0);
  memory.set(moving, 8);
  memory.set([x + 0.3, 0.5, 0.5], 16);
  const overlap = api.brazilpe_aabb_intersects() === 1;
  const centerInside = api.brazilpe_aabb_contains() === 1;
  const allowed = api.brazilpe_clip_x(desired, 0);
  memory.set(moving, 0);
  memory.set([allowed, 0, 0], 16);
  api.brazilpe_aabb_translate();
  const translated = Array.from(memory.slice(24, 30));
  return { obstacle, moving, translated, overlap, centerInside, allowed };
}

export function attachGeometry(api) {
  const position = document.querySelector('#position');
  const delta = document.querySelector('#movement');
  const canvas = document.querySelector('#geometry-scene');
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas geométrico indisponível.');
  function draw() {
    const x = Number(position.value), desired = Number(delta.value);
    if (x < -2 || x > 2 || desired < -2 || desired > 2) return;
    const result = scenario(api, x, desired);
    document.querySelector('#position-value').textContent = x.toFixed(2);
    document.querySelector('#movement-value').textContent = desired.toFixed(2);
    document.querySelector('#allowed').textContent = result.allowed.toFixed(3);
    document.querySelector('#overlap').textContent = result.overlap ? 'Sim' : 'Não';
    document.querySelector('#contained').textContent = result.centerInside ? 'Sim' : 'Não';
    context.clearRect(0, 0, canvas.width, canvas.height);
    const pixel = worldX => 280 + worldX * 90;
    context.strokeStyle = '#2d4652';
    for (let grid = -3; grid <= 4; grid++) {
      context.beginPath(); context.moveTo(pixel(grid), 0); context.lineTo(pixel(grid), 240); context.stroke();
    }
    function box(bounds, color, filled) {
      context.fillStyle = color; context.strokeStyle = color; context.lineWidth = 3;
      const left = pixel(bounds[0]), width = (bounds[3] - bounds[0]) * 90;
      if (filled) context.fillRect(left, 70, width, 80);
      else context.strokeRect(left, 70, width, 80);
    }
    box(result.obstacle, '#83e4b080', true);
    box(result.moving, '#83b5ff', false);
    box(result.translated, '#f1ba64', false);
    context.fillStyle = '#e6f0e9'; context.font = '14px system-ui';
    context.fillText('Verde: obstáculo · Azul: início · Amarelo: resultado', 24, 210);
  }
  position.disabled = false; delta.disabled = false;
  position.addEventListener('input', draw); delta.addEventListener('input', draw);
  draw();
}
