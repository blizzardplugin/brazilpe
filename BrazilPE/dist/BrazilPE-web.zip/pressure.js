export function attachPressure(api) {
  const controls = ['weighted', 'count', 'capacity', 'metadata'].map(name => document.querySelector(`#pressure-${name}`));
  const output = document.querySelector('#pressure-result');
  function draw() {
    const values = controls.map(input => Number(input.value));
    if (controls.some(input => input.value === '') || !values.every(Number.isInteger)) {
      output.textContent = 'Preencha valores inteiros.'; return;
    }
    const [mode, count, capacity, metadata] = values;
    const signal = api.brazilpe_pressure_signal(mode, count, capacity);
    const decoded = api.brazilpe_pressure_decode(mode, metadata);
    if (signal < 0 || decoded < 0) { output.textContent = 'Valores fora do intervalo do laboratório.'; return; }
    output.textContent = `Sinal: ${signal} · Metadado calculado: ${api.brazilpe_pressure_encode(mode, signal)} · Sinal do metadado informado: ${decoded} · Intervalo retornado: ${api.brazilpe_pressure_delay(mode)} ticks`;
  }
  for (const input of controls) { input.disabled = false; input.addEventListener('input', draw); }
  draw();
}
