export async function attachShapes(api) {
  const select = document.querySelector('#shape-profile'), metadata = document.querySelector('#shape-metadata');
  const canvas = document.querySelector('#shape-scene'), context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas de formas indisponível.');
  const source = document.querySelector('#shape-source');
  const response = await fetch('registry-profiles.json');
  if (!response.ok) throw new Error('Catálogo de formas indisponível.');
  const registry = await response.json();
  if (!Array.isArray(registry.bindings) || registry.bindings.length !== 8) throw new Error('Catálogo de formas inválido.');
  const bindings = new Map();
  for (const binding of registry.bindings) {
    if (!Number.isInteger(binding.id) || binding.id < 0 || binding.id > 255 || bindings.has(binding.id) ||
        typeof binding.name !== 'string' || !/^[a-z0-9_]+$/.test(binding.name) || ![1, 2].includes(binding.shape_profile)) {
      throw new Error('Associação de forma inválida.');
    }
    bindings.set(binding.id, binding);
    const option = document.createElement('option'); option.value = String(binding.id); option.textContent = `${binding.id} · ${binding.name}`;
    source.append(option);
  }
  function draw() {
    const profile = Number(select.value), value = Number(metadata.value);
    if (!Number.isInteger(profile) || !Number.isInteger(value) || value < 0 || value > 15) return;
    const result = source.value === '' ? api.brazilpe_block_shape(profile, value) : api.brazilpe_registered_shape(Number(source.value), value);
    if (result !== 1) throw new Error('Perfil de forma inválido.');
    const bounds = Array.from(new Float32Array(api.memory.buffer, api.brazilpe_shape_buffer(), 6));
    document.querySelector('#shape-height').textContent = (bounds[4] - bounds[1]).toFixed(5);
    document.querySelector('#shape-footprint').textContent = `${(bounds[3] - bounds[0]).toFixed(4)} × ${(bounds[5] - bounds[2]).toFixed(4)}`;
    context.clearRect(0, 0, canvas.width, canvas.height);
    const project = (x, y, z) => [170 + x * 180 + z * 90, 245 - y * 175 - z * 55];
    function face(vertices, color) {
      context.beginPath(); vertices.forEach((point, index) => { const pixel = project(...point); if (index) context.lineTo(...pixel); else context.moveTo(...pixel); });
      context.closePath(); context.fillStyle = color; context.fill(); context.strokeStyle = '#d7f7e5'; context.stroke();
    }
    const [x0, y0, z0, x1, y1, z1] = bounds;
    face([[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0]], '#477c67');
    face([[x1,y0,z0],[x1,y0,z1],[x1,y1,z1],[x1,y1,z0]], '#356654');
    face([[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]], '#83e4b0');
  }
  select.disabled = false; metadata.disabled = false;
  source.disabled = false;
  select.addEventListener('change', () => { source.value = ''; draw(); });
  source.addEventListener('change', () => {
    if (source.value !== '') select.value = String(bindings.get(Number(source.value)).shape_profile);
    document.querySelector('#shape-binding-note').textContent = source.value === '' ? 'Perfil isolado.' : 'Nome e ID observados no inicializador; getter ligado pelo construtor e tabela virtual.';
    draw();
  });
  metadata.addEventListener('input', draw); draw();
}
