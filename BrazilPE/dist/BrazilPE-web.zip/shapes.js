export function attachShapes(api) {
  const select = document.querySelector('#shape-profile'), metadata = document.querySelector('#shape-metadata');
  const canvas = document.querySelector('#shape-scene'), context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas de formas indisponível.');
  function draw() {
    const profile = Number(select.value), value = Number(metadata.value);
    if (!Number.isInteger(profile) || !Number.isInteger(value) || value < 0 || value > 15) return;
    if (api.brazilpe_block_shape(profile, value) !== 1) throw new Error('Perfil de forma inválido.');
    const bounds = Array.from(new Float32Array(api.memory.buffer, api.brazilpe_shape_buffer(), 6));
    document.querySelector('#shape-height').textContent = (bounds[4] - bounds[1]).toFixed(5);
    document.querySelector('#shape-footprint').textContent = `${(bounds[3] - bounds[0]).toFixed(4)} × ${(bounds[5] - bounds[2]).toFixed(4)}`;
    context.clearRect(0, 0, canvas.width, canvas.height);
    const project = (x, y, z) => [170 + x * 180 + z * 90, 245 - y * 175 - z * 55];
    function face(vertices, color) {
      context.beginPath(); vertices.forEach((point, index) => { const pixel = project(...point); if (index) context.lineTo(...pixel); else context.moveTo(...pixel); });
      context.closePath(); context.fillStyle = color; context.fill(); context.strokeStyle = '#d7f7e5'; context.stroke();
    }
    const [x0, y0, z0, x1, y1, z1] = bounds;
    face([[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0]], '#477c67');
    face([[x1,y0,z0],[x1,y0,z1],[x1,y1,z1],[x1,y1,z0]], '#356654');
    face([[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]], '#83e4b0');
  }
  select.disabled = false; metadata.disabled = false;
  select.addEventListener('change', draw); metadata.addEventListener('input', draw); draw();
}
