const status = document.querySelector('#catalog-status'), output = document.querySelector('#catalog-records');
try {
  const response = await fetch('catalog.json'); if (!response.ok) throw new Error('Catálogo indisponível.');
  const catalog = await response.json();
  if (!Array.isArray(catalog.blocks) || catalog.blocks.length !== 256 || !Array.isArray(catalog.items) || !Array.isArray(catalog.models)) throw new Error('Catálogo inválido.');
  status.textContent = `${catalog.blocks.length} declarações de blocos (${catalog.blocks.filter(item => !item.placeholder).length} com nome) · ${catalog.items.length} declarações de itens no recurso · ${catalog.models.length} modelos inventariados`;
  const search = document.querySelector('#catalog-search'), kind = document.querySelector('#catalog-kind');
  function draw() {
    const term = search.value.trim().toLowerCase();
    const records = catalog[kind.value].filter(record => `${record.name} ${record.id ?? record.resource_id ?? ''}`.toLowerCase().includes(term));
    output.replaceChildren();
    for (const record of records) {
      const details = document.createElement('details'), summary = document.createElement('summary'), body = document.createElement('pre');
      summary.textContent = `${record.id ?? record.resource_id ?? ''} · ${record.name || '(placeholder sem nome)'}`;
      body.textContent = JSON.stringify(record, null, 2); details.append(summary, body); output.append(details);
    }
    document.querySelector('#catalog-count').textContent = `${records.length} resultados`;
  }
  search.disabled = false; kind.disabled = false;
  search.addEventListener('input', draw); kind.addEventListener('change', draw); draw();
} catch (error) { status.textContent = error.message; }
