import { CONFIG } from './config.js';
export class Controls {
  constructor(canvas, player, action) {
    this.player = player; this.state = { forward: false, backward: false, left: false, right: false, jump: false };
    this.keys = new Set(); this.touches = new Map(); this.active = true;
    const direction = new Map([['KeyW', 'forward'], ['ArrowUp', 'forward'], ['KeyS', 'backward'], ['ArrowDown', 'backward'],
      ['KeyA', 'left'], ['ArrowLeft', 'left'], ['KeyD', 'right'], ['ArrowRight', 'right']]);
    this.update = () => {
      for (const name of ['forward', 'backward', 'left', 'right']) this.state[name] =
        Array.from(this.keys).some(key => direction.get(key) === name) || Array.from(this.touches.values()).includes(name);
    };
    document.addEventListener('keydown', event => {
      if (['INPUT', 'SELECT', 'BUTTON'].includes(event.target.tagName) || !this.active) return;
      if (direction.has(event.code)) { event.preventDefault(); this.keys.add(event.code); this.update(); }
      if (event.code === 'Space' && !event.repeat) { event.preventDefault(); this.state.jump = true; }
    });
    document.addEventListener('keyup', event => { this.keys.delete(event.code); this.update(); });
    const clear = () => { this.keys.clear(); this.touches.clear(); this.update(); this.state.jump = false; };
    window.addEventListener('blur', clear); document.addEventListener('visibilitychange', () => { if (document.hidden) clear(); });
    for (const button of document.querySelectorAll('[data-move]')) {
      button.addEventListener('pointerdown', event => {
        event.preventDefault(); button.setPointerCapture(event.pointerId);
        if (button.dataset.move === 'jump') this.state.jump = true;
        else this.touches.set(event.pointerId, button.dataset.move);
        this.update();
      });
      for (const kind of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(kind, event => { this.touches.delete(event.pointerId); this.update(); });
    }
    canvas.addEventListener('contextmenu', event => event.preventDefault());
    let cameraPointer = null;
    canvas.addEventListener('pointerdown', event => {
      if (event.pointerType === 'touch') { cameraPointer = { id: event.pointerId, x: event.clientX, y: event.clientY }; canvas.setPointerCapture(event.pointerId); return; }
      if (document.pointerLockElement !== canvas) {
        try { const result = canvas.requestPointerLock?.(); result?.catch?.(() => {}); } catch { /* Drag controls still work. */ }
        cameraPointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
        return;
      }
      action(event.button === 2 ? 'place' : 'break');
    });
    document.addEventListener('pointermove', event => {
      if (!this.active) return;
      if (document.pointerLockElement === canvas) this.look(event.movementX, event.movementY, CONFIG.sensitivity);
      else if (cameraPointer?.id === event.pointerId) {
        this.look(event.clientX - cameraPointer.x, event.clientY - cameraPointer.y,
          event.pointerType === 'touch' ? CONFIG.touchSensitivity : CONFIG.sensitivity);
        cameraPointer.x = event.clientX; cameraPointer.y = event.clientY;
      }
    });
    for (const kind of ['pointerup', 'pointercancel']) canvas.addEventListener(kind, () => { cameraPointer = null; });
  }
  look(dx, dy, sensitivity) {
    this.player.yaw = ((this.player.yaw + dx * sensitivity + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
    this.player.pitch = Math.max(-1.5, Math.min(1.5, this.player.pitch - dy * sensitivity));
  }
}
