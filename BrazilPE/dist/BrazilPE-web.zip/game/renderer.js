import { CONFIG, BLOCKS, solid, isPlate, localBounds } from './config.js';
import { cameraDirection } from './physics.js';

const FACES = [
  { normal: [1, 0, 0], corners: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], shade: 0.8 },
  { normal: [-1, 0, 0], corners: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]], shade: 0.7 },
  { normal: [0, 1, 0], corners: [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]], shade: 1 },
  { normal: [0, -1, 0], corners: [[0, 0, 1], [0, 0, 0], [1, 0, 0], [1, 0, 1]], shade: 0.55 },
  { normal: [0, 0, 1], corners: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]], shade: 0.85 },
  { normal: [0, 0, -1], corners: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]], shade: 0.75 },
];
export function chunkMesh(world, chunk) {
  const result = [];
  for (let y = 0; y < CONFIG.chunkHeight; y++) {
    for (let localZ = 0; localZ < CONFIG.chunkSize; localZ++) {
      for (let localX = 0; localX < CONFIG.chunkSize; localX++) {
        const x = chunk.cx * CONFIG.chunkSize + localX, z = chunk.cz * CONFIG.chunkSize + localZ;
        const block = world.get(x, y, z); if (!block) continue;
        const bounds = localBounds(block, world.getMetadata(x, y, z));
        const signal = world.signalAt(x, y, z);
        for (const face of FACES) {
          if (!isPlate(block) && solid(world.get(x + face.normal[0], y + face.normal[1], z + face.normal[2]))) continue;
          for (const index of [0, 1, 2, 0, 2, 3]) {
            const corner = face.corners[index];
            result.push(...[x, y, z].map((value, axis) => value + bounds[axis] + corner[axis] * (bounds[axis + 3] - bounds[axis])),
              ...BLOCKS[block].color.map(value => Math.min(1, value * face.shade + signal / 15 * 0.12)));
          }
        }
      }
    }
  }
  return new Float32Array(result);
}
function dot(a, b) { return a.reduce((sum, value, index) => sum + value * b[index], 0); }
function multiply(a, b) {
  const out = new Float32Array(16);
  for (let col = 0; col < 4; col++) for (let row = 0; row < 4; row++) {
    for (let k = 0; k < 4; k++) out[col * 4 + row] += a[k * 4 + row] * b[col * 4 + k];
  }
  return out;
}
function cameraMatrix(player, aspect) {
  const f = cameraDirection(player), side = [Math.cos(player.yaw), 0, Math.sin(player.yaw)];
  const up = [side[1] * f[2] - side[2] * f[1], side[2] * f[0] - side[0] * f[2], side[0] * f[1] - side[1] * f[0]];
  const eye = [player.position[0], player.position[1] + CONFIG.eyeHeight, player.position[2]];
  const view = new Float32Array([side[0], up[0], -f[0], 0, side[1], up[1], -f[1], 0,
    side[2], up[2], -f[2], 0, -dot(side, eye), -dot(up, eye), dot(f, eye), 1]);
  const scale = 1 / Math.tan(CONFIG.fov / 2), range = CONFIG.near - CONFIG.far;
  const projection = new Float32Array([scale / aspect, 0, 0, 0, 0, scale, 0, 0,
    0, 0, (CONFIG.far + CONFIG.near) / range, -1, 0, 0, 2 * CONFIG.far * CONFIG.near / range, 0]);
  return multiply(projection, view);
}
function shader(gl, kind, source) {
  const item = gl.createShader(kind); if (!item) throw new Error('Não foi possível criar o shader.');
  gl.shaderSource(item, source); gl.compileShader(item);
  if (!gl.getShaderParameter(item, gl.COMPILE_STATUS)) {
    const reason = gl.getShaderInfoLog(item); gl.deleteShader(item); throw new Error(`Falha no shader: ${reason}`);
  }
  return item;
}
export class Renderer {
  constructor(canvas) {
    const gl = canvas.getContext('webgl', { antialias: true, alpha: false });
    if (!gl) throw new Error('WebGL não está disponível neste navegador.');
    this.gl = gl; this.canvas = canvas; this.meshes = new Map(); this.triangles = 0;
    const vertex = shader(gl, gl.VERTEX_SHADER, `attribute vec3 position; attribute vec3 color;
      uniform mat4 camera; varying vec3 tint; varying vec3 worldPosition;
      void main(){ gl_Position=camera*vec4(position,1.0); tint=color; worldPosition=position; }`);
    const fragment = shader(gl, gl.FRAGMENT_SHADER, `precision mediump float; varying vec3 tint; varying vec3 worldPosition;
      void main(){ vec3 edge=min(fract(worldPosition),1.0-fract(worldPosition));
        float second=max(min(edge.x,edge.y),min(max(edge.x,edge.y),edge.z));
        float grid=mix(0.76,1.0,step(0.018,second)); gl_FragColor=vec4(tint*grid,1.0); }`);
    this.program = gl.createProgram();
    if (!this.program) throw new Error('Não foi possível criar o programa gráfico.');
    gl.attachShader(this.program, vertex); gl.attachShader(this.program, fragment); gl.linkProgram(this.program);
    gl.deleteShader(vertex); gl.deleteShader(fragment);
    if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) throw new Error(`Falha no programa gráfico: ${gl.getProgramInfoLog(this.program)}`);
    this.position = gl.getAttribLocation(this.program, 'position'); this.color = gl.getAttribLocation(this.program, 'color');
    this.camera = gl.getUniformLocation(this.program, 'camera'); this.outline = gl.createBuffer();
    if (this.position < 0 || this.color < 0 || !this.camera || !this.outline) throw new Error('Interface gráfica incompleta.');
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.clearColor(0.46, 0.69, 0.79, 1);
  }
  reset() {
    for (const mesh of this.meshes.values()) this.gl.deleteBuffer(mesh.buffer);
    this.meshes.clear();
  }
  bind(buffer) {
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.enableVertexAttribArray(this.position); gl.enableVertexAttribArray(this.color);
    gl.vertexAttribPointer(this.position, 3, gl.FLOAT, false, 24, 0);
    gl.vertexAttribPointer(this.color, 3, gl.FLOAT, false, 24, 12);
  }
  draw(world, player, target) {
    const gl = this.gl, ratio = Math.min(globalThis.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(this.canvas.clientWidth * ratio)), height = Math.max(1, Math.round(this.canvas.clientHeight * ratio));
    if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
    gl.viewport(0, 0, width, height); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(this.program); gl.uniformMatrix4fv(this.camera, false, cameraMatrix(player, width / height));
    for (const key of world.dirty) {
      const data = chunkMesh(world, world.chunks.get(key));
      let mesh = this.meshes.get(key);
      if (!mesh) { mesh = { buffer: gl.createBuffer(), count: 0 }; this.meshes.set(key, mesh); }
      if (!mesh.buffer) throw new Error('Não foi possível reservar memória gráfica.');
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buffer); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); mesh.count = data.length / 6;
    }
    world.dirty.clear(); this.triangles = 0;
    for (const mesh of this.meshes.values()) { this.bind(mesh.buffer); gl.drawArrays(gl.TRIANGLES, 0, mesh.count); this.triangles += mesh.count / 3; }
    if (target) {
      const vertices = [], corners = [];
      const bounds = localBounds(world.get(...target.cell), world.getMetadata(...target.cell));
      for (let i = 0; i < 8; i++) corners.push(target.cell.map((value, axis) => value +
        (((i >> axis) & 1) ? bounds[axis + 3] + 0.002 : bounds[axis] - 0.002)));
      for (let i = 0; i < 8; i++) for (let axis = 0; axis < 3; axis++) {
        const other = i ^ (1 << axis); if (other <= i) continue;
        vertices.push(...corners[i], 1, 1, 1, ...corners[other], 1, 1, 1);
      }
      this.bind(this.outline); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.DYNAMIC_DRAW); gl.drawArrays(gl.LINES, 0, vertices.length / 6);
    }
    const error = gl.getError(); if (error !== gl.NO_ERROR) throw new Error(`Erro WebGL ${error}.`);
  }
}
