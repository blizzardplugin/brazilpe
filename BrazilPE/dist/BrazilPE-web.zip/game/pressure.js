import { CONFIG, BLOCKS, isPlate } from './config.js';

export class PressureSystem {
  constructor(world, createApi) {
    this.world = world; this.createApi = createApi; this.states = new Map(); this.tick = 0; this.accumulator = 0;
    this.events = [];
    this.listener = change => { this.remove(change.position.join(',')); };
    world.listeners.add(this.listener);
    for (const [key, position] of world.plates) this.state(key, position);
  }
  dispose() { this.world.listeners.delete(this.listener); for (const key of [...this.states.keys()]) this.remove(key); }
  remove(key) {
    const state = this.states.get(key);
    if (state) {
      state.api.brazilpe_scheduler_cancel(...state.position, state.id);
      if (state.api.brazilpe_scheduler_count() !== 0) throw new Error('Cancelamento da placa não esvaziou sua fila isolada.');
      this.states.delete(key);
    }
  }
  state(key, position) {
    if (this.states.has(key)) return this.states.get(key);
    const id = BLOCKS[this.world.get(...position)]?.pressureId;
    if (!id) throw new Error('Estado solicitado para bloco sem placa.');
    const api = this.createApi();
    if (api.brazilpe_pressure_profile(id) !== 1) throw new Error('Perfil nativo da placa indisponível.');
    const profile = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_pressure_profile_values(), 4));
    const state = { api, id, position: position.slice(), weighted: profile[0], variant: profile[1], capacity: profile[2], delay: profile[3] };
    api.brazilpe_scheduler_reset(this.tick, 0); this.states.set(key, state);
    const metadata = this.world.getMetadata(...position);
    this.world.signals.set(key, api.brazilpe_pressure_decode(state.weighted, metadata));
    if (metadata && this.world.plateSchedules.has(key)) {
      const remaining = this.world.plateSchedules.get(key);
      if (remaining !== null && api.brazilpe_scheduler_add(...position, id, remaining, 1, id) !== 1) throw new Error('Não foi possível restaurar o tick da placa.');
    }
    return state;
  }
  detect(state, actors) {
    const api = state.api;
    new Int32Array(api.memory.buffer, api.brazilpe_pressure_position(), 3).set(state.position);
    const boxes = new Float32Array(api.memory.buffer, api.brazilpe_pressure_candidates(), CONFIG.maxPressureActors * 6);
    const types = new Int32Array(api.memory.buffer, api.brazilpe_pressure_types(), CONFIG.maxPressureActors);
    actors.forEach((actor, i) => { boxes.set(actor.box, i * 6); types[i] = actor.type; });
    const signal = api.brazilpe_pressure_detect(state.weighted, state.variant, actors.length, state.capacity);
    if (signal < 0) throw new Error('Consulta sensora da placa rejeitada.');
    return signal;
  }
  update(state, signal) {
    const api = state.api, position = state.position, key = position.join(',');
    if (BLOCKS[this.world.get(...position)]?.pressureId !== state.id) return;
    const metadata = this.world.getMetadata(...position);
    if (api.brazilpe_pressure_tick(state.weighted, metadata, signal, 0) !== 1) throw new Error('Atualização da placa rejeitada.');
    const events = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_pressure_events(), 8));
    for (const kind of events.slice(1, events[0] + 1)) {
      if (kind === 1) this.world.signals.set(key, signal);
      if (kind === 2) this.world.setMetadata(...position, events[5]);
      if (kind === 4) {
        const scheduled = api.brazilpe_scheduler_add(...position, state.id, events[7], Number(this.world.pressureRegionAvailable(...position)), state.id);
        if (scheduled < 0) throw new Error('Agendamento da placa rejeitado.');
      }
      this.events.push({ tick: this.tick, position: position.slice(), kind, signal, metadata: events[5], soundPayload: kind === 3 ? events[6] : 0 });
      if (this.events.length > 64) this.events.shift();
    }
  }
  step(actors, dt = CONFIG.fixedStep) {
    if (!Array.isArray(actors) || actors.length > CONFIG.maxPressureActors || !Number.isFinite(dt) || dt <= 0 || dt > CONFIG.maximumFrameDelta ||
        actors.some(actor => !actor || !Number.isInteger(actor.type) || actor.type < 0 || actor.type > 65535 ||
          !Array.isArray(actor.box) || actor.box.length !== 6 || !actor.box.every(v => Number.isFinite(v) && Math.abs(v) <= 1000000) ||
          [0, 1, 2].some(axis => actor.box[axis] > actor.box[axis + 3]))) throw new Error('Entidades ou passo de placas inválidos.');
    for (const [key, position] of this.world.plates) {
      const state = this.state(key, position);
      const signal = this.detect(state, actors), metadata = this.world.getMetadata(...position);
      if (actors.some(actor => state.api.brazilpe_pressure_contact(state.weighted, metadata, signal, actor.type, 0) === 1)) this.update(state, signal);
    }
    this.accumulator += dt;
    while (this.accumulator + 1e-9 >= CONFIG.pressureTickSeconds) {
      if (this.tick >= 0xffffffff) throw new Error('Relógio do adaptador de placas excedeu seu limite.');
      this.accumulator -= CONFIG.pressureTickSeconds; this.tick++;
      for (const state of this.states.values()) {
        const available = Number(this.world.pressureRegionAvailable(...state.position));
        state.api.brazilpe_scheduler_process(this.tick, 0, 128, available, state.id);
        const count = state.api.brazilpe_scheduler_dispatch_count();
        for (let i = 0; i < count; i++) this.update(state, this.detect(state, actors));
      }
    }
    for (const [key, state] of this.states) {
      const count = state.api.brazilpe_scheduler_count();
      const remaining = count ? Number(new DataView(state.api.memory.buffer).getBigUint64(state.api.brazilpe_scheduler_buffer() + 16, true)) - this.tick : null;
      this.world.plateSchedules.set(key, remaining);
    }
  }
}
