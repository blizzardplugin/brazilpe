import { CONFIG, BLOCKS, solid } from './config.js';
import { World, raycast } from './world.js';
import { createPlayer, stepPlayer, playerBox, cameraDirection } from './physics.js';
import { Renderer } from './renderer.js';
import { Controls } from './input.js';
import { saveLocal, loadLocal, encodeSave, decodeSave } from './save.js';
import { PressureSystem } from './pressure.js';

const canvas = document.querySelector('#world'), status = document.querySelector('#game-status');
const choice = document.querySelector('#block-choice');
let world = new World(), player = createPlayer(), renderer, controls, api, module, pressure;
let paused = false, last = 0, accumulated = 0, target = null, frames = 0, steps = 0;
let graphicUnavailable = false, pauseBeforeContextLoss = false;
const testMode = new URLSearchParams(location.search).get('test') === '1';
function message(text) { status.textContent = text; }
function eye() { return [player.position[0], player.position[1] + CONFIG.eyeHeight, player.position[2]]; }
function restore(saved) {
  if (!saved) { message('Nenhum mundo salvo neste navegador.'); return; }
  pressure.dispose(); world = saved.world; player = saved.player; controls.player = player;
  pressure = new PressureSystem(world, () => new WebAssembly.Instance(module, {}).exports);
  renderer.reset(); accumulated = 0; last = 0; message('Mundo carregado.');
}
function edit(kind) {
  if (paused) return;
  target = raycast(world, eye(), cameraDirection(player));
  if (!target) { message('Nenhum bloco ao alcance.'); return; }
  if (kind === 'break') {
    message(world.set(...target.cell, 0) ? 'Bloco removido.' : 'Esse limite do mundo é fixo.');
  } else if (target.previous) {
    const [x, y, z] = target.previous, bounds = playerBox(player);
    if (solid(Number(choice.value)) && [0, 1, 2].every(axis => [x, y, z][axis] + 1 > bounds[axis] && [x, y, z][axis] < bounds[axis + 3])) {
      message('Escolha um espaço fora do personagem.'); return;
    }
    message(world.set(x, y, z, Number(choice.value)) ? 'Bloco colocado.' : 'Não foi possível colocar aqui.');
  }
}
function frame(time) {
  requestAnimationFrame(frame);
  if (!renderer || !controls || graphicUnavailable || renderer.gl.isContextLost()) return;
  const delta = last ? Math.min((time - last) / 1000, CONFIG.maximumFrameDelta) : 0; last = time;
  try {
    if (!paused && !document.hidden) {
      accumulated += delta;
      let count = 0;
      while (accumulated >= CONFIG.fixedStep && count < CONFIG.maximumSteps) {
        stepPlayer(api, world, player, controls.state);
        pressure.step([{ type: api.brazilpe_player_type(), box: playerBox(player) }]);
        accumulated -= CONFIG.fixedStep; count++; steps++;
      }
      if (count === CONFIG.maximumSteps) accumulated = 0;
    } else accumulated = 0;
    target = raycast(world, eye(), cameraDirection(player));
    renderer.draw(world, player, target); frames++;
    document.querySelector('#coordinates').textContent = player.position.map(value => value.toFixed(1)).join(' · ') + (player.ground ? ' · chão' : '');
    const plate = target && BLOCKS[world.get(...target.cell)]?.pressureId ? target.cell :
      [Math.floor(player.position[0]), Math.floor(player.position[1]), Math.floor(player.position[2])];
    const plateId = world.get(...plate);
    document.querySelector('#plate-status').textContent = BLOCKS[plateId]?.pressureId ?
      `${BLOCKS[plateId].name} · sinal ${world.signalAt(...plate)}/15` : 'Placas: coloque sobre um bloco e caminhe por cima.';
  } catch (error) {
    paused = true; controls.active = false; message(`Cena pausada: ${error.message}`);
  }
}
try {
  for (let id = 1; id < BLOCKS.length; id++) {
    const option = document.createElement('option'); option.value = String(id); option.textContent = BLOCKS[id].name; choice.append(option);
  }
  const response = await fetch('core.wasm');
  if (!response.ok) throw new Error(`Módulo indisponível: HTTP ${response.status}`);
  module = await WebAssembly.compile(await response.arrayBuffer());
  api = new WebAssembly.Instance(module, {}).exports;
  if (typeof api.brazilpe_move !== 'function' || typeof api.brazilpe_query_bounds !== 'function') throw new Error('Módulo incompatível.');
  renderer = new Renderer(canvas); controls = new Controls(canvas, player, edit);
  pressure = new PressureSystem(world, () => new WebAssembly.Instance(module, {}).exports);
  for (const id of ['break', 'place']) document.querySelector(`#${id}-block`).addEventListener('click', () => edit(id));
  document.querySelector('#save-world').addEventListener('click', () => {
    try { saveLocal(localStorage, world, player); message('Mundo salvo neste navegador.'); } catch (error) { message(error.message); }
  });
  document.querySelector('#load-world').addEventListener('click', () => {
    try { restore(loadLocal(localStorage)); } catch (error) { message(error.message); }
  });
  document.querySelector('#pause-world').addEventListener('click', event => {
    paused = !paused; controls.active = !paused; event.target.textContent = paused ? 'Continuar' : 'Pausar';
    message(paused ? 'Pausado.' : 'Mundo pronto.'); if (paused) document.exitPointerLock?.();
  });
  document.querySelector('#export-world').addEventListener('click', () => {
    try {
      const blob = new Blob([encodeSave(world, player)], { type: 'application/json' });
      const url = URL.createObjectURL(blob), link = document.createElement('a');
      link.href = url; link.download = 'BrazilPE-world.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      message('Cópia do mundo exportada.');
    } catch (error) { message(error.message); }
  });
  document.querySelector('#import-world').addEventListener('change', async event => {
    const file = event.target.files[0]; if (!file) return;
    try {
      if (file.size > CONFIG.maxSaveBytes) throw new Error('Arquivo de mundo grande demais.');
      restore(decodeSave(await file.text()));
    } catch (error) { message(error.message); } finally { event.target.value = ''; }
  });
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault(); pauseBeforeContextLoss = paused; graphicUnavailable = true;
    paused = true; controls.active = false; message('Contexto gráfico perdido. Aguardando restauração.');
  });
  canvas.addEventListener('webglcontextrestored', () => {
    try {
      renderer = new Renderer(canvas); for (const key of world.chunks.keys()) world.dirty.add(key);
      graphicUnavailable = false; paused = pauseBeforeContextLoss; controls.active = !paused;
      last = 0; message('Contexto gráfico restaurado.');
    } catch (error) { message(error.message); }
  });
  message('Mundo pronto. Clique na cena ou use os controles.');
  if (testMode) {
    window.__brazilpeTest = {
      get world() { return world; }, get player() { return player; }, get renderer() { return renderer; },
      get pressure() { return pressure; },
      get metrics() { return { frames, steps, paused, chunks: world.chunks.size, triangles: renderer.triangles }; },
      step(input = {}, count = 1) { for (let i = 0; i < count; i++) { stepPlayer(api, world, player, { ...input }); pressure.step([{type:api.brazilpe_player_type(),box:playerBox(player)}]); } renderer.draw(world, player, null); },
      pause(value) { paused = value; controls.active = !value; accumulated = 0; },
      setPlayer(position, yaw = 0, pitch = 0) { player = createPlayer(position); player.yaw = yaw; player.pitch = pitch; controls.player = player; },
      edit, snapshot() { return encodeSave(world, player); }, restore(text) { restore(decodeSave(text)); },
    };
  }
  requestAnimationFrame(frame);
} catch (error) {
  message(`Não foi possível iniciar: ${error.message}`);
  for (const button of document.querySelectorAll('button')) button.disabled = true;
}
