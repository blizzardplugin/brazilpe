import { CONFIG, BLOCKS } from './config.js';

export const WORLD_WIDTH = CONFIG.chunkSize * CONFIG.chunksPerAxis;
export function coordinates(x, y, z) {
  return [x, y, z].every(Number.isInteger) && x >= 0 && z >= 0 && y >= 0 &&
    x < WORLD_WIDTH && z < WORLD_WIDTH && y < CONFIG.chunkHeight;
}
function boundary(x, z) { return x === 0 || z === 0 || x === WORLD_WIDTH - 1 || z === WORLD_WIDTH - 1; }
export function editable(x, y, z) { return coordinates(x, y, z) && y > 0 && !boundary(x, z); }
function initialBlock(x, y, z) {
  if (y === 0) return 3;
  if (boundary(x, z) && y < 8) return 3;
  if (y < 2) return 2;
  if (y === 2) return 1;
  if (x === 15 && z >= 9 && z <= 16 && y < 6) return 4;
  if (z === 17 && x >= 12 && x <= 19 && y < 5) return 3;
  if (x >= 21 && x <= 23 && z >= 8 && z <= 10 && y < 6) return 5;
  return 0;
}
function chunkKey(cx, cz) { return `${cx},${cz}`; }
export class World {
  constructor() {
    this.chunks = new Map(); this.edits = new Map(); this.dirty = new Set();
    for (let cx = 0; cx < CONFIG.chunksPerAxis; cx++) {
      for (let cz = 0; cz < CONFIG.chunksPerAxis; cz++) {
        const cells = new Uint8Array(CONFIG.chunkSize ** 2 * CONFIG.chunkHeight);
        for (let y = 0; y < CONFIG.chunkHeight; y++) {
          for (let z = 0; z < CONFIG.chunkSize; z++) {
            for (let x = 0; x < CONFIG.chunkSize; x++) {
              cells[this.index(x, y, z)] = initialBlock(cx * CONFIG.chunkSize + x, y, cz * CONFIG.chunkSize + z);
            }
          }
        }
        const key = chunkKey(cx, cz);
        this.chunks.set(key, { cx, cz, cells }); this.dirty.add(key);
      }
    }
  }
  index(x, y, z) { return y + (x * CONFIG.chunkSize + z) * CONFIG.chunkHeight; }
  get(x, y, z) {
    if (!coordinates(x, y, z)) return 0;
    const cx = Math.floor(x / CONFIG.chunkSize), cz = Math.floor(z / CONFIG.chunkSize);
    return this.chunks.get(chunkKey(cx, cz)).cells[this.index(x % CONFIG.chunkSize, y, z % CONFIG.chunkSize)];
  }
  set(x, y, z, id) {
    if (!editable(x, y, z) || !Number.isInteger(id) || id < 0 || id >= BLOCKS.length) return false;
    const key = `${x},${y},${z}`;
    if (!this.edits.has(key) && this.edits.size >= CONFIG.maxEdits && id !== initialBlock(x, y, z)) return false;
    const cx = Math.floor(x / CONFIG.chunkSize), cz = Math.floor(z / CONFIG.chunkSize);
    this.chunks.get(chunkKey(cx, cz)).cells[this.index(x % CONFIG.chunkSize, y, z % CONFIG.chunkSize)] = id;
    if (id === initialBlock(x, y, z)) this.edits.delete(key);
    else this.edits.set(key, [x, y, z, id]);
    for (const [neighborX, neighborZ] of [[cx, cz], [cx - 1, cz], [cx + 1, cz], [cx, cz - 1], [cx, cz + 1]]) {
      const neighbor = chunkKey(neighborX, neighborZ);
      if (this.chunks.has(neighbor)) this.dirty.add(neighbor);
    }
    return true;
  }
}

export function sweptBox(box, desired) {
  return box.map((value, index) => Math.fround(value +
    (index < 3 ? Math.min(desired[index], 0) : Math.max(desired[index - 3], 0))));
}
export function collectObstacles(api, world, box, desired) {
  const query = sweptBox(box, desired);
  new Float32Array(api.memory.buffer, api.brazilpe_query_buffer(), 6).set(query);
  if (api.brazilpe_query_bounds() !== 1) throw new Error('Região de consulta inválida.');
  const ranges = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_query_ranges(), 6));
  const visits = (ranges[3] - ranges[0]) * (ranges[4] - ranges[1]) * (ranges[5] - ranges[2]);
  if (visits > CONFIG.maxQueryVisits) throw new Error('Movimento excede a região de consulta permitida.');
  const data = new Float32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
  const position = new Int32Array(api.memory.buffer, api.brazilpe_block_position(), 3);
  data.fill(0); data.set([0, 0, 0, 1, 1, 1], 0); data.set(query, 8);
  const boxes = [];
  for (let x = ranges[0]; x < ranges[3]; x++) {
    for (let z = ranges[2]; z < ranges[5]; z++) {
      for (let y = ranges[1]; y < ranges[4]; y++) {
        if (!world.get(x, y, z)) continue;
        position.set([x, y, z]);
        const accepted = api.brazilpe_block_collect(1);
        if (accepted < 0) throw new Error('Entrada inválida no coletor de blocos.');
        if (!accepted) continue;
        if (boxes.length === CONFIG.maxObstacles) throw new Error('Há mais obstáculos do que o módulo aceita.');
        boxes.push(Array.from(data.slice(16, 22)));
      }
    }
  }
  return boxes;
}

export function raycast(world, origin, direction, reach = CONFIG.reach) {
  const length = Math.hypot(...direction);
  if (!Number.isFinite(length) || length === 0 || !origin.every(Number.isFinite) || reach < 0 || reach > CONFIG.reach) return null;
  const d = direction.map(x => x / length);
  const cell = origin.map(Math.floor), step = d.map(x => Math.sign(x));
  const delta = d.map(x => x === 0 ? Infinity : Math.abs(1 / x));
  const edge = d.map((x, i) => x === 0 ? Infinity : ((x > 0 ? cell[i] + 1 : cell[i]) - origin[i]) / x);
  let distance = 0, previous = null;
  for (let visited = 0; visited < 128 && distance <= reach; visited++) {
    if (world.get(...cell)) return { cell: cell.slice(), previous, distance };
    const axis = edge[0] <= edge[1] && edge[0] <= edge[2] ? 0 : edge[1] <= edge[2] ? 1 : 2;
    previous = cell.slice(); distance = edge[axis]; cell[axis] += step[axis]; edge[axis] += delta[axis];
  }
  return null;
}
