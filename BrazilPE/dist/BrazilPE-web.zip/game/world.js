import { CONFIG, BLOCKS, isPlate, solid, localBounds } from './config.js';

export const WORLD_WIDTH = CONFIG.chunkSize * CONFIG.chunksPerAxis;
export function coordinates(x, y, z) {
  return [x, y, z].every(Number.isInteger) && x >= 0 && z >= 0 && y >= 0 &&
    x < WORLD_WIDTH && z < WORLD_WIDTH && y < CONFIG.chunkHeight;
}
function boundary(x, z) { return x === 0 || z === 0 || x === WORLD_WIDTH - 1 || z === WORLD_WIDTH - 1; }
export function editable(x, y, z) { return coordinates(x, y, z) && y > 0 && !boundary(x, z); }
function initialBlock(x, y, z) {
  if (y === 0) return 3;
  if (boundary(x, z) && y < 8) return 3;
  if (y < 2) return 2;
  if (y === 2) return 1;
  if (x === 15 && z >= 9 && z <= 16 && y < 6) return 4;
  if (z === 17 && x >= 12 && x <= 19 && y < 5) return 3;
  if (x >= 21 && x <= 23 && z >= 8 && z <= 10 && y < 6) return 5;
  return 0;
}
function chunkKey(cx, cz) { return `${cx},${cz}`; }
export class World {
  constructor() {
    this.chunks = new Map(); this.edits = new Map(); this.dirty = new Set();
    this.plates = new Map(); this.signals = new Map(); this.plateSchedules = new Map();
    this.listeners = new Set(); this.unavailableChunks = new Set();
    for (let cx = 0; cx < CONFIG.chunksPerAxis; cx++) {
      for (let cz = 0; cz < CONFIG.chunksPerAxis; cz++) {
        const cells = new Uint8Array(CONFIG.chunkSize ** 2 * CONFIG.chunkHeight);
        for (let y = 0; y < CONFIG.chunkHeight; y++) {
          for (let z = 0; z < CONFIG.chunkSize; z++) {
            for (let x = 0; x < CONFIG.chunkSize; x++) {
              cells[this.index(x, y, z)] = initialBlock(cx * CONFIG.chunkSize + x, y, cz * CONFIG.chunkSize + z);
            }
          }
        }
        const key = chunkKey(cx, cz);
        this.chunks.set(key, { cx, cz, cells, metadata: new Uint8Array(cells.length / 2) }); this.dirty.add(key);
      }
    }
  }
  index(x, y, z) { return y + (x * CONFIG.chunkSize + z) * CONFIG.chunkHeight; }
  get(x, y, z) {
    if (!coordinates(x, y, z)) return 0;
    const cx = Math.floor(x / CONFIG.chunkSize), cz = Math.floor(z / CONFIG.chunkSize);
    return this.chunks.get(chunkKey(cx, cz)).cells[this.index(x % CONFIG.chunkSize, y, z % CONFIG.chunkSize)];
  }
  set(x, y, z, id) {
    if (!editable(x, y, z) || !Number.isInteger(id) || id < 0 || id >= BLOCKS.length) return false;
    if (isPlate(id) && (!solid(this.get(x, y - 1, z)) ||
        (!isPlate(this.get(x, y, z)) && this.plates.size >= CONFIG.maxPlates))) return false;
    if (this.get(x, y, z) === id) return true;
    const changes = [[x, y, z, id]];
    if (!solid(id) && isPlate(this.get(x, y + 1, z))) changes.push([x, y + 1, z, 0]);
    let projected = this.edits.size;
    for (const [px, py, pz, value] of changes) {
      const pkey = `${px},${py},${pz}`;
      projected += Number(value !== initialBlock(px, py, pz)) - Number(this.edits.has(pkey));
    }
    if (projected > CONFIG.maxEdits) return false;
    for (const change of changes) this.commit(...change);
    return true;
  }
  commit(x, y, z, id) {
    const key = `${x},${y},${z}`;
    const previous = this.get(x, y, z);
    const cx = Math.floor(x / CONFIG.chunkSize), cz = Math.floor(z / CONFIG.chunkSize);
    this.chunks.get(chunkKey(cx, cz)).cells[this.index(x % CONFIG.chunkSize, y, z % CONFIG.chunkSize)] = id;
    if (id === initialBlock(x, y, z)) this.edits.delete(key);
    else this.edits.set(key, [x, y, z, id]);
    this.setMetadata(x, y, z, 0);
    this.plates.delete(key); this.signals.delete(key); this.plateSchedules.delete(key);
    if (isPlate(id)) this.plates.set(key, [x, y, z]);
    for (const [neighborX, neighborZ] of [[cx, cz], [cx - 1, cz], [cx + 1, cz], [cx, cz - 1], [cx, cz + 1]]) {
      const neighbor = chunkKey(neighborX, neighborZ);
      if (this.chunks.has(neighbor)) this.dirty.add(neighbor);
    }
    for (const listener of this.listeners) listener({ position: [x, y, z], previous, id });
  }
  getMetadata(x, y, z) {
    if (!coordinates(x, y, z)) return 0;
    const chunk = this.chunks.get(chunkKey(Math.floor(x / 16), Math.floor(z / 16)));
    const index = this.index(x & 15, y, z & 15);
    return (chunk.metadata[index >> 1] >> ((index & 1) * 4)) & 15;
  }
  setMetadata(x, y, z, value) {
    if (!coordinates(x, y, z) || !Number.isInteger(value) || value < 0 || value > 15) return false;
    const key = chunkKey(Math.floor(x / 16), Math.floor(z / 16)), chunk = this.chunks.get(key);
    const index = this.index(x & 15, y, z & 15), shift = (index & 1) * 4;
    chunk.metadata[index >> 1] = (chunk.metadata[index >> 1] & ~(15 << shift)) | (value << shift);
    this.dirty.add(key); return true;
  }
  signalAt(x, y, z) { return this.signals.get(`${x},${y},${z}`) ?? 0; }
  pressureRegionAvailable(x, y, z) {
    // Outside the bounded scene is fixed virtual terrain; inside chunks can be unavailable.
    for (let cx = Math.floor((x - 8) / 16); cx <= Math.floor((x + 8) / 16); cx++)
      for (let cz = Math.floor((z - 8) / 16); cz <= Math.floor((z + 8) / 16); cz++)
        if (this.unavailableChunks.has(chunkKey(cx, cz))) return false;
    return true;
  }
}

export function sweptBox(box, desired) {
  return box.map((value, index) => Math.fround(value +
    (index < 3 ? Math.min(desired[index], 0) : Math.max(desired[index - 3], 0))));
}
export function collectObstacles(api, world, box, desired) {
  const query = sweptBox(box, desired);
  new Float32Array(api.memory.buffer, api.brazilpe_query_buffer(), 6).set(query);
  if (api.brazilpe_query_bounds() !== 1) throw new Error('Região de consulta inválida.');
  const ranges = Array.from(new Int32Array(api.memory.buffer, api.brazilpe_query_ranges(), 6));
  const visits = (ranges[3] - ranges[0]) * (ranges[4] - ranges[1]) * (ranges[5] - ranges[2]);
  if (visits > CONFIG.maxQueryVisits) throw new Error('Movimento excede a região de consulta permitida.');
  const data = new Float32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
  const position = new Int32Array(api.memory.buffer, api.brazilpe_block_position(), 3);
  data.fill(0); data.set([0, 0, 0, 1, 1, 1], 0); data.set(query, 8);
  const boxes = [];
  for (let x = ranges[0]; x < ranges[3]; x++) {
    for (let z = ranges[2]; z < ranges[5]; z++) {
      for (let y = ranges[1]; y < ranges[4]; y++) {
        if (!solid(world.get(x, y, z))) continue;
        position.set([x, y, z]);
        const accepted = api.brazilpe_block_collect(1);
        if (accepted < 0) throw new Error('Entrada inválida no coletor de blocos.');
        if (!accepted) continue;
        if (boxes.length === CONFIG.maxObstacles) throw new Error('Há mais obstáculos do que o módulo aceita.');
        boxes.push(Array.from(data.slice(16, 22)));
      }
    }
  }
  return boxes;
}

export function raycast(world, origin, direction, reach = CONFIG.reach) {
  const length = Math.hypot(...direction);
  if (!Number.isFinite(length) || length === 0 || !origin.every(Number.isFinite) || reach < 0 || reach > CONFIG.reach) return null;
  const d = direction.map(x => x / length);
  const cell = origin.map(Math.floor), step = d.map(x => Math.sign(x));
  const delta = d.map(x => x === 0 ? Infinity : Math.abs(1 / x));
  const edge = d.map((x, i) => x === 0 ? Infinity : ((x > 0 ? cell[i] + 1 : cell[i]) - origin[i]) / x);
  let distance = 0, previous = null;
  for (let visited = 0; visited < 128 && distance <= reach; visited++) {
    const id = world.get(...cell);
    if (id) {
      const bounds = localBounds(id, world.getMetadata(...cell));
      let near = 0, far = reach;
      for (let axis = 0; axis < 3; axis++) {
        const low = cell[axis] + bounds[axis], high = cell[axis] + bounds[axis + 3];
        if (d[axis] === 0) { if (origin[axis] < low || origin[axis] > high) far = -1; }
        else {
          const a = (low - origin[axis]) / d[axis], b = (high - origin[axis]) / d[axis];
          near = Math.max(near, Math.min(a, b)); far = Math.min(far, Math.max(a, b));
        }
      }
      if (near <= far && far >= 0) return { cell: cell.slice(), previous, distance: near };
    }
    const axis = edge[0] <= edge[1] && edge[0] <= edge[2] ? 0 : edge[1] <= edge[2] ? 1 : 2;
    previous = cell.slice(); distance = edge[axis]; cell[axis] += step[axis]; edge[axis] += delta[axis];
  }
  return null;
}
