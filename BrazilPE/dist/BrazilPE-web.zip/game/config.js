/* New web prototype settings. These are not recovered MCPE constants. */
export const CONFIG = Object.freeze({
  seed: 1510, chunkSize: 16, chunkHeight: 128, chunksPerAxis: 2,
  halfWidth: 0.3, bodyHeight: 1.8, eyeHeight: 1.6,
  gravity: 20, speed: 4.5, jumpSpeed: 6.2,
  fixedStep: 1 / 60, maximumSteps: 6, maximumFrameDelta: 0.1,
  reach: 5, maxQueryVisits: 8192, maxObstacles: 64,
  maxEdits: 8192, maxSaveBytes: 1024 * 1024,
  sensitivity: 0.0025, touchSensitivity: 0.006,
  near: 0.05, far: 90, fov: Math.PI / 3,
  saveKey: 'BrazilPE.web.prototype.v1', saveVersion: 1,
  spawn: Object.freeze([8.5, 3, 8.5]),
  spawnYaw: Math.PI / 2, spawnPitch: -0.15,
});
export const BLOCKS = Object.freeze([
  { name: 'Ar', color: [0, 0, 0] },
  { name: 'Prado', color: [0.32, 0.66, 0.42] },
  { name: 'Terra', color: [0.55, 0.35, 0.24] },
  { name: 'Pedra', color: [0.48, 0.55, 0.6] },
  { name: 'Madeira', color: [0.72, 0.51, 0.3] },
  { name: 'Azul', color: [0.25, 0.58, 0.78] },
]);
