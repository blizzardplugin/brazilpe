import { CONFIG } from './config.js';
import { simulate } from '../movement.js';
import { collectObstacles } from './world.js';

export function createPlayer(position = CONFIG.spawn) {
  return { position: Array.from(position), velocity: [0, 0, 0], yaw: CONFIG.spawnYaw, pitch: CONFIG.spawnPitch, ground: false };
}
export function playerBox(player) {
  const [x, y, z] = player.position;
  return [x - CONFIG.halfWidth, y, z - CONFIG.halfWidth, x + CONFIG.halfWidth, y + CONFIG.bodyHeight, z + CONFIG.halfWidth];
}
export function stepPlayer(api, world, player, input, dt = CONFIG.fixedStep) {
  if (!Number.isFinite(dt) || dt <= 0 || dt > CONFIG.maximumFrameDelta) throw new Error('Passo de tempo inválido.');
  const sideways = Number(Boolean(input.right)) - Number(Boolean(input.left));
  const forward = Number(Boolean(input.forward)) - Number(Boolean(input.backward));
  const magnitude = Math.hypot(sideways, forward) || 1;
  player.velocity[0] = (Math.cos(player.yaw) * sideways + Math.sin(player.yaw) * forward) / magnitude * CONFIG.speed;
  player.velocity[2] = (Math.sin(player.yaw) * sideways - Math.cos(player.yaw) * forward) / magnitude * CONFIG.speed;
  if (input.jump && player.ground) player.velocity[1] = CONFIG.jumpSpeed;
  input.jump = false;
  player.velocity[1] -= CONFIG.gravity * dt;
  const box = playerBox(player), desired = player.velocity.map(v => Math.fround(v * dt));
  const obstacles = collectObstacles(api, world, box, desired);
  const result = simulate(api, { box, velocity: player.velocity, desired, obstacles, ground: Number(player.ground), noCollision: 0 });
  player.position = [result.position[0], result.box[1], result.position[2]];
  player.velocity = result.velocity; player.ground = result.ground;
  if (player.position[1] < -10) Object.assign(player, createPlayer());
  return { ...result, obstacles: obstacles.length };
}
export function cameraDirection(player) {
  return [Math.sin(player.yaw) * Math.cos(player.pitch), Math.sin(player.pitch), -Math.cos(player.yaw) * Math.cos(player.pitch)];
}
