import { CONFIG, BLOCKS } from './config.js';
import { World, WORLD_WIDTH, editable } from './world.js';
import { createPlayer, playerBox } from './physics.js';

export function encodeSave(world, player) {
  const record = { format: 'BrazilPE-web-world', version: CONFIG.saveVersion, seed: CONFIG.seed,
    edits: Array.from(world.edits.values()),
    player: { position: player.position, yaw: player.yaw, pitch: player.pitch } };
  const text = JSON.stringify(record);
  if (text.length > CONFIG.maxSaveBytes) throw new Error('Mundo grande demais para salvar.');
  return text;
}
export function decodeSave(text) {
  if (typeof text !== 'string' || text.length > CONFIG.maxSaveBytes) throw new Error('Arquivo de mundo grande demais.');
  let data;
  try { data = JSON.parse(text); } catch { throw new Error('Arquivo de mundo inválido.'); }
  if (!data || data.format !== 'BrazilPE-web-world' || data.version !== CONFIG.saveVersion || data.seed !== CONFIG.seed ||
      !Array.isArray(data.edits) || data.edits.length > CONFIG.maxEdits) throw new Error('Formato de mundo incompatível.');
  const position = data.player?.position;
  if (!Array.isArray(position) || position.length !== 3 || !position.every(Number.isFinite) ||
      position[0] < 1 || position[0] > WORLD_WIDTH - 1 || position[2] < 1 || position[2] > WORLD_WIDTH - 1 ||
      position[1] < 1 || position[1] > CONFIG.chunkHeight ||
      !Number.isFinite(data.player.yaw) || Math.abs(data.player.yaw) > Math.PI * 2 ||
      !Number.isFinite(data.player.pitch) || Math.abs(data.player.pitch) > 1.5) throw new Error('Posição salva inválida.');
  const seen = new Set();
  for (const edit of data.edits) {
    if (!Array.isArray(edit) || edit.length !== 4 || !edit.every(Number.isInteger) ||
        !editable(...edit.slice(0, 3)) || edit[3] < 0 || edit[3] >= BLOCKS.length) throw new Error('Bloco salvo inválido.');
    const key = edit.slice(0, 3).join(',');
    if (seen.has(key)) throw new Error('Bloco duplicado no arquivo.');
    seen.add(key);
  }
  const world = new World();
  for (const edit of data.edits) if (!world.set(...edit)) throw new Error('Não foi possível restaurar o mundo.');
  const player = createPlayer(position); player.yaw = data.player.yaw; player.pitch = data.player.pitch;
  const bounds = playerBox(player);
  for (let x = Math.floor(bounds[0]); x < Math.ceil(bounds[3]); x++) {
    for (let z = Math.floor(bounds[2]); z < Math.ceil(bounds[5]); z++) {
      for (let y = Math.floor(bounds[1]); y < Math.ceil(bounds[4]); y++) {
        if (world.get(x, y, z)) throw new Error('A posição salva está dentro de um bloco.');
      }
    }
  }
  return { world, player };
}
export function saveLocal(storage, world, player) {
  try { storage.setItem(CONFIG.saveKey, encodeSave(world, player)); }
  catch (error) { throw new Error(`Não foi possível salvar neste navegador: ${error.message}`); }
}
export function loadLocal(storage) {
  const text = storage.getItem(CONFIG.saveKey);
  return text === null ? null : decodeSave(text);
}
