function vector(value, length) {
  if (!Array.isArray(value) || value.length !== length ||
      !value.every(x => Number.isFinite(x) && Math.abs(x) <= 1000000)) {
    throw new Error('Entrada de movimento inválida.');
  }
  return value;
}
function box(value) {
  vector(value, 6);
  if ([0, 1, 2].some(axis => value[axis] > value[axis + 3])) throw new Error('Caixa invertida.');
  return value;
}
export function simulate(api, initial) {
  box(initial.box); vector(initial.velocity, 3); vector(initial.desired, 3);
  if (!Array.isArray(initial.obstacles) || initial.obstacles.length > 64 ||
      ![0, 1].includes(initial.ground) || ![0, 1].includes(initial.noCollision)) {
    throw new Error('Cenário de movimento inválido.');
  }
  initial.obstacles.forEach(box);
  const offset = api.brazilpe_movement_buffer();
  if (!Number.isInteger(offset) || offset < 0 || offset % 4 !== 0 || offset + 544 * 4 > api.memory.buffer.byteLength) {
    throw new Error('Memória de movimento inválida.');
  }
  const state = new Float32Array(api.memory.buffer, offset, 544);
  state.fill(0);
  state.set(initial.box, 0); state.set(initial.velocity, 8); state.set(initial.desired, 12);
  state[24] = initial.ground;
  initial.obstacles.forEach((value, index) => state.set(value, 32 + index * 8));
  if (api.brazilpe_move(initial.obstacles.length, initial.noCollision) !== 1) {
    throw new Error('O módulo rejeitou o cenário.');
  }
  return { box: Array.from(state.slice(0, 6)), velocity: Array.from(state.slice(8, 11)),
    position: Array.from(state.slice(16, 19)), allowed: Array.from(state.slice(20, 23)), ground: state[24] === 1 };
}

export function attachMovement(api) {
  const horizontal = document.querySelector('#step-horizontal');
  const vertical = document.querySelector('#step-vertical');
  const bypass = document.querySelector('#step-bypass');
  const canvas = document.querySelector('#movement-scene');
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas de movimento indisponível.');
  const initialBox = [-0.3, 0.6, -0.3, 0.3, 2.4, 0.3];
  const obstacles = [[-8, -1, -8, 8, 0, 8], [1, 0, -4, 2, 4, 4], [-4, 0, 1, 4, 4, 2]];
  function draw() {
    const h = Number(horizontal.value), v = Number(vertical.value);
    if (!Number.isFinite(h) || h < 0 || h > 2 || !Number.isFinite(v) || v < -1 || v > 1) return;
    const result = simulate(api, { box: initialBox, obstacles, velocity: [1, -1, 1],
      desired: [h, v, h], ground: 0, noCollision: bypass.checked ? 1 : 0 });
    document.querySelector('#step-horizontal-value').textContent = h.toFixed(2);
    document.querySelector('#step-vertical-value').textContent = v.toFixed(2);
    document.querySelector('#step-result').textContent = result.allowed.map(x => x.toFixed(3)).join(' / ');
    document.querySelector('#step-ground').textContent = result.ground ? 'Sim' : 'Não';
    document.querySelector('#step-velocity').textContent = result.velocity.map(x => x.toFixed(3)).join(' / ');
    context.clearRect(0, 0, 640, 300);
    const xPixel = x => 200 + x * 100, yPixel = y => 240 - y * 65;
    function rectangle(bounds, color, fill) {
      context.fillStyle = color; context.strokeStyle = color; context.lineWidth = 3;
      const left = xPixel(bounds[0]), top = yPixel(bounds[4]);
      const width = (bounds[3] - bounds[0]) * 100, height = (bounds[4] - bounds[1]) * 65;
      if (fill) context.fillRect(left, top, width, height);
      else context.strokeRect(left, top, width, height);
    }
    rectangle(obstacles[0], '#2d4652', true); rectangle(obstacles[1], '#2d4652', true);
    rectangle(initialBox, '#83e4b0', false); rectangle(result.box, '#83b5ff', false);
    context.fillStyle = '#e6f0e9'; context.font = '14px system-ui';
    context.fillText('Vista X/Y · Verde: início · Azul: resultado', 24, 28);
  }
  for (const control of [horizontal, vertical, bypass]) {
    control.disabled = false; control.addEventListener('input', draw);
  }
  draw();
}
