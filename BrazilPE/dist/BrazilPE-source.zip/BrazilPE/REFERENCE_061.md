# Referência enviada: Minecraft-MCPE 0.6.1

Repositório: https://github.com/Intelinsidecom/Minecraft-MCPE
Commit inspecionado: `d9a68e1c895a9907019359b5cc408bb5786e34b3`.

O próprio README descreve o conteúdo como "leak files for MCPE 0.6.1" e lista
ports, ajustes e bugs posteriores. Isso não confirma publicação oficial ou uma
snapshot inalterada da 0.6.1. A análise desta entrega consultou o README e os nomes
de arquivos, sem importar código desse repositório para o BrazilPE.

A árvore contém lógica C++ de mundo (`world/level/Level.h`), inventário
(`world/entity/player/Inventory.cpp`), armazenamento de mundo e `util/Random.h`,
além de adaptações Android/iOS/Win32/UWP em `AppPlatform*`. Essas divisões podem
servir de referência arquitetural para análises futuras.

Os SDKs Android/iOS antigos não precisam ser o runtime do projeto web. As
dependências de plataforma seriam adaptadas para WebAssembly/WebGL, entrada,
áudio, armazenamento e transporte web. Esse trabalho não prova equivalência
de regras, formatos ou protocolos da 0.6.1 com a 0.15.10.

Para a etapa atual, a referência de comportamento continua sendo o executável
ARM64 fingerprintado da 0.15.10 disponível no checkout. O repositório 0.6.1
não foi usado para preencher lacunas de placas ou alterar seus parâmetros.
