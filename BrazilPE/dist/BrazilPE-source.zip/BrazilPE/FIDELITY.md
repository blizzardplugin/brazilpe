# BrazilPE: caminho até a fidelidade à MCPE 0.15.10

Estado de 13/10/2026 (São Paulo). O navegador executa um protótipo novo e rotinas reconstruídas
em WebAssembly. Ainda não executa o jogo original completo. Não há uma porcentagem
de conclusão comprovada nem prazo estimável com a evidência atual.

A referência disponível é o executável ARM64 do IPA modificado incluído no
repositório, verificado por SHA-256. O IPA original não modificado não foi fornecido.
Isso permite avançar na análise, mas limita a comparação da versão original,
principalmente perto das alterações de hitbox. Emulação com dependências
substituídas comprova apenas os caminhos explicitamente exercitados.

## O que já tem evidência

O agendador agora tem inserção, heap e despacho reconstruídos, com 3.840
operações em 80 cenários nativos. A validação substitui disponibilidade da
região, leitura do ID do bloco e destino do callback; usa vetor prealocado.
Cancelamento observado e callbacks reentrantes de placas foram validados em
testes posteriores. Persistência nativa e equivalência de filas compartilhadas
permanecem pendentes; a integração web usa filas isoladas por placa.
O Experimento 06 substituiu sua fila de prazo única por esse núcleo Wasm.

Nesta entrega também passaram 960 cenários nativos de consulta sensora
(listas do cliente e chunks do servidor) e 1.024 sequências de eventos do tick.
O método virtual que fornece chunks foi substituído por uma fixture; os
provedores nativos e seus filtros de estado executaram. A lista separada de
jogadores permaneceu vazia. Leituras de sinal/metadado e destinos dos eventos
foram interceptados: a evidência comprova intenção e ordem de eventos, não o
agendador original ou propagação de redstone.

O Experimento 06 usa essas rotinas com uma entidade fornecida e integração de
laboratório ao núcleo do agendador reconstruído. `catalog.html` mostra 256 declarações de blocos (192 com nome),
40 declarações de itens dos recursos e 38 resumos de modelos. Isso não é um
catálogo completo de itens em runtime. Os IDs dos recursos são preservados sem
inferir offsets. Os 11 sistemas solicitados **continuam sem conclusão integral**;
veja [SYSTEMS.md](SYSTEMS.md) para o estado da entrega por sistema.

- Operações de AABB, recorte por eixo, movimento com obstáculos fornecidos,
  limites da consulta de blocos, IDs/metadados e acesso controlado aos chunks.
- Três getters de forma; oito ligações estáticas entre ID, nome, construtor e
  getter. Inicialização completa e comportamento dos blocos pendentes.
- Sinal de placas comuns/ponderadas, metadado e intervalo retornado: 430
  comparações com ARM64. Consulta de entidades, cópia/liberação do vetor normal
  e método virtual de tipo de entidade substituídos nos testes.
- Protótipo jogável com quatro chunks, colisão, edição, persistência própria e
  teclado/toque. Terreno, renderização, gravidade, paleta e saves são próprios.

## Etapas restantes, em ordem de trabalho

| Etapa | Estado atual | O que falta e como validar |
| --- | --- | --- |
| 1. Placas de pressão | Quatro placas funcionais no protótipo; 24 ciclos nativos completos comparados | Equivalência de filas compartilhadas, receptores originais e ambiente não modificado não comprovados. A integração web tem filas por placa, armazenamento próprio e saída de sinal sem circuito completo. |
| 2. Catálogo e inicialização | Parcial | Construtores e registros reais de blocos/itens, propriedades e variantes. O trace de 256 declarações substitui chamadas e não comprova gameplay. Validar parâmetros finais dos tipos registrados. |
| 3. Formas e interações | Parcial | Escadas, lajes, portas, cercas, plantas, neve, trilhos e variantes; seleção, colisão, suporte e quebra. Resolver o caminho das placas sem translação antes de integrar. Comparar por ID, metadado e posição. |
| 4. Mundo e geração | Layout parcial; terreno próprio | Seeds, RNG, biomas, relevo, estruturas, dimensões e ciclo de carregamento. Comparar chunks por seed/coordenadas e estados de disponibilidade. |
| 5. Jogador e física | Movimento parcial; controles próprios | Gravidade, salto, atrito, água, escadas, agachar, voo, dano, câmera e modos de jogo. Comparar trajetórias/estados tick a tick com entradas idênticas. |
| 6. Inventário e sobrevivência | Pendente | Stacks, receitas, ferramentas, durabilidade, drops, saúde, fome e interfaces. Validar ações, transações, falhas e persistência. |
| 7. Entidades | Pendente | Mobs, itens no chão, projéteis, veículos, IA, spawn, colisões e animações. Comparar eventos/estados em cenários repetíveis. |
| 8. Simulação e redstone | Apenas cálculo isolado de placas | Agendamento, ticks aleatórios, líquidos, fogo, crescimento, vizinhos e circuitos. Comparar ordem de eventos/resultados por tick. |
| 9. Visual e áudio | Renderizador ilustrativo próprio | Materiais, texturas, iluminação, transparência, partículas, modelos, HUD, menus e sons. Comparar imagens/áudio e definir carregamento de recursos sem distribuir o IPA. |
| 10. Saves originais | JSON próprio | Formato real de mundo, chunks, metadados, entidades e inventário. Validar leitura/escrita em cópias com round-trip e preservação de dados desconhecidos. |
| 11. Multiplayer 0.15.10 | Pendente | Protocolo, sessão, pacotes, sincronização e transporte compatível com navegador. Definir bridge se necessária e testar com referência. |
| 12. Compatibilidade e validação final | Chromium automatizado | Chrome/Firefox/Edge/Safari e aparelhos reais PC/iOS/Android: toque, áudio, memória, desempenho e armazenamento. Regressão por cenário e referência não modificada antes de afirmar fidelidade geral. |

As etapas se sobrepõem e exigem regressão. Uma rotina isolada validada não conclui
um sistema inteiro. O laboratório atual não adiciona redstone ou placas
funcionais ao mundo jogável. Os limites de 4096 entidades/capacidade são limites
da API de laboratório, não constantes recuperadas do jogo.

## Reproduzir esta etapa

Na raiz do repositório:

```bash
.venv/bin/python BrazilPE/validation/pressure_reference.py
bash BrazilPE/build.sh
node BrazilPE/validation/pressure_compare.mjs
.venv/bin/python BrazilPE/validation/pressure_runtime_reference.py
node BrazilPE/validation/pressure_runtime_compare.mjs
.venv/bin/python BrazilPE/validation/resource_catalog.py
```

Os relatórios locais `pressure-reference.json`, `pressure-evidence.json` e
`pressure-result.json` registram entradas, retornos, bytes e limitações.
O Experimento 05 mostra esses cálculos no navegador.
