# Estado dos 11 sistemas solicitados

Atualização de 13/10/2026 (São Paulo): o laboratório agora usa inserção,
ordenação por prazo e despacho reconstruídos do agendador. Passaram 3.840
operações em 80 cenários ARM64, incluindo empate de prazos, limites por passo,
atrasos negativos, troca de ID, indisponibilidade e aritmética uint64.
Os acessos ao mundo e os destinos virtuais dos eventos foram substituídos por
fixtures. Cancelamento e callbacks reentrantes de placas receberam validação
posterior de ciclos completos. Persistência nativa e equivalência de filas
compartilhadas continuam pendentes; o adaptador web isola filas por placa.
Essa entrega não conclui os 11 sistemas.

Nenhum dos 11 sistemas foi declarado completo. O protótipo usa um núcleo novo
com rotinas reconstruídas; não há port integral nem código-fonte original
recuperado. O executável é o ARM64 do IPA modificado incluído no repositório.

| Sistema | Entrega verificável nesta etapa | Trabalho restante |
| --- | --- | --- |
| 1. Placas | Quatro placas funcionais no mundo web: filtros/capacidades por ID confirmados, ativação/liberação, sinal, suporte, remoção e salvamento próprio. 24 ciclos completos ARM64/2.400 passos, 12 grupos de integração e 11 checks no navegador. | Equivalência de filas compartilhadas e receptores originais não comprovada. O adaptador usa filas isoladas por placa, persistência própria e saída de sinal sem circuitos de redstone completos. |
| 2. Inicialização e catálogo | 256 argumentos de declaração de blocos; 192 nomes; recursos visuais associados por nome literal; 40 declarações de itens disponíveis em arquivo. Busca em `catalog.html`. | Executar os construtores reais e inicialização, obter o registro completo de itens/runtime e validar propriedades finais. Não inferir ID de runtime a partir de ID do recurso. |
| 3. Formas e interações | Três getters e oito associações estáticas já validados. Recursos de forma/textura inventariados. | Demais getters, interações, materiais, suporte, quebra e colisões completas por estado. |
| 4. Geração e dimensões | Layout parcial de chunks já reconstruído; mundo do protótipo próprio. | Recuperar algoritmo/RNG, seeds, biomas, estruturas, dimensões e ciclo de chunks; comparar referências geradas. |
| 5. Jogador | Recorte de movimento validado; gravidade/controles novos. | Recuperar integrador, modos, câmera e regras de movimento em cada meio; comparar estados por tick. |
| 6. Inventário e sobrevivência | Dados declarativos de uso/alimento quando presentes nas 40 entradas do arquivo de itens. | Implementar runtime, inventário, receitas, durabilidade, drops, saúde e fome. Dados de recurso não comprovam os cálculos do sistema. |
| 7. Entidades | Filtros de tipo e consulta controlada; 38 resumos de modelos. | Spawn, simulação, IA, animação, projéteis e veículos. Modelos não contêm IA. |
| 8. Simulação/redstone | Cálculos e sinais de placas integrados; núcleo de agendamento/cancelamento observado e callbacks de placas validados. | Persistência nativa, filas compartilhadas, aleatoriedade, vizinhos, líquidos, fogo, crescimento e circuitos completos. |
| 9. Visual/áudio | Inventário e hashes dos arquivos de recursos; propriedades visuais declaradas e dimensões/quantidades de ossos dos modelos. | Carregamento, renderização/animação, materiais/iluminação, HUD e decodificação FSB. Imagens, modelos completos e áudio não foram adicionados ao ZIP público. |
| 10. Saves originais | Persistência JSON própria já existente. | Recuperar formato e versões reais, ler/escrever cópias de saves de referência e preservar dados desconhecidos. Não há saves originais de teste no checkout. |
| 11. Multiplayer | Nenhuma implementação compatível entregue. | Recuperar protocolo/sessões, testar cliente/servidor 0.15.10 e adaptar transporte ao navegador. WebSocket sozinho não fornece compatibilidade com protocolo/UDP originais. |

## Limites dos testes de placas

Executaram nativamente as consultas `0x1005dc118`/`0x1005dc3ec`, o filtro
`0x1004e94e4`, a caixa sensora `0x1006068ac`, o coletor de entidades do chunk
`0x100676f30` e os provedores de chunks. As fixtures forneceram um mapa de chunks
prealocados, listas de entidades e método virtual de tipo. Não há alocação de
vetor durante o teste nem concorrência ou execução da inicialização original.

O controlador `0x100606584` chama a atualização `0x10060671c`; os testes
interceptam as leituras de sinal/metadado e os destinos de componente, escrita,
som e agendamento. As sequências observadas comprovaram: saída antecipada no
mundo remoto, escrita mesmo quando o sinal não muda, som apenas ao mudar entre
zero e positivo e pedido de novo tick enquanto o sinal é positivo.

O Wasm retorna eventos. O Experimento 06 usa a inserção, heap e despacho
reconstruídos do agendador, com IDs/disponibilidade fornecidos e execução dos
eventos pelo laboratório. Não substitui a rede, os circuitos, a persistência da
fila ou o loop completo do mundo original.

## Reproduzir

```bash
.venv/bin/python BrazilPE/validation/pressure_runtime_reference.py
.venv/bin/python BrazilPE/validation/resource_catalog_test.py
.venv/bin/python BrazilPE/validation/resource_catalog.py
bash BrazilPE/build.sh
node BrazilPE/validation/pressure_runtime_compare.mjs
.venv/bin/python BrazilPE/validation/scheduler_reference.py
node BrazilPE/validation/scheduler_compare.mjs
```

Com o servidor local da pasta `public` e Chromium/CDP iniciado conforme o README:

```bash
node BrazilPE/validation/systems_browser.mjs
node BrazilPE/validation/browser.mjs
node BrazilPE/validation/game_browser.mjs
```

A comparação final com a edição não modificada requer uma referência original.
A ausência dela não impede continuar a engenharia reversa, mas impede validar
as diferenças próximas das alterações de hitbox e afirmar fidelidade geral.
