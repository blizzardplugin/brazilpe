"""Execute the original base collision collector and its real virtual methods.
Only metadata lookup is substituted; the base shape getter ignores metadata.
Vector storage is preallocated, so no native allocator is involved.
"""
import json
import random
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2,
    UC_ARM64_REG_X3, UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR)
from native_image import load_image, function_starts

OUT = Path(__file__).resolve().parent
image, digest = load_image()
starts = function_starts(image)
collector, air, vtable, metadata = 0x10060ff60, 0x100605dfc, 0x100e8ac00, 0x1005da064
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for segment in image.segments:
    if not segment['va'] or not segment['vs']: continue
    uc.mem_map(segment['va'], (segment['vs'] + 4095) & ~4095)
    if segment['fs']: uc.mem_write(segment['va'], image.raw[segment['fo']:segment['fo'] + segment['fs']])
base, stop = 0x70000000, 0x71000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096)
position, query, vector, output = base + 0x1000, base + 0x2000, base + 0x3000, base + 0x4000

def metadata_lookup(machine, address, size, user):
    machine.reg_write(UC_ARM64_REG_X0, 0)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
uc.hook_add(UC_HOOK_CODE, metadata_lookup, begin=metadata, end=metadata)

def execute(entry):
    uc.mem_write(base, bytes(256))
    uc.mem_write(base, struct.pack('<Q', vtable))
    uc.mem_write(base + 0x84, struct.pack('<6f', *entry['shape']) + bytes([entry['flag']]))
    uc.mem_write(position, struct.pack('<3i', *entry['position']))
    uc.mem_write(query, struct.pack('<6f', *entry['query']) + bytes(8))
    uc.mem_write(vector, struct.pack('<3Q', output, output, output + 28))
    uc.mem_write(output, bytes(28))
    for register, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x800),
        (UC_ARM64_REG_X2, position), (UC_ARM64_REG_X3, query), (UC_ARM64_REG_X4, vector),
        (UC_ARM64_REG_X5, 0), (UC_ARM64_REG_SP, base + 0x1f000), (UC_ARM64_REG_LR, stop)]:
        uc.reg_write(register, value)
    uc.emu_start(collector if entry['enabled'] else air, stop, count=3000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop
    assert uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
    returned = uc.reg_read(UC_ARM64_REG_X0)
    end = struct.unpack('<Q', bytes(uc.mem_read(vector + 8, 8)))[0]
    assert end in (output, output + 28)
    assert returned == int(end != output)
    return {'accepted': returned, 'box_bits': list(struct.unpack('<6I', bytes(uc.mem_read(output, 24)))) if returned else None,
            'flag': uc.mem_read(output + 24, 1)[0] if returned else None}

rng = random.Random(151005)
entries = []
shapes = [[0, 0, 0, 1, 1, 1], [0, 0, 0, 1, 0.5, 1], [0.2, 0, 0.2, 0.8, 1, 0.8], [0] * 6]
for shape in shapes:
    for flag in [0, 1, 2, 3]:
        for enabled in [0, 1]:
            for shift in [-1, 0, 0.5, 1, 2]:
                entries.append({'shape': shape, 'flag': flag, 'position': [2, -3, 5],
                    'query': [2 + shift, -3, 5, 3 + shift, -1, 6], 'enabled': enabled})
for _ in range(800):
    low = [rng.uniform(-0.5, 0.5) for _ in range(3)]
    shape = low + [low[i] + rng.uniform(0, 1.5) for i in range(3)]
    pos = [rng.randrange(-20, 21) for _ in range(3)]
    query_low = [pos[i] + rng.uniform(-1, 1) for i in range(3)]
    entries.append({'shape': shape, 'flag': rng.choice([0, 0, 0, 1, 2]), 'position': pos,
        'query': query_low + [query_low[i] + rng.uniform(0.1, 2) for i in range(3)], 'enabled': int(rng.random() > 0.1)})
for entry in entries: entry['expected'] = execute(entry)
(OUT / 'block-reference.json').write_text(json.dumps({'cases': entries}, indent=2) + '\n')
cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
routines = {}
for address in [collector, air, 0x100610b60, 0x1006101b4, 0x100610b08, 0x100610b58, 0x1006f7e04, 0x1006f83a0]:
    code = image.read(address, starts[starts.index(address) + 1] - address)
    routines[hex(address)] = {'bytes': code.hex(), 'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
(OUT / 'block-evidence.json').write_text(json.dumps({
    'executable_sha256': digest, 'base_vtable': hex(vtable), 'local_shape_offset': '0x84',
    'default_shape_initialized_by': '0x10060ed7c..0x10060ee84 calling 0x1006f6268',
    'metadata_lookup_stub': hex(metadata), 'routines': routines,
    'limitations': ['Base virtual method chain only, not subclass overrides.', 'Vector has free capacity; allocator growth untested.',
        'Fixtures supply local shape; partial shapes do not establish slab/fence/other retail block identities.'],
}, indent=2) + '\n')
print(f'Native base collector: {len(entries)} cases; {sum(x["expected"]["accepted"] for x in entries)} accepted')
