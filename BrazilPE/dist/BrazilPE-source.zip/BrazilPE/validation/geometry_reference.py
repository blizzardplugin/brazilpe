"""Execute six candidate geometric routines from the actual ARM64 binary."""
import hashlib
import json
import random
import struct
import sys
from pathlib import Path

from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM
from unicorn.arm64_const import (
    UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X8,
    UC_ARM64_REG_W0, UC_ARM64_REG_W2, UC_ARM64_REG_S0,
    UC_ARM64_REG_LR, UC_ARM64_REG_PC, UC_ARM64_REG_SP,
)

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.macho import MachO

OUT = Path(__file__).resolve().parent
from native_image import load_image, function_starts
m, expected = load_image()
starts = function_starts(m)
addresses = {'intersects': 0x1006f6e78, 'contains': 0x1006f7644,
             'translate': 0x1006f6720, 'clip_x': 0x1006f6c08,
             'clip_y': 0x1006f6cd8, 'clip_z': 0x1006f6da8}
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
uc.mem_map(0x1006f6000, 0x2000)
uc.mem_write(0x1006f6000, m.read(0x1006f6000, 0x2000))
uc.mem_map(0x100fc6000, 0x1000)
# The referenced zero vector is in zero-fill storage, not file-backed bytes.
zero_section = next(s for s in m.sections if s['va'] <= 0x100fc6244 and 0x100fc6250 <= s['va'] + s['size'])
assert (zero_section['flags'] & 0xff) in (1, 12), 'Expected zero-fill section'
base, stop = 0x70000000, 0x71000000
uc.mem_map(base, 0x10000)
uc.mem_map(stop, 0x1000)
disassembler = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
evidence = {'executable_sha256': expected, 'input_is_patched_ipa': True,
            'zero_vector_assumption': 'Image-initial zero-fill at 0x100fc6244; no application startup executed.',
            'routines': {}}
for name, address in addresses.items():
    length = starts[starts.index(address) + 1] - address
    code = m.read(address, length)
    evidence['routines'][name] = {
        'address': hex(address), 'bytes': code.hex(),
        'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in disassembler.disasm(code, address)],
    }

def bits(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]

def write_values(address, values):
    uc.mem_write(address, struct.pack('<' + 'f' * len(values), *values))

def run(name, a, b, vector, desired, mode):
    write_values(base, a)
    write_values(base + 0x100, vector if name in ('contains', 'translate') else b)
    uc.reg_write(UC_ARM64_REG_X0, base)
    uc.reg_write(UC_ARM64_REG_X1, base + 0x100)
    uc.reg_write(UC_ARM64_REG_X8, base + 0x200)
    uc.reg_write(UC_ARM64_REG_W2, mode)
    uc.reg_write(UC_ARM64_REG_S0, bits(desired))
    uc.reg_write(UC_ARM64_REG_SP, base + 0xf000)
    uc.reg_write(UC_ARM64_REG_LR, stop)
    uc.emu_start(addresses[name], stop, count=128)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop, name
    assert uc.reg_read(UC_ARM64_REG_SP) == base + 0xf000, 'Unbalanced stack'
    if name == 'translate':
        data = bytes(uc.mem_read(base + 0x200, 25))
        return {'bits': list(struct.unpack('<6I', data[:24])), 'zero_flag': data[24]}
    return uc.reg_read(UC_ARM64_REG_W0 if name in ('intersects', 'contains') else UC_ARM64_REG_S0)

rng = random.Random(151002)
def box():
    minimum = [rng.uniform(-20, 20) for _ in range(3)]
    return minimum + [minimum[i] + rng.uniform(0, 10) for i in range(3)]

inputs = []
for axis in range(3):
    for gap in [-2, -1, 0, 0.5, 1, 2]:
        a, b = [0, 0, 0, 1, 1, 1], [0, 0, 0, 1, 1, 1]
        b[axis], b[axis + 3] = gap, gap + 1
        for delta in [-3, -0.25, 0, 0.25, 3]:
            for mode in [0, 1]:
                inputs.append((a, b.copy(), [gap, 0.5, 0.5], delta, mode))
for point in [[0, 0, 0], [1, 1, 1], [0.5, 0.5, 0.5], [-1, 0, 0]]:
    inputs.append(([0, 0, 0, 1, 1, 1], [0, 0, 0, 1, 1, 1], point, 1, 0))
inputs.append(([0] * 6, [0] * 6, [0, 0, 0], 0, 0))
for _ in range(1200):
    inputs.append((box(), box(), [rng.uniform(-25, 25) for _ in range(3)], rng.uniform(-30, 30), rng.randrange(2)))
cases = []
for a, b, vector, desired, mode in inputs:
    cases.append({'a': a, 'b': b, 'vector': vector, 'desired': desired, 'mode': mode,
                  'expected': {name: run(name, a, b, vector, desired, mode) for name in addresses}})
(OUT / 'geometry-reference.json').write_text(json.dumps({'cases': cases, 'domain': 'finite float32 inputs'}, indent=2) + '\n')
(OUT / 'geometry-evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
print(f'ARM64 geometry reference: {len(cases)} cases across {len(addresses)} routines')
