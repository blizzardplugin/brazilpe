"""Execute both original state-filtering chunk providers; substitute their virtual source only."""
import json
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR
from native_image import load_image

image, digest = load_image(); uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for page in [0x100673000, 0x10067b000]:
    uc.mem_map(page, 4096); uc.mem_write(page, image.read(page, 4096))
base, stop, callback, chunk = 0x70000000, 0x71000000, 0x72000000, 0x70002000
uc.mem_map(base, 0x10000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096)
uc.mem_write(base, struct.pack('<Q', base + 0x100)); uc.mem_write(base + 0x110, struct.pack('<Q', callback))
present = True
def source(machine, pc, size, user):
    machine.reg_write(UC_ARM64_REG_X0, chunk if present else 0)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
uc.hook_add(UC_HOOK_CODE, source, begin=callback, end=callback)
cases = []
for mode, address in [(0, 0x100673638), (1, 0x10067301c)]:
    for state in range(256):
        for provided in [False, True]:
            present = provided; uc.mem_write(chunk + 0x78, bytes([state]))
            for reg, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x1000),
                (UC_ARM64_REG_SP, base + 0xf000), (UC_ARM64_REG_LR, stop)]: uc.reg_write(reg, value)
            uc.emu_start(address, stop, count=100)
            assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0xf000
            result = uc.reg_read(UC_ARM64_REG_X0); assert result in (0, chunk)
            cases.append({'mode': mode, 'state': state, 'present': provided, 'available': int(result == chunk)})
output = Path(__file__).with_name('provider-reference.json')
output.write_text(json.dumps({'cases': cases, 'executable_sha256': digest,
    'state_offset': '0x78', 'source_slot': '0x10', 'limitation': 'Virtual source substituted; atomic acquire ordering/concurrent transitions not modeled.'}, indent=2) + '\n')
print(f'Original providers: {len(cases)} combinations')
