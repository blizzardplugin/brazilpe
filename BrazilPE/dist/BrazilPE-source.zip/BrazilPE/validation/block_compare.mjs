import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url);
const reference = JSON.parse(await readFile(new URL('block-reference.json', root), 'utf8'));
const { instance } = await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {});
const api = instance.exports;
const data = new Float32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const bits = new Uint32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const position = new Int32Array(api.memory.buffer, api.brazilpe_block_position(), 3);
let accepted = 0;
for (const [index, entry] of reference.cases.entries()) {
  data.fill(0); data.set(entry.shape, 0); data.set(entry.query, 8); data[24] = entry.flag; position.set(entry.position);
  assert.equal(api.brazilpe_block_collect(entry.enabled), entry.expected.accepted, `case ${index}: accepted`);
  if (entry.expected.accepted) {
    assert.deepEqual(Array.from(bits.slice(16, 22)), entry.expected.box_bits, `case ${index}: translated box`);
    assert.equal(data[25], entry.expected.flag); accepted++;
  }
}
data[0] = NaN; assert.equal(api.brazilpe_block_collect(1), -1);
const result = { cases: reference.cases.length, accepted, failed: 0,
  method: 'Real native collector and virtual methods vs reconstructed Wasm; metadata lookup only substituted',
  scope: 'Base block path plus air collector; subclass shapes and native allocator not validated' };
await writeFile(new URL('block-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
