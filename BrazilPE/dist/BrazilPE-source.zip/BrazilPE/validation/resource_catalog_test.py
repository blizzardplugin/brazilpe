import unittest
from resource_catalog import parse_jsonc

class JsoncTests(unittest.TestCase):
    def test_comments_and_trailing_commas_preserve_strings(self):
        self.assertEqual(parse_jsonc('{/*x*/"url":"https://host/a//b", "escaped":"\\\"/*keep*/",//line\n"list":[1,2,],}'),
                         {'url': 'https://host/a//b', 'escaped': '"/*keep*/', 'list': [1, 2]})
    def test_unterminated_comment_rejected(self):
        with self.assertRaises(ValueError): parse_jsonc('{/*broken')
    def test_invalid_json_rejected(self):
        with self.assertRaises(ValueError): parse_jsonc('{"a":NaN, trailing}')
        with self.assertRaises(ValueError): parse_jsonc('{"a":NaN}')
if __name__ == '__main__': unittest.main()
