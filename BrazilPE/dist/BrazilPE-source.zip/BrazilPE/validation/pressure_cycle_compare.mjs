import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {World} from '../public/game/world.js';
import {PressureSystem} from '../public/game/pressure.js';
import {BLOCKS} from '../public/game/config.js';
const reference=JSON.parse(await readFile(new URL('pressure-cycle-reference.json',import.meta.url),'utf8'));
const module=await WebAssembly.compile(await readFile(new URL('../public/core.wasm',import.meta.url)));
let frames=0;
for(const scenario of reference.cases){
 const world=new World(),palette=BLOCKS.findIndex(block=>block.pressureId===scenario.id);
 assert(world.set(8,3,8,palette));
 const system=new PressureSystem(world,()=>new WebAssembly.Instance(module,{}).exports);
 for(const expected of scenario.sequence){
  system.events.length=0;
  if(expected.available)world.unavailableChunks.delete('1,1');else world.unavailableChunks.add('1,1');
  system.step(expected.actors);
  assert.equal(world.getMetadata(8,3,8),expected.metadata,`${scenario.id}/${scenario.variant}/${frames} metadata`);
  assert.equal(world.signalAt(8,3,8),expected.signal);
  assert.equal(system.tick,expected.tick);
  const state=system.states.get('8,3,8'),data=new DataView(state.api.memory.buffer),base=state.api.brazilpe_scheduler_buffer();
  const deadlines=Array.from({length:state.api.brazilpe_scheduler_count()},(_,i)=>Number(data.getBigUint64(base+i*24+16,true)));
  assert.deepEqual(deadlines,expected.deadlines);
  const events=system.events.map(event=>({kind:event.kind,value:event.kind===1?event.signal:event.kind===2?event.metadata:event.kind===3?event.soundPayload:state.delay}));
  assert.deepEqual(events,expected.events);frames++;
 }
 system.dispose();
}
const result={cycles:reference.cases.length,frames,failed:0,limitations:reference.limitations};
await writeFile(new URL('pressure-cycle-result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
