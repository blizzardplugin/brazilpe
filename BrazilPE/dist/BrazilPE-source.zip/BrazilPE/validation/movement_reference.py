"""Execute the native caller; substitute only its world obstacle query."""
import hashlib
import json
import random
import struct
import sys
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (
    UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2,
    UC_ARM64_REG_X19, UC_ARM64_REG_X26, UC_ARM64_REG_LR,
    UC_ARM64_REG_SP, UC_ARM64_REG_PC,
)

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.macho import MachO
OUT = Path(__file__).resolve().parent
from native_image import load_image, function_starts
m, expected_hash = load_image()
starts = function_starts(m)
caller, query, stop = 0x1002bd860, 0x1005dce10, 0x71000000
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for page, size in [(0x1002bd000, 4096), (0x1006f6000, 8192)]:
    uc.mem_map(page, size)
    uc.mem_write(page, m.read(page, size))
uc.mem_map(0x1005dc000, 4096)
uc.mem_map(0x100fc6000, 4096)
uc.mem_map(stop, 4096)
base = 0x70000000
uc.mem_map(base, 0x20000)
request, vector_header, obstacle_base = base + 0x1000, base + 0x2000, base + 0x3000
stack = base + 0x1f000
query_boxes = []

def world_query(machine, address, size, user):
    query_boxes.append(list(struct.unpack('<6I', bytes(machine.mem_read(machine.reg_read(UC_ARM64_REG_X2), 24)))))
    machine.reg_write(UC_ARM64_REG_X0, vector_header)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))

uc.hook_add(UC_HOOK_CODE, world_query, begin=query, end=query)

def write_floats(address, values):
    uc.mem_write(address, struct.pack('<' + 'f' * len(values), *values))

def output_bits(address, count):
    return list(struct.unpack('<' + 'I' * count, bytes(uc.mem_read(address, count * 4))))

def execute(entry):
    uc.mem_write(base, bytes(512))
    write_floats(base + 0xd0, entry['box'])
    write_floats(base + 0xa8, entry['velocity'])
    write_floats(request, entry['desired'])
    uc.mem_write(base + 0xcc, bytes([entry['no_collision'], entry['ground']]))
    uc.mem_write(base + 0xa0, struct.pack('<Q', base + 0x800))
    for index, box in enumerate(entry['obstacles']):
        write_floats(obstacle_base + index * 28, box)
        uc.mem_write(obstacle_base + index * 28 + 24, bytes(4))
    end = obstacle_base + len(entry['obstacles']) * 28
    uc.mem_write(vector_header, struct.pack('<QQQ', obstacle_base, end, end))
    query_boxes.clear()
    uc.reg_write(UC_ARM64_REG_X0, base)
    uc.reg_write(UC_ARM64_REG_X1, request)
    uc.reg_write(UC_ARM64_REG_X19, 0x12345678)
    uc.reg_write(UC_ARM64_REG_X26, 0x23456789)
    uc.reg_write(UC_ARM64_REG_SP, stack)
    uc.reg_write(UC_ARM64_REG_LR, stop)
    uc.emu_start(caller, stop, count=100000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop
    assert uc.reg_read(UC_ARM64_REG_SP) == stack
    assert uc.reg_read(UC_ARM64_REG_X19) == 0x12345678
    assert uc.reg_read(UC_ARM64_REG_X26) == 0x23456789
    assert len(query_boxes) == (0 if entry['no_collision'] else 1)
    return {'box': output_bits(base + 0xd0, 6), 'position': output_bits(base + 0xb4, 3),
            'velocity': output_bits(base + 0xa8, 3), 'ground': uc.mem_read(base + 0xcd, 1)[0],
            'allowed': output_bits(request if entry['no_collision'] else stack - 0x60, 3),
            'query_boxes': query_boxes.copy()}

entity = [-0.3, 0, -0.3, 0.3, 1.8, 0.3]
floor = [-8, -1, -8, 8, 0, 8]
wall_x = [1, 0, -4, 2, 4, 4]
wall_z = [-4, 0, 1, 4, 4, 2]
entries = []
for name, obstacles, desired in [
    ('free', [], [1, -0.2, 0.4]), ('floor', [floor], [1, -0.2, 0]),
    ('wall', [wall_x], [2, 0, 0]), ('corner', [floor, wall_x, wall_z], [2, -0.2, 2]),
    ('corner-reversed', [wall_z, wall_x, floor], [2, -0.2, 2]),
    ('upward', [floor], [0, 1, 0]), ('zero', [floor], [0, 0, 0]),
    ('initial-penetration', [[-0.2, 0, -0.2, 0.5, 1, 0.5]], [0.2, 0.2, 0.2]),
]:
    for bypass in [0, 1]:
        entries.append({'name': name, 'box': entity, 'velocity': [0.3, -0.7, 0.4],
                        'desired': desired, 'obstacles': obstacles, 'no_collision': bypass, 'ground': 1})
entries.append({'name': '64-obstacles', 'box': entity, 'velocity': [1, 2, 3],
                'desired': [2, -0.1, 2], 'obstacles': [floor, wall_x, wall_z] * 21 + [floor],
                'no_collision': 0, 'ground': 0})
rng = random.Random(151003)
for index in range(500):
    minimum = [rng.uniform(-4, 4) for _ in range(3)]
    box = minimum + [minimum[i] + rng.uniform(0, 2) for i in range(3)]
    obstacles = []
    for _ in range(rng.randrange(9)):
        low = [minimum[i] + rng.uniform(-3, 3) for i in range(3)]
        obstacles.append(low + [low[i] + rng.uniform(0.1, 3) for i in range(3)])
    entries.append({'name': f'random-{index}', 'box': box, 'obstacles': obstacles,
                    'velocity': [rng.uniform(-2, 2) for _ in range(3)],
                    'desired': [rng.uniform(-3, 3) for _ in range(3)],
                    'no_collision': int(index % 17 == 0), 'ground': index % 2})
for entry in entries:
    entry['expected'] = execute(entry)
(OUT / 'movement-reference.json').write_text(json.dumps({'cases': entries}, indent=2) + '\n')
evidence = {'executable_sha256': expected_hash, 'caller': hex(caller), 'axis_order': ['Y', 'X', 'Z'],
            'world_query_stub': hex(query), 'obstacle_stride_bytes': 28,
            'limitations': ['World query replaced by supplied candidate list.',
                           'Zero-fill global vector assumed at image initialization.',
                           'No chunk, block or entity system initialized.'], 'routines': {}}
cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
for address in [caller, 0x1006f6560, 0x1006f7428, 0x1006f748c, 0x1006f7618]:
    code = m.read(address, starts[starts.index(address) + 1] - address)
    evidence['routines'][hex(address)] = {'bytes': code.hex(),
        'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
(OUT / 'movement-evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
print(f'Native movement caller executed: {len(entries)} scenarios; world query substituted only')
