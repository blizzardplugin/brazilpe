"""Verify constructor parameter flow and produce the four pressure profiles."""
import bisect
import json
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from native_image import load_image, function_starts
image, digest = load_image(); starts = function_starts(image); cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
root = Path(__file__).resolve().parents[1]
bindings = json.loads((root / 'validation/registry-bindings.json').read_text())
if bindings['executable_sha256'] != digest: raise ValueError('Parameter binding image mismatch')
def disassemble(address):
    return list(cs.disasm(image.read(address, starts[bisect.bisect_right(starts, address)] - address), address))
profiles = []
for record in bindings['bindings']:
    if record['id'] not in (70, 72, 147, 148): continue
    helper = disassemble(int(record['helper'], 16)); ctor = disassemble(int(record['constructor'], 16))
    # In all three creation helpers X3 is retained in X22, dereferenced into W4.
    if not any(i.mnemonic == 'mov' and i.op_str == 'x22, x3' for i in helper) or not any(i.mnemonic == 'ldr' and i.op_str == 'w4, [x22]' for i in helper):
        raise ValueError('Unproved parameter forwarding')
    if not any(i.mnemonic == 'mov' and i.op_str == 'x20, x4' for i in ctor) and not any(i.mnemonic == 'mov' and i.op_str == 'w20, w4' for i in ctor):
        # Normal constructor directly preserves W4 around base construction in W19.
        if not any(i.mnemonic == 'mov' and i.op_str in ('w19, w4', 'x19, x4') for i in ctor):
            raise ValueError('Unproved constructor argument preservation')
    stores = [i for i in ctor if i.mnemonic == 'str' and '#0xb8]' in i.op_str]
    if len(stores) != 1: raise ValueError('Unproved parameter field write')
    parameter = record['pressure_parameter']; weighted = int(record['id'] >= 147)
    if weighted and parameter < 1 or not weighted and parameter not in (0, 1, 2): raise ValueError('Invalid native pressure parameter')
    profiles.append({'id': record['id'], 'name': record['name'], 'parameter': parameter,
        'weighted': weighted, 'variant': 0 if weighted else parameter, 'capacity': parameter if weighted else 1,
        'delay': 10 if weighted else 20, 'constructor': record['constructor'], 'parameter_store': hex(stores[0].address)})
(root / 'public/pressure-profiles.json').write_text(json.dumps({'executable_sha256': digest, 'profiles': profiles,
    'scope': 'Initializer arguments observed with callees modeled; helper and constructor flow verified statically.'}, indent=2) + '\n')
(root / 'src/pressure_profiles.h').write_text('/* Generated from verified initializer/helper/constructor parameter flow. */\n'
    'static const struct { int id, weighted, variant, capacity; } pressure_profiles[] = {\n' +
    ''.join(f'    {{{r["id"]}, {r["weighted"]}, {r["variant"]}, {r["capacity"]}}},\n' for r in profiles) + '};\n')
print('Verified profiles:', [(p['id'], p['parameter']) for p in profiles])
