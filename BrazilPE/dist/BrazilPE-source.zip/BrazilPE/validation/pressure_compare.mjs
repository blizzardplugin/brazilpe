import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const reference = JSON.parse(await readFile(new URL('pressure-reference.json', import.meta.url), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', import.meta.url)), {})).instance.exports;
let comparisons = 0;
for (const entry of reference.cases) {
  assert.equal(api.brazilpe_pressure_signal(entry.weighted, entry.eligible, entry.weighted ? entry.variant : 1), entry.expected, JSON.stringify(entry));
  comparisons++;
}
for (const entry of reference.scalar) {
  assert.equal(api.brazilpe_pressure_decode(entry.weighted, entry.value), entry.decode);
  assert.equal(api.brazilpe_pressure_encode(entry.weighted, entry.value), entry.encode);
  comparisons += 2;
}
for (let weighted = 0; weighted < 2; weighted++) {
  assert.equal(api.brazilpe_pressure_delay(weighted), reference.delays[weighted]); comparisons++;
}
for (const args of [[-1,1,15], [2,1,15], [1,-1,15], [1,4097,15], [1,1,0], [1,1,4097]])
  assert.equal(api.brazilpe_pressure_signal(...args), -1);
for (const name of ['decode', 'encode']) for (const args of [[2,0],[0,-1],[1,16]])
  assert.equal(api[`brazilpe_pressure_${name}`](...args), -1);
assert.equal(api.brazilpe_pressure_delay(2), -1);
const result = { comparisons, failed: 0, scope: 'Signal computation on supplied query results; full pressure-plate gameplay pending' };
await writeFile(new URL('pressure-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
