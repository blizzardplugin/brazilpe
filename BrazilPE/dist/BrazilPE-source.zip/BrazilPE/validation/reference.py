"""Generate independent reference cases by executing the shipped ARM64 code."""
import hashlib
import json
import random
import struct
import sys
from pathlib import Path

from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_LR, UC_ARM64_REG_S0, UC_ARM64_REG_W0, UC_ARM64_REG_PC

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.macho import MachO

OUT = Path(__file__).resolve().parent
from native_image import load_image
m, EXPECTED_HASH = load_image()
addresses = {'shadow': 0x1004e4b64, 'margin': 0x1004e4cbc, 'type': 0x1002cb9cc}
expected = {
    'shadow': '00d440bd01102c1e0008211ec0035fd6',
    'margin': '083800d000154bbdc0035fd6',
    'type': 'e0278052c0035fd6',
}
for name, hex_bytes in expected.items():
    assert m.read(addresses[name], len(bytes.fromhex(hex_bytes))).hex() == hex_bytes

uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
pages = set()
for addr in [*addresses.values(), 0x100be6b14]:
    page = addr & ~4095
    if page not in pages:
        uc.mem_map(page, 4096)
        uc.mem_write(page, m.read(page, 4096))
        pages.add(page)
actor, stop = 0x70000000, 0x71000000
uc.mem_map(actor, 4096)
uc.mem_map(stop, 4096)

def execute(name):
    uc.reg_write(UC_ARM64_REG_X0, actor)
    uc.reg_write(UC_ARM64_REG_LR, stop)
    uc.emu_start(addresses[name], stop, count=16)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop, 'Routine did not return within the instruction bound'
    return uc.reg_read(UC_ARM64_REG_W0 if name == 'type' else UC_ARM64_REG_S0)

def as_bits(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]

rng = random.Random(1510)
inputs = [0, 0x80000000, 1, 2, 3, 0x007fffff, 0x00800000, 0x7f7fffff,
          0x7f800000, 0xff800000, as_bits(0.6), as_bits(1), as_bits(-1)]
inputs.extend(as_bits(rng.uniform(-10000, 10000)) for _ in range(1024))
cases = []
for bits in inputs:
    uc.mem_write(actor + 0xd4, struct.pack('<I', bits))
    cases.append({'input_bits': bits, 'expected_bits': execute('shadow')})
reference = {'cases': cases, 'margin_bits': execute('margin'), 'player_type': execute('type')}
(OUT / 'arm64-reference.json').write_text(json.dumps(reference, indent=2) + '\n')
(OUT / 'evidence.json').write_text(json.dumps({
    'executable_sha256': EXPECTED_HASH,
    'input_is_patched_ipa': True,
    'functions': {name: {'address': hex(addresses[name]), 'bytes': expected[name]} for name in addresses},
    'margin_constant_bytes': m.read(0x100be6b14, 4).hex(),
    'shadow_input_field_offset': '0xd4',
    'field_semantics': 'Unknown; field name is not recoverable from these instructions.',
    'method': 'Original ARM64 instructions executed in Unicorn; no iOS execution.',
}, indent=2) + '\n')
print(f'ARM64 reference generated: {len(cases)} shadow cases + margin + type')
