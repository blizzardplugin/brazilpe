"""Run original world traversal plus actual base block collectors.
Only their virtual chunk source is replaced; availability expansion is disabled (w4=0).
"""
import json
import random
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2,
    UC_ARM64_REG_X3, UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_X8,
    UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR)
from native_image import load_image

OUT = Path(__file__).resolve().parent
image, digest = load_image()
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for segment in image.segments:
    if not segment['va'] or not segment['vs']: continue
    uc.mem_map(segment['va'], (segment['vs'] + 4095) & ~4095)
    if segment['fs']: uc.mem_write(segment['va'], image.raw[segment['fo']:segment['fo'] + segment['fs']])
base, stop = 0x70000000, 0x71000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096)
source_callback = 0x72000000
uc.mem_map(source_callback, 4096)
uc.mem_write(base + 0x800, struct.pack('<Q', base + 0x900))
uc.mem_write(base + 0x910, struct.pack('<Q', source_callback))
chunk_arena = 0x74000000
uc.mem_map(chunk_arena, 16 * 0x10000)
SHAPES = [[0, 0, 0, 1, 1, 1], [0, 0, 0, 1, 0.5, 1]]
for id in [0, 1, 2]:
    block = base + 0x1000 + id * 0x200
    uc.mem_write(block, struct.pack('<Q', 0x100e89628 if id == 0 else 0x100e8ac00))
    if id: uc.mem_write(block + 0x84, struct.pack('<6f', *SHAPES[id - 1]) + bytes(4))
    uc.mem_write(0x100fc4680 + id * 8, struct.pack('<Q', block))
chunks = {}
def provider(machine, pc, size, user):
    coordinate = struct.unpack('<2i', bytes(machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 8)))
    machine.reg_write(UC_ARM64_REG_X0, chunks.get(coordinate, 0))
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
def unexpected_growth(machine, pc, size, user): raise AssertionError('Fixture exceeded native vector capacity')
uc.hook_add(UC_HOOK_CODE, provider, begin=source_callback, end=source_callback)
uc.hook_add(UC_HOOK_CODE, unexpected_growth, begin=0x1004e8d18, end=0x1004e8d18)
query, output = base + 0x2000, base + 0x3000
def execute(entry):
    chunks.clear()
    for x, y, z, id in entry['cells']:
        if not 0 <= y < 128: continue
        pair = (x >> 4, z >> 4)
        if pair not in chunks:
            assert len(chunks) < 16
            chunk = chunk_arena + len(chunks) * 0x10000
            uc.mem_write(chunk, bytes(0x10000)); uc.mem_write(chunk + 0x28, struct.pack('<2i', *pair))
            uc.mem_write(chunk + 0x78, bytes([4]))
            chunks[pair] = chunk
        index = y + (((x & 15) * 16 + (z & 15)) * 128)
        uc.mem_write(chunks[pair] + 0xa88 + index, bytes([id]))
    uc.mem_write(base, bytes(256))
    uc.mem_write(base + 0x20, struct.pack('<Q', base + 0x800))
    uc.mem_write(base + 0x80, struct.pack('<3Q', output, output, output + 256 * 28))
    uc.mem_write(query, struct.pack('<6f', *entry['query']) + bytes(8))
    for reg, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base), (UC_ARM64_REG_X2, query),
        (UC_ARM64_REG_X3, 0), (UC_ARM64_REG_X4, 0), (UC_ARM64_REG_X5, 0),
        (UC_ARM64_REG_SP, base + 0x1f000), (UC_ARM64_REG_LR, stop)]: uc.reg_write(reg, value)
    uc.emu_start(0x1005dce10, stop, count=300000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
    assert uc.reg_read(UC_ARM64_REG_X0) == base + 0x80
    end = struct.unpack('<Q', bytes(uc.mem_read(base + 0x88, 8)))[0]
    assert end >= output and end - output <= 256 * 28 and (end - output) % 28 == 0
    return [{'bits': list(struct.unpack('<6I', bytes(uc.mem_read(p, 24)))), 'flag': uc.mem_read(p + 24, 1)[0]} for p in range(output, end, 28)]
rng = random.Random(151006)
entries = [{'query': [-0.2, -0.2, -0.2, 2.2, 2.2, 2.2], 'cells': [[0, 0, 0, 1], [1, 0, 0, 2], [3, 0, 0, 1]]},
           {'query': [1, 0, 0, 2, 1, 1], 'cells': [[0, 0, 0, 1]]},
           {'query': [0, 0.5, 0, 1, 1, 1], 'cells': [[0, 0, 0, 2]]}]
for _ in range(120):
    origin = [rng.randrange(-8, 9) for _ in range(3)]
    query_min = [origin[i] + rng.uniform(-1, 1) for i in range(3)]
    mapping = {}
    for _ in range(25):
        coordinate = tuple(origin[i] + rng.randrange(-2, 4) for i in range(3)); mapping[coordinate] = rng.choice([1, 2])
    entries.append({'query': query_min + [query_min[i] + rng.uniform(0.1, 3) for i in range(3)],
        'cells': [list(coordinate) + [id] for coordinate, id in mapping.items()]})
for entry in entries: entry['expected'] = execute(entry)
(OUT / 'block-world-reference.json').write_text(json.dumps({'cases': entries, 'shapes': SHAPES}, indent=2) + '\n')
(OUT / 'block-world-evidence.json').write_text(json.dumps({
    'executable_sha256': digest, 'query': '0x1005dce10', 'collector': '0x10060ff60',
    'native_callbacks_reconstructed': ['slot 0x18', 'slot 0x40', 'slot 0x2d8', 'slot 0x2e0'],
    'substituted': ['Virtual chunk source, slot 0x10'],
    'native_providers_executed': ['0x100673638', '0x10067b6c0'],
    'native_storage_executed': ['0x1005d9f4c', '0x1005da064', '0x1005e0934', '0x1005e09b0', '0x10067b990'],
    'disabled': ['Chunk checks (w4=0)', 'Auxiliary per-block output (x3=null)'],
    'fixture_ids': '0=air path, 1=base cube, 2=base supplied partial shape; not original game IDs',
    'vector_capacity': 256,
}, indent=2) + '\n')
print(f'Native world + base collectors: {len(entries)} regions; {sum(len(e["expected"]) for e in entries)} boxes')
