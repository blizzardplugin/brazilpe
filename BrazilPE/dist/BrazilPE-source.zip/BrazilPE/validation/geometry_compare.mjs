import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { scenario } from '../public/geometry.js';
const root = new URL('./', import.meta.url);
const reference = JSON.parse(await readFile(new URL('geometry-reference.json', root), 'utf8'));
const { instance } = await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {});
const api = instance.exports;
assert.throws(() => scenario(api, Infinity, 1), /inválida/);
assert.throws(() => scenario(api, 0, NaN), /inválida/);
assert.throws(() => scenario(api, 1e100, 1), /inválida/);
const memory = new Float32Array(api.memory.buffer, api.brazilpe_geometry_buffer(), 32);
const integers = new Uint32Array(api.memory.buffer, api.brazilpe_geometry_buffer(), 32);
const temp = new DataView(new ArrayBuffer(4));
function floatBits(value) { temp.setFloat32(0, value, true); return temp.getUint32(0, true); }
let comparisons = 0;
for (const [index, entry] of reference.cases.entries()) {
  memory.set(entry.a, 0); memory.set(entry.b, 8); memory.set(entry.vector, 16);
  for (const name of ['intersects', 'contains']) {
    assert.equal(api[`brazilpe_aabb_${name}`](), entry.expected[name], `case ${index}: ${name}`);
    comparisons++;
  }
  api.brazilpe_aabb_translate();
  assert.deepEqual(Array.from(integers.slice(24, 30)), entry.expected.translate.bits, `case ${index}: translated coords`);
  assert.equal(memory[30], entry.expected.translate.zero_flag, `case ${index}: zero flag`);
  comparisons++;
  for (const name of ['clip_x', 'clip_y', 'clip_z']) {
    assert.equal(floatBits(api[`brazilpe_${name}`](entry.desired, entry.mode)), entry.expected[name], `case ${index}: ${name}`);
    comparisons++;
  }
}
const result = { cases: reference.cases.length, comparisons, failed: 0, routines: 6,
  domain: reference.domain, method: 'Original ARM64 instructions in Unicorn vs reconstructed Wasm',
  limitation: 'No proof of integration with game movement; non-finite clipping inputs are outside tested domain.' };
await writeFile(new URL('geometry-result.json', root), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
