import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url);
const reference = JSON.parse(await readFile(new URL('world-reference.json', root), 'utf8'));
const { instance } = await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {});
const api = instance.exports;
const box = new Float32Array(api.memory.buffer, api.brazilpe_query_buffer(), 6);
const ranges = new Int32Array(api.memory.buffer, api.brazilpe_query_ranges(), 6);
let visits = 0;
for (const entry of reference.cases) {
  box.set(entry.box); assert.equal(api.brazilpe_query_bounds(), 1);
  const actual = [];
  for (let x = ranges[0]; x < ranges[3]; x++) {
    for (let z = ranges[2]; z < ranges[5]; z++) {
      for (let y = ranges[1]; y < ranges[4]; y++) actual.push([x, y, z]);
    }
  }
  assert.deepEqual(actual, entry.visited);
  visits += actual.length;
}
box[0] = NaN; assert.equal(api.brazilpe_query_bounds(), 0);
const result = { cases: reference.cases.length, visits, failed: 0,
  scope: 'Native traversal with empty-block callbacks; not original chunk or block shape behavior' };
await writeFile(new URL('world-result.json', root), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
