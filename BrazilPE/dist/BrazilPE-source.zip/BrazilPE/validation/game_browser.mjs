import assert from 'node:assert/strict';
import { writeFile, readFile, mkdtemp, readdir } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { connectPage } from './cdp.mjs';
const cdp = await connectPage(), { command, evaluate, events } = cdp;
const root = new URL('./', import.meta.url); const checks = [];
async function ready() {
  for (let i = 0; i < 100; i++) {
    if (await evaluate('Boolean(window.__brazilpeTest?.metrics.frames > 2)')) return;
    await delay(100);
  }
  throw new Error(`Game did not start: ${await evaluate("document.querySelector('#game-status').textContent")}`);
}
async function click(selector) { await evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`); }
async function importFile(path) {
  const { root: document } = await command('DOM.getDocument');
  const { nodeId } = await command('DOM.querySelector', { nodeId: document.nodeId, selector: '#import-world' });
  await command('DOM.setFileInputFiles', { nodeId, files: [path] }); await delay(250);
}
try {
  await command('Page.enable'); await command('Runtime.enable'); await command('Network.enable');
  await command('Network.setCacheDisabled', { cacheDisabled: true });
  await command('Emulation.setDeviceMetricsOverride', { width: 1280, height: 800, deviceScaleFactor: 1, mobile: false });
  await command('Emulation.setTouchEmulationEnabled', { enabled: false });
  await command('Page.navigate', { url: 'http://127.0.0.1:8080/play.html?test=1' }); await ready();
  const metrics = await evaluate('window.__brazilpeTest.metrics');
  assert.equal(metrics.chunks, 4); assert(metrics.triangles > 100); assert(!metrics.paused); checks.push('Wasm and WebGL render four chunks');
  await evaluate('window.__brazilpeTest.pause(true); window.__brazilpeTest.step({},300)');
  assert(await evaluate('window.__brazilpeTest.player.ground')); checks.push('integrated floor stability');
  await evaluate('window.__brazilpeTest.setPlayer([10,3,10.5],Math.PI/2);window.__brazilpeTest.step({forward:true},180)');
  assert(await evaluate('window.__brazilpeTest.player.position[0]<=14.7001')); checks.push('integrated wall collision');
  await evaluate('window.__brazilpeTest.setPlayer([8.5,3,8.5],0,-0.8);window.__brazilpeTest.pause(false)'); await delay(100);
  await click('#break-block');
  assert.equal(await evaluate('window.__brazilpeTest.world.edits.size'), 1); checks.push('break targeted block');
  await evaluate('document.querySelector("#block-choice").value="5"'); await click('#place-block');
  assert.equal(await evaluate('Array.from(window.__brazilpeTest.world.edits.values())[0][3]'), 5); checks.push('place selected block');
  await click('#break-block');
  await click('#save-world');
  const saved = await evaluate("localStorage.getItem('BrazilPE.web.prototype.v1')");
  const data = JSON.parse(saved); assert.equal(data.format, 'BrazilPE-web-world'); checks.push('save through UI');
  const changed = data.edits[0];
  await evaluate(`window.__brazilpeTest.world.set(${changed[0]},${changed[1]},${changed[2]},5)`);
  await click('#load-world');
  assert.equal(await evaluate(`window.__brazilpeTest.world.get(${changed[0]},${changed[1]},${changed[2]})`), 0); checks.push('load restores edits');
  await evaluate("localStorage.setItem('BrazilPE.web.prototype.v1','{')"); const before = await evaluate('window.__brazilpeTest.snapshot()');
  await click('#load-world');
  assert((await evaluate("document.querySelector('#game-status').textContent")).includes('inválido'));
  assert.equal(JSON.parse(await evaluate('window.__brazilpeTest.snapshot()')).edits.length, JSON.parse(before).edits.length);
  checks.push('corrupt local save rejected');
  await evaluate(`localStorage.setItem('BrazilPE.web.prototype.v1',${JSON.stringify(saved)})`);
  await command('Page.reload'); await ready(); await click('#load-world');
  assert.equal(await evaluate(`window.__brazilpeTest.world.get(${changed[0]},${changed[1]},${changed[2]})`), 0); checks.push('local save survives reload');
  const downloads = await mkdtemp('/tmp/BrazilPE-download-');
  await command('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: downloads });
  await click('#export-world');
  let files = [];
  for (let i = 0; i < 30; i++) { files = (await readdir(downloads)).filter(x => x.endsWith('.json')); if (files.length) break; await delay(100); }
  assert(files.length); assert.equal(JSON.parse(await readFile(`${downloads}/${files[0]}`, 'utf8')).format, 'BrazilPE-web-world'); checks.push('export creates valid world file');
  const imported = JSON.parse(saved); imported.edits.push([9, 3, 9, 4]);
  const importPath = `${downloads}/import.json`; await writeFile(importPath, JSON.stringify(imported)); await importFile(importPath);
  assert.equal(await evaluate('window.__brazilpeTest.world.get(9,3,9)'), 4); checks.push('import restores block edits');
  await writeFile(importPath, '{}'); await importFile(importPath);
  assert((await evaluate("document.querySelector('#game-status').textContent")).includes('incompatível'));
  assert.equal(await evaluate('window.__brazilpeTest.world.get(9,3,9)'), 4); checks.push('bad import leaves world intact');
  await evaluate('window.__brazilpeTest.setPlayer([8.5,3,8.5],0,0);document.querySelector("#world").focus()');
  const initialZ = await evaluate('window.__brazilpeTest.player.position[2]');
  await command('Input.dispatchKeyEvent', { type: 'keyDown', code: 'KeyW', key: 'w', windowsVirtualKeyCode: 87 }); await delay(300);
  await command('Input.dispatchKeyEvent', { type: 'keyUp', code: 'KeyW', key: 'w', windowsVirtualKeyCode: 87 });
  assert(await evaluate(`window.__brazilpeTest.player.position[2]<${initialZ}-0.1`)); checks.push('keyboard moves player through frame loop');
  await command('Input.dispatchKeyEvent', { type: 'keyDown', code: 'Space', key: ' ', windowsVirtualKeyCode: 32 }); await delay(200);
  await command('Input.dispatchKeyEvent', { type: 'keyUp', code: 'Space', key: ' ', windowsVirtualKeyCode: 32 });
  assert(await evaluate('window.__brazilpeTest.player.position[1]>3.3')); checks.push('keyboard jump through frame loop');
  await evaluate('window.__brazilpeTest.setPlayer([8.5,3,8.5],Math.PI/2,-0.15)'); await click('#save-world'); await delay(100);
  const screenshot = await command('Page.captureScreenshot', { format: 'png' });
  await writeFile(new URL('game-desktop.png', root), Buffer.from(screenshot.data, 'base64'));
  await command('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
  await command('Emulation.setTouchEmulationEnabled', { enabled: true });
  assert(await evaluate('document.documentElement.scrollWidth<=window.innerWidth')); checks.push('mobile viewport fits screen');
  await evaluate('window.__brazilpeTest.setPlayer([8.5,3,8.5],0,0)');
  const touch = await evaluate('(()=>{const r=document.querySelector("[data-move=forward]").getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()');
  await command('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ ...touch, id: 1 }] }); await delay(350);
  await command('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  assert(await evaluate('window.__brazilpeTest.player.position[2]<8.4')); checks.push('touch button moves player');
  await command('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: 20, y: 300, id: 2 }] });
  await command('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: 90, y: 300, id: 2 }] });
  await command('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  assert(await evaluate('Math.abs(window.__brazilpeTest.player.yaw)>0.1')); checks.push('touch drag rotates camera');
  await evaluate('window.__brazilpeTest.setPlayer([8.5,3,8.5],Math.PI/2,-0.15)'); await delay(100);
  const mobile = await command('Page.captureScreenshot', { format: 'png' });
  await writeFile(new URL('game-mobile.png', root), Buffer.from(mobile.data, 'base64'));
  assert(await evaluate('Boolean(window.__testContextExtension=window.__brazilpeTest.renderer.gl.getExtension("WEBGL_lose_context"))'));
  await evaluate('window.__testContextExtension.loseContext()'); await delay(150);
  assert(await evaluate('window.__brazilpeTest.metrics.paused')); checks.push('context loss pauses simulation');
  await evaluate('window.__testContextExtension.restoreContext()');
  let restored = false;
  for (let i = 0; i < 50; i++) {
    restored = await evaluate('!window.__brazilpeTest.metrics.paused && document.querySelector("#game-status").textContent.includes("restaurado")');
    if (restored) break; await delay(100);
  }
  assert(restored); checks.push('WebGL context restoration rebuilds renderer');
  assert.equal(events.filter(e => e.method === 'Runtime.exceptionThrown').length, 0); checks.push('no uncaught JavaScript exceptions');
  assert.equal(events.filter(e => e.method === 'Network.responseReceived' && e.params.response.status >= 400 && !e.params.response.url.endsWith('favicon.ico')).length, 0);
  checks.push('required page assets served successfully');
  const result = { passed: checks.length, failed: 0, checks,
    platform: 'Chromium headless with SwiftShader; mobile viewport/touch emulation',
    physicalAndroid: 'not tested', physicalIOS: 'not tested',
    scope: 'New playable web prototype; not complete MCPE port' };
  await writeFile(new URL('game-browser-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
} finally { cdp.close(); }
