"""Extract initializer arguments, not a fully executed runtime registry.
Every direct callee and fluent virtual method is substituted. Only the initializer
instructions execute; factories are observed at their call sites. This is evidence
of declared ID/name arguments, not validation of construction or registration.
"""
import bisect
import json
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR
from native_image import load_image, function_starts

OUT = Path(__file__).resolve().parent
image, digest = load_image(); starts = function_starts(image)
start = 0x10060aa68; end = starts[bisect.bisect_right(starts, start)]
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for segment in image.segments:
    if not segment['va'] or not segment['vs']: continue
    uc.mem_map(segment['va'], (segment['vs'] + 4095) & ~4095)
    if segment['fs']: uc.mem_write(segment['va'], image.raw[segment['fo']:segment['fo'] + segment['fs']])
heap, stop, callback = 0x70000000, 0x71000000, 0x72000000
uc.mem_map(heap, 0x400000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096)
uc.mem_write(heap, struct.pack('<Q', callback) * 128)
allocated = 0
def allocate():
    global allocated
    allocated += 1
    if allocated >= 768: raise ValueError('Initializer model exceeded allocation bound')
    address = heap + 0x1000 + allocated * 0x1000
    uc.mem_write(address, struct.pack('<Q', heap))
    return address
cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
instructions = list(cs.disasm(image.read(start, end - start), start))
calls = {i.address: int(i.op_str[1:], 16) for i in instructions if i.mnemonic == 'bl'}
records, substituted = [], []
def call_site(machine, pc, size, user):
    if pc == callback:
        machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR)); return
    if pc not in calls: return
    target = calls[pc]; x0 = machine.reg_read(UC_ARM64_REG_X0); x1 = machine.reg_read(UC_ARM64_REG_X1)
    if 0x100611148 <= target <= 0x10061bc48 and (target - 0x100611148) % 256 == 0:
        name = bytes(machine.mem_read(x0, 256)).split(b'\0', 1)[0].decode('ascii')
        identifier = struct.unpack('<I', bytes(machine.mem_read(x1, 4)))[0]
        if not 0 <= identifier <= 255: raise ValueError('Unresolved factory identifier')
        if image.read(x0, len(name) + 1) != name.encode('ascii') + b'\0': raise ValueError('Name does not match an original image literal')
        if not name and target != 0x10061bc48: raise ValueError('Unexpected empty declaration name')
        address = allocate(); machine.mem_write(address + 8, bytes([identifier]))
        machine.mem_write(0x100fc4680 + identifier * 8, struct.pack('<Q', address))
        machine.reg_write(UC_ARM64_REG_X0, address)
        records.append({'id': identifier, 'name': name, 'placeholder': not bool(name), 'factory': hex(target), 'site': hex(pc), 'name_address': hex(x0)})
    elif not heap + 0x1000 <= x0 < heap + 0x400000:
        machine.reg_write(UC_ARM64_REG_X0, allocate())
    substituted.append({'site': hex(pc), 'target': hex(target)})
    machine.reg_write(UC_ARM64_REG_PC, pc + 4)
uc.hook_add(UC_HOOK_CODE, call_site)
uc.reg_write(UC_ARM64_REG_SP, heap + 0x3f0000); uc.reg_write(UC_ARM64_REG_LR, stop)
uc.emu_start(start, stop, count=100000)
if uc.reg_read(UC_ARM64_REG_PC) != stop: raise ValueError('Initializer model did not return')
if len(records) != 256 or {r['id'] for r in records} != set(range(256)): raise ValueError('Incomplete declared registry trace')
report = {'executable_sha256': digest, 'initializer': hex(start), 'records': records, 'substituted_calls': substituted,
    'method': 'Execute initializer control flow with all callees/fluent methods modeled; capture original factory arguments.',
    'limitations': ['Not a completed execution of the real initializer.',
        'Synthetic objects populate the modeled registry to allow the declaration path to continue.',
        'Placeholder declarations may be present; 256 arguments do not imply 256 supported gameplay block types.',
        'Runtime overrides, platform branches influenced by real callees, allocation and constructor side effects not validated.']}
(OUT / 'registry-arguments.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'Captured {len(records)} declared ID/name factory arguments; all callees modeled')
