"""Native signal calculation with a supplied entity-query vector.

Query, normal-vector copy, free and entity-type virtual method are substituted.
Actual sensor-box method, loops, arithmetic and metadata methods execute ARM64.
"""
import bisect
import json
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *
from native_image import load_image, function_starts

out = Path(__file__).resolve().parent
image, digest = load_image()
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for seg in image.segments:
    if not seg['va'] or not seg['vs']: continue
    uc.mem_map(seg['va'], (seg['vs'] + 4095) & ~4095)
    if seg['fs']: uc.mem_write(seg['va'], image.raw[seg['fo']:seg['fo'] + seg['fs']])
base, stop, callback = 0x70000000, 0x71000000, 0x72000000
uc.mem_map(base, 0x40000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096)
vector, entries, entity, entity_table = base + 0x1000, base + 0x2000, base + 0x12000, base + 0x18000
uc.mem_write(entity_table + 0x2b0, struct.pack('<Q', callback))
selectors = []
def finish(machine): machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
def hook(machine, pc, size, user):
    if pc in (0x1005dc118, 0x1005dc3ec):
        selectors.append(None if pc == 0x1005dc118 else machine.reg_read(UC_ARM64_REG_W1))
        machine.reg_write(UC_ARM64_REG_X0, vector)
    elif pc == 0x10064d924:
        destination = machine.reg_read(UC_ARM64_REG_X0)
        begin, end = machine.reg_read(UC_ARM64_REG_X1), machine.reg_read(UC_ARM64_REG_X2)
        machine.mem_write(destination, struct.pack('<3Q', begin, end, end))
    elif pc == callback:
        pointer = machine.reg_read(UC_ARM64_REG_X0)
        machine.reg_write(UC_ARM64_REG_W0, struct.unpack('<I', machine.mem_read(pointer + 8, 4))[0])
    finish(machine)
for address in (0x1005dc118, 0x1005dc3ec, 0x10064d924, 0x100be3608, callback):
    uc.hook_add(UC_HOOK_CODE, hook, begin=address, end=address)
def run(address, parameter=0):
    uc.reg_write(UC_ARM64_REG_SP, base + 0x3f000)
    uc.reg_write(UC_ARM64_REG_LR, stop)
    uc.reg_write(UC_ARM64_REG_X0, base)
    uc.reg_write(UC_ARM64_REG_W1, parameter)
    uc.emu_start(address, stop, count=100000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop
    assert uc.reg_read(UC_ARM64_REG_SP) == base + 0x3f000
    return uc.reg_read(UC_ARM64_REG_W0)
def calculate(weighted, variant, types):
    uc.mem_write(base, struct.pack('<Q', 0x100ea48e0 if weighted else 0x100e9b590))
    uc.mem_write(base + 0xb8, struct.pack('<I', variant))
    for index, value in enumerate(types):
        pointer = entity + index * 16
        uc.mem_write(pointer, struct.pack('<QI', entity_table, value))
        uc.mem_write(entries + index * 8, struct.pack('<Q', pointer))
    uc.mem_write(vector, struct.pack('<3Q', entries, entries + len(types) * 8, entries + len(types) * 8))
    uc.mem_write(base + 0x800, struct.pack('<3i', 5, 2, -3))
    uc.reg_write(UC_ARM64_REG_X2, base + 0x800)
    # run() initializes X1, so the query source is supplied as its parameter.
    selectors.clear()
    result = run(0x10065eb88 if weighted else 0x10064d6c4, base + 0x700)
    assert selectors == ([None] if weighted or variant == 0 else [0x100 if variant == 1 else 0x13f])
    return result
cases = []
for weighted in (0, 1):
    for variant in ([0, 1, 2] if weighted == 0 else [1, 2, 3, 7, 15, 16, 31, 150, 255, 4096]):
        for count in sorted(set([0, 1, 2, 3, 7, 14, 15, 16, 31, 149, 150, 151, 255, 256, min(variant, 256)])):
            for excluded in (0, 3):
                types = [0x45] * excluded + [0x13f] * count
                cases.append({'weighted': weighted, 'variant': variant, 'eligible': count,
                              'excluded': excluded, 'expected': calculate(weighted, variant, types)})
scalar = []
for weighted in (0, 1):
    for value in range(16):
        scalar.append({'weighted': weighted, 'value': value,
                       'decode': run(0x10065ec40 if weighted else 0x10064d6b4, value),
                       'encode': run(0x10065ec48 if weighted else 0x10064d6a8, value)})
delays = [run(0x10060643c), run(0x10065ec50)]
(out / 'pressure-reference.json').write_text(json.dumps({'cases': cases, 'scalar': scalar, 'delays': delays}, indent=2) + '\n')
starts = function_starts(image); cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
addresses = [0x10064d6c4, 0x10065eb88, 0x10064d6b4, 0x10064d6a8, 0x10065ec40, 0x10065ec48, 0x10060643c, 0x10065ec50]
routines = {}
for address in addresses:
    code = image.read(address, starts[bisect.bisect_right(starts, address)] - address)
    routines[hex(address)] = {'bytes': code.hex(), 'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
(out / 'pressure-evidence.json').write_text(json.dumps({'executable_sha256': digest, 'routines': routines,
    'limitations': ['Entity queries supplied, not reconstructed; selector arguments checked only.',
        'Normal vector copy, deallocation and entity-type virtual call substituted.',
        'No native registry startup, scheduler, metadata writes or signal propagation.',
        'API count and capacity bounds 4096 are laboratory limits, not recovered game limits.']}, indent=2) + '\n')
print(f'Pressure signals: {len(cases)} native cases; {len(scalar) * 2 + len(delays)} scalar returns')
