"""Execute original world traversal with chunk checks disabled and empty blocks.
Block lookup and block virtual collision dispatch are controlled callbacks.
"""
import json
import random
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (
    UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3,
    UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_X8,
    UC_ARM64_REG_SP, UC_ARM64_REG_LR, UC_ARM64_REG_PC,
)
from native_image import load_image, function_starts

OUT = Path(__file__).resolve().parent
image, digest = load_image()
address, lookup, collision = 0x1005dce10, 0x1005d9f4c, 0x72000000
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
uc.mem_map(0x1005dc000, 0x2000)
uc.mem_write(0x1005dc000, image.read(0x1005dc000, 0x2000))
uc.mem_map(0x1005d9000, 4096)
uc.mem_map(0x100fc4000, 4096)
base, stop = 0x70000000, 0x71000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096); uc.mem_map(collision, 4096)
block, vtable = base + 0x1000, base + 0x2000
uc.mem_write(0x100fc4680, struct.pack('<Q', block))
uc.mem_write(block, struct.pack('<Q', vtable))
uc.mem_write(vtable + 0x48, struct.pack('<Q', collision))
visited, dispatched = [], []

def block_lookup(machine, pc, size, user):
    coordinates = list(struct.unpack('<3i', bytes(machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 12))))
    visited.append(coordinates)
    machine.mem_write(machine.reg_read(UC_ARM64_REG_X8), bytes([0, 0]))
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))

def empty_collision(machine, pc, size, user):
    coordinates = list(struct.unpack('<3i', bytes(machine.mem_read(machine.reg_read(UC_ARM64_REG_X2), 12))))
    dispatched.append(coordinates)
    machine.reg_write(UC_ARM64_REG_X0, 0)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))

uc.hook_add(UC_HOOK_CODE, block_lookup, begin=lookup, end=lookup)
uc.hook_add(UC_HOOK_CODE, empty_collision, begin=collision, end=collision)

def execute(box):
    uc.mem_write(base, bytes(256))
    uc.mem_write(base + 0x3000, struct.pack('<6f', *box) + bytes(8))
    visited.clear(); dispatched.clear()
    for reg, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base),
                       (UC_ARM64_REG_X2, base + 0x3000), (UC_ARM64_REG_X3, 0),
                       (UC_ARM64_REG_X4, 0), (UC_ARM64_REG_X5, 0),
                       (UC_ARM64_REG_SP, base + 0x1f000), (UC_ARM64_REG_LR, stop)]:
        uc.reg_write(reg, value)
    uc.emu_start(address, stop, count=200000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop
    assert uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
    assert visited == dispatched
    return visited.copy()

rng = random.Random(151004)
boxes = [[0, 0, 0, 1, 1, 1], [-1.2, -0.01, -0.6, -0.2, 1.8, 0.4],
         [-16, 0, -16, -15, 2, -15], [0] * 6, [-0.0] * 6]
for _ in range(80):
    low = [rng.uniform(-20, 20) for _ in range(3)]
    boxes.append(low + [low[i] + rng.uniform(0, 3) for i in range(3)])
cases = [{'box': box, 'visited': execute(box)} for box in boxes]
(OUT / 'world-reference.json').write_text(json.dumps({'cases': cases}, indent=2) + '\n')
starts = function_starts(image)
code = image.read(address, starts[starts.index(address) + 1] - address)
(OUT / 'world-evidence.json').write_text(json.dumps({
    'executable_sha256': digest, 'query_address': hex(address), 'bytes': code.hex(),
    'scope': 'Actual integer traversal, with w4=0, x3=null; lookup returns air and collision callback returns false.',
    'limitations': ['Chunk checks disabled.', 'No original block shape implementation executed.',
                    'Does not validate block IDs, storage or original chunk serialization.'],
}, indent=2) + '\n')
print(f'Original world traversal: {len(cases)} boxes; {sum(len(x["visited"]) for x in cases)} block visits')
