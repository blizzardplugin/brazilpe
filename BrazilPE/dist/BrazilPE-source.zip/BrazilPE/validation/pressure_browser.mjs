import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {connectPage} from './cdp.mjs';
const cdp=await connectPage(); const checks=[];
async function ready(){for(let i=0;i<100;i++){if(await cdp.evaluate('Boolean(window.__brazilpeTest?.metrics.frames>2)'))return;await delay(100);}throw new Error('Pressure game not ready');}
async function run(code){return cdp.evaluate(code);}
try{
 await cdp.command('Page.enable');await cdp.command('Runtime.enable');
 await cdp.command('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
 await cdp.command('Page.navigate',{url:'http://127.0.0.1:8080/play.html?test=1'});await ready();
 await run('window.__brazilpeTest.pause(true);window.__brazilpeTest.setPlayer([8.5,3,8.5],0,-1.5)');
 assert(await run("[6,7,8,9].every(id=>Array.from(document.querySelector('#block-choice').options).some(option=>Number(option.value)===id))"));checks.push('Four plates selectable');
 await run("document.querySelector('#block-choice').value='6';window.__brazilpeTest.pause(false);document.querySelector('#place-block').click();window.__brazilpeTest.pause(true);window.__brazilpeTest.step({},1)");
 assert.equal(await run('window.__brazilpeTest.world.get(8,3,8)'),6);assert.equal(await run('window.__brazilpeTest.world.signalAt(8,3,8)'),15);checks.push('UI placement under player activates stone plate');
 assert.equal(await run('window.__brazilpeTest.player.position[1]'),3);checks.push('Plate does not obstruct player');
 await run('window.__brazilpeTest.setPlayer([10.5,3,8.5],0,-1.2);window.__brazilpeTest.step({},65)');
 assert.equal(await run('window.__brazilpeTest.world.getMetadata(8,3,8)'),0);checks.push('Leaving releases plate through frame-loop tick interval');
 await run('window.__brazilpeTest.setPlayer([8.5,3,8.5],0,-1.2);window.__brazilpeTest.step({},1);document.querySelector("#save-world").click()');
 const saved=await run("localStorage.getItem('BrazilPE.web.prototype.v1')");assert.equal(JSON.parse(saved).plateState[0][3],1);checks.push('Pressed state and remaining ticks saved through UI');
 await run('window.__brazilpeTest.world.set(8,3,8,0);document.querySelector("#load-world").click()');
 assert.equal(await run('window.__brazilpeTest.world.get(8,3,8)'),6);assert.equal(await run('window.__brazilpeTest.world.signalAt(8,3,8)'),15);checks.push('Load restores plate and output signal');
 await cdp.command('Page.reload');await ready();await run('window.__brazilpeTest.pause(true);document.querySelector("#load-world").click()');
 assert.equal(await run('window.__brazilpeTest.world.signalAt(8,3,8)'),15);checks.push('Plate save survives browser reload');
 await run('window.__brazilpeTest.world.set(8,2,8,0)');
 assert.equal(await run('window.__brazilpeTest.world.get(8,3,8)'),0);assert.equal(await run('window.__brazilpeTest.pressure.states.size'),0);checks.push('Support removal deletes plate and cancels pending state');
 await run('window.__brazilpeTest.world.set(8,2,8,1);window.__brazilpeTest.world.set(8,3,8,9);window.__brazilpeTest.setPlayer([8.5,3,8.5],0,-1);window.__brazilpeTest.step({},1)');
 assert.equal(await run('window.__brazilpeTest.world.signalAt(8,3,8)'),1);checks.push('Heavy plate uses capacity 150');
 const before=await run('window.__brazilpeTest.snapshot()');const malformed=JSON.parse(before);malformed.plateState[0][4]=999;
 await run(`try{window.__brazilpeTest.restore(${JSON.stringify(JSON.stringify(malformed))})}catch(error){window.pressureValidationError=error.message}`);
 assert((await run('window.pressureValidationError')).includes('placa inválido'));assert.equal(await run('window.__brazilpeTest.snapshot()'),before);checks.push('Invalid plate timer does not replace live world');
 await run('window.__brazilpeTest.world.set(8,3,8,0);window.__brazilpeTest.world.set(10,3,10,6);window.__brazilpeTest.world.set(11,3,10,7);window.__brazilpeTest.world.set(12,3,10,8);window.__brazilpeTest.world.set(13,3,10,9);window.__brazilpeTest.setPlayer([8.5,3,8.5],1.0,-0.45);window.__brazilpeTest.step({},1)');
 await delay(100);
 const screenshot=await cdp.command('Page.captureScreenshot',{format:'png'});
 await writeFile(new URL('../dist/BrazilPE-placas.png',import.meta.url),Buffer.from(screenshot.data,'base64'));
 assert.equal(cdp.events.filter(event=>event.method==='Runtime.exceptionThrown').length,0);checks.push('No uncaught JavaScript exceptions');
 const result={passed:checks.length,failed:0,checks,scope:'Playable web plate lifecycle; native core equivalence validated separately'};
 await writeFile(new URL('pressure-browser-result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{cdp.close();}
