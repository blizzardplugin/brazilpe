import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';

const directory = new URL('./', import.meta.url);
const reference = JSON.parse(await readFile(new URL('arm64-reference.json', directory), 'utf8'));
const bytes = await readFile(new URL('../public/core.wasm', directory));
assert(WebAssembly.validate(bytes));
const { instance } = await WebAssembly.instantiate(bytes, {});
const api = instance.exports;
const buffer = new ArrayBuffer(4);
const view = new DataView(buffer);
function floatFromBits(bits) {
  view.setUint32(0, bits, true);
  return view.getFloat32(0, true);
}
function bitsFromFloat(value) {
  view.setFloat32(0, value, true);
  return view.getUint32(0, true);
}
for (const entry of reference.cases) {
  assert.equal(bitsFromFloat(api.brazilpe_shadow_radius(floatFromBits(entry.input_bits))),
    entry.expected_bits, `ARM64/Wasm mismatch for bits ${entry.input_bits.toString(16)}`);
}
assert.equal(bitsFromFloat(api.brazilpe_original_pick_margin()), reference.margin_bits);
assert.equal(api.brazilpe_player_type(), reference.player_type);
const result = {
  passed: reference.cases.length + 2, failed: 0,
  scope: 'Three reconstructed scalar routines; not the game engine.',
  runtime: process.version, comparison: 'bit-exact ARM64 Unicorn vs WebAssembly',
};
await writeFile(new URL('result.json', directory), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
