"""Native insert/process and heap helpers with region/ID/callback substitutions.
Preallocated vector excludes allocator growth. No reentrant callback scheduling.
"""
import bisect
import json
import random
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from native_image import load_image, function_starts

image, digest = load_image(); uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for seg in image.segments:
    if not seg['va'] or not seg['vs']: continue
    uc.mem_map(seg['va'], (seg['vs'] + 4095) & ~4095)
    if seg['fs']: uc.mem_write(seg['va'], image.raw[seg['fo']:seg['fo'] + seg['fs']])
base, stop, callback = 0x70000000, 0x71000000, 0x72000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096)
queue, pos, block_id, clock, block, table = base + 0x1000, base + 0x3000, base + 0x4000, base + 0x5000, base + 0x6000, base + 0x7000
uc.mem_write(block, struct.pack('<Q', table)); uc.mem_write(table + 0x10, struct.pack('<Q', callback))
for identifier in range(1, 256): uc.mem_write(0x100fc4680 + identifier * 8, struct.pack('<Q', block))
available = True; current_id = 70; callbacks = []
def hook(machine, address, size, user):
    if address == 0x1005d9ddc:
        low = struct.unpack('<3i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 12))
        high = struct.unpack('<3i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X2), 12))
        assert all(b - a == 16 for a, b in zip(low, high))
        machine.reg_write(UC_ARM64_REG_W0, int(available))
    elif address == 0x1005d9f4c:
        machine.mem_write(machine.reg_read(UC_ARM64_REG_X8), bytes([current_id]))
    else:
        position = struct.unpack('<3i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X2), 12))
        callbacks.append({'position': list(position), 'id': current_id,
            'time': struct.unpack('<Q', machine.mem_read(base, 8))[0]})
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
for address in (callback, 0x1005d9ddc, 0x1005d9f4c): uc.hook_add(UC_HOOK_CODE, hook, begin=address, end=address)
def run(address, args):
    uc.reg_write(UC_ARM64_REG_SP, base + 0x1f000); uc.reg_write(UC_ARM64_REG_LR, stop)
    for reg, value in args: uc.reg_write(reg, value)
    uc.emu_start(address, stop, count=100000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
    return uc.reg_read(UC_ARM64_REG_X0)
def state():
    end = struct.unpack('<Q', uc.mem_read(base + 0x10, 8))[0]
    records = []
    for pointer in range(queue, end, 24):
        x, y, z, identifier, deadline = struct.unpack('<3iB3xQ', uc.mem_read(pointer, 24))
        records.append({'position': [x, y, z], 'id': identifier, 'deadline': deadline})
    return records
scenarios = []; rng = random.Random(151010)
for scenario in range(80):
    initial = rng.choice([0, 100, (1 << 32) - 1, (1 << 63), (1 << 64) - 5])
    uc.mem_write(base, struct.pack('<4Q', initial, queue, queue, queue + 128 * 24))
    uc.mem_write(queue, bytes(128 * 24)); operations = []
    for index in range(48):
        callbacks.clear(); available = rng.random() > 0.15; current_id = rng.choice([0, 70, 72])
        if index < 32:
            coordinates = [rng.randint(-20, 20), rng.randint(-8, 130), rng.randint(-20, 20)]
            identifier = rng.choice([0, 70, 72]); delay = rng.choice([-5, -1, 0, 1, 2, 10, 20, 20, 0x7fffffff])
            uc.mem_write(pos, struct.pack('<3i', *coordinates)); uc.mem_write(block_id, bytes([identifier]))
            run(0x1005df614, [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x9000),
                (UC_ARM64_REG_X2, pos), (UC_ARM64_REG_X3, block_id), (UC_ARM64_REG_W4, delay & 0xffffffff)])
            operation = {'kind': 'add', 'position': coordinates, 'id': identifier, 'delay': delay}
        elif 32 <= index < 40:
            queued = state()
            chosen = rng.choice(queued) if queued else {'position': [0, 0, 0], 'id': 70}
            uc.mem_write(pos, struct.pack('<3i', *chosen['position'])); uc.mem_write(block_id, bytes([chosen['id']]))
            run(0x1005df768, [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, pos), (UC_ARM64_REG_X2, block_id)])
            operation = {'kind': 'cancel', 'position': chosen['position'], 'id': chosen['id']}
        else:
            now = (initial + (index - 31) * rng.randint(0, 8)) & ((1 << 64) - 1)
            budget = rng.choice([0, 1, 2, 4, 128]); uc.mem_write(clock, struct.pack('<Q', now))
            result = run(0x1005df794, [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x9000),
                (UC_ARM64_REG_X2, clock), (UC_ARM64_REG_W3, budget), (UC_ARM64_REG_W4, 0)])
            operation = {'kind': 'process', 'now': str(now), 'budget': budget, 'result': result}
        operation.update({'available': int(available), 'current_id': current_id, 'queue': state(), 'callbacks': list(callbacks)})
        # Preserve exact unsigned 64-bit values for JavaScript comparisons.
        for entry in operation['queue']: entry['deadline'] = str(entry['deadline'])
        for entry in operation['callbacks']: entry['time'] = str(entry['time'])
        operations.append(operation)
    scenarios.append({'initial': str(initial), 'operations': operations})
starts = function_starts(image); cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
routines = {}
for address in (0x1005df614, 0x1005df794, 0x1005f77fc, 0x1005f7828, 0x1005e049c, 0x1005e05b4):
    code = image.read(address, starts[bisect.bisect_right(starts, address)] - address)
    routines[hex(address)] = {'bytes': code.hex(), 'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
out = Path(__file__).resolve().parent
(out / 'scheduler-reference.json').write_text(json.dumps({'scenarios': scenarios}, indent=2) + '\n')
(out / 'scheduler-evidence.json').write_text(json.dumps({'executable_sha256': digest, 'routines': routines,
    'limitations': ['Region availability, block-ID lookup and callback destinations substituted.',
        'Vector capacity preallocated; allocator growth not tested.', 'Cancellation, persistence and reentrant callbacks not reconstructed.',
        'Uniform current ID and availability per process call are fixture inputs, not full world storage.']}, indent=2) + '\n')
print(f'Native scheduler: {len(scenarios)} scenarios; {sum(len(s["operations"]) for s in scenarios)} operations')
