import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url), reference = JSON.parse(await readFile(new URL('block-world-reference.json', root), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {})).instance.exports;
const query = new Float32Array(api.memory.buffer, api.brazilpe_query_buffer(), 6);
const ranges = new Int32Array(api.memory.buffer, api.brazilpe_query_ranges(), 6);
const data = new Float32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const bits = new Uint32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const position = new Int32Array(api.memory.buffer, api.brazilpe_block_position(), 3);
let count = 0;
for (const [index, entry] of reference.cases.entries()) {
  query.set(entry.query); assert.equal(api.brazilpe_query_bounds(), 1);
  const cells = new Map(entry.cells.map(c => [c.slice(0, 3).join(','), c[3]]));
  const output = [];
  for (let x = ranges[0]; x < ranges[3]; x++) for (let z = ranges[2]; z < ranges[5]; z++) for (let y = ranges[1]; y < ranges[4]; y++) {
    const id = cells.get([x, y, z].join(',')) ?? 0;
    data.fill(0); data.set(reference.shapes[id ? id - 1 : 0], 0); data.set(entry.query, 8); position.set([x, y, z]);
    const accepted = api.brazilpe_block_collect(Number(id !== 0 && y >= 0 && y < 128)); assert(accepted >= 0);
    if (accepted) output.push({ bits: Array.from(bits.slice(16, 22)), flag: data[25] });
  }
  assert.deepEqual(output, entry.expected, `region ${index}`); count += output.length;
}
const result = { regions: reference.cases.length, boxes: count, failed: 0,
  method: 'Original world traversal + real base collectors vs reconstructed Wasm',
  limitation: 'Virtual chunk source substituted; no original availability-expansion path or subclass-specific block shapes' };
await writeFile(new URL('block-world-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
