import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { World, raycast } from '../public/game/world.js';
import { PressureSystem } from '../public/game/pressure.js';
import { createPlayer, playerBox, stepPlayer } from '../public/game/physics.js';
import { encodeSave, decodeSave } from '../public/game/save.js';
import { chunkMesh } from '../public/game/renderer.js';
const module = await WebAssembly.compile(await readFile(new URL('../public/core.wasm', import.meta.url)));
const createApi = () => new WebAssembly.Instance(module, {}).exports;
const actor = (type = 319, x = 8.5) => ({ type, box: [x - .3, 3, 8.2, x + .3, 4.8, 8.8] });
let checks = 0;
function check(name, action) { action(); checks++; console.log('PASS', name); }
function fixture(id = 6) { const world = new World(); assert(world.set(8, 3, 8, id)); return { world, system: new PressureSystem(world, createApi) }; }
check('four original profile parameters routed from Wasm', () => {
  const api = createApi();
  for (const [id, expected] of [[70,[0,1,1,20]], [72,[0,0,1,20]], [147,[1,0,15,10]], [148,[1,0,150,10]]]) {
    assert.equal(api.brazilpe_pressure_profile(id), 1); assert.deepEqual(Array.from(new Int32Array(api.memory.buffer, api.brazilpe_pressure_profile_values(),4)), expected);
  }
});
check('stone plate activates, stays down, releases on native interval', () => {
  const {world,system} = fixture(); system.step([actor()]); assert.equal(world.signalAt(8,3,8),15); assert.equal(world.getMetadata(8,3,8),1);
  for(let i=0;i<30;i++) system.step([actor()]); assert.equal(system.events.filter(e=>e.kind===3).length,1);
  for(let i=0;i<90;i++) system.step([]); assert.equal(world.signalAt(8,3,8),0); assert.equal(world.getMetadata(8,3,8),0);
  assert.equal(system.states.get('8,3,8').api.brazilpe_scheduler_count(),0); system.dispose();
});
check('type filters and excluded entity cannot activate', () => {
  for(const [id,type,signal] of [[6,1,0],[6,257,15],[7,1,15],[7,69,0],[8,69,0]]) {
    const {world,system}=fixture(id); system.step([actor(type)]); assert.equal(world.signalAt(8,3,8),signal); system.dispose();
  }
});
check('weighted count changes at interval and caps at 15', () => {
  const {world,system}=fixture(8); system.step([actor()]); assert.equal(world.signalAt(8,3,8),1);
  const actors=Array.from({length:16},()=>actor()); for(let i=0;i<30;i++)system.step(actors);
  assert.equal(world.signalAt(8,3,8),15); for(let i=0;i<30;i++)system.step([actor()]); assert.equal(world.signalAt(8,3,8),1); system.dispose();
  const heavy=fixture(9); heavy.system.step(Array.from({length:16},()=>actor())); assert.equal(heavy.world.signalAt(8,3,8),2); heavy.system.dispose();
});
check('exit and reentry before deadline do not duplicate pending tick', () => {
  const {world,system}=fixture(); system.step([actor()]); system.step([]); system.step([actor()]);
  assert.equal(system.states.get('8,3,8').api.brazilpe_scheduler_count(),1); assert.equal(world.signalAt(8,3,8),15); system.dispose();
});
check('unsupported placement rejected and support removal cancels', () => {
  const world=new World(); assert.equal(world.set(8,5,8,6),false);
  const f=fixture(); f.system.step([actor()]); const state=f.system.states.get('8,3,8'); assert(f.world.set(8,2,8,0));
  assert.equal(f.world.get(8,3,8),0); assert.equal(f.world.signalAt(8,3,8),0); assert.equal(state.api.brazilpe_scheduler_count(),0); f.system.dispose();
});
check('unavailable neighbor region blocks scheduling and drops due callback without rewriting', () => {
  const f=fixture(); f.world.unavailableChunks.add('1,1'); f.system.step([actor()]);
  assert.equal(f.world.getMetadata(8,3,8),1); assert.equal(f.system.states.get('8,3,8').api.brazilpe_scheduler_count(),0); f.system.dispose();
  const g=fixture(); g.system.step([actor()]); g.world.unavailableChunks.add('1,1');
  for(let i=0;i<60;i++)g.system.step([]);
  assert.equal(g.world.getMetadata(8,3,8),1); assert.equal(g.system.states.get('8,3,8').api.brazilpe_scheduler_count(),0); g.system.dispose();
});
check('removal and replacement preserve independent plates', () => {
  const f=fixture(); assert(f.world.set(9,3,8,7)); f.system.step([actor(),actor(1,9.5)]);
  const first=f.system.states.get('8,3,8'); assert(f.world.set(8,3,8,9)); assert.equal(first.api.brazilpe_scheduler_count(),0);
  assert.equal(f.world.signalAt(9,3,8),15); f.system.step([actor(),actor(1,9.5)]); assert.equal(f.world.signalAt(8,3,8),1); f.system.dispose();
});
check('plate does not obstruct walking and has thin selection', () => {
  const f=fixture(), api=createApi(), player=createPlayer(); for(let i=0;i<10;i++)stepPlayer(api,f.world,player,{});
  assert.equal(player.position[1],3); assert(player.ground);
  assert.deepEqual(raycast(f.world,[8.5,4.6,8.5],[0,-1,0]).cell,[8,3,8]);
  assert.notDeepEqual(raycast(f.world,[7.5,3.5,8.5],[1,0,0])?.cell,[8,3,8]); f.system.dispose();
});
check('metadata and remaining ticks roundtrip; legacy save accepted', () => {
  const f=fixture(); f.system.step([actor()]); for(let i=0;i<12;i++)f.system.step([]);
  const saved=encodeSave(f.world,createPlayer()), copy=decodeSave(saved); const restored=new PressureSystem(copy.world,createApi);
  assert.equal(copy.world.getMetadata(8,3,8),1); assert.equal(copy.world.signalAt(8,3,8),15);
  for(let i=0;i<48;i++)restored.step([]); assert.equal(copy.world.signalAt(8,3,8),0);
  const legacy=JSON.parse(saved); delete legacy.plateState; assert.equal(decodeSave(JSON.stringify(legacy)).world.getMetadata(8,3,8),0);
  restored.dispose(); f.system.dispose();
});
check('invalid actor and malformed plate save rejected without mutating world', () => {
  const f=fixture(), before=encodeSave(f.world,createPlayer());
  assert.throws(()=>f.system.step([{type:319,box:[NaN,3,8,9,5,9]}]),/inválidos/); assert.equal(encodeSave(f.world,createPlayer()),before);
  const data=JSON.parse(before); data.plateState[0][3]=2; assert.throws(()=>decodeSave(JSON.stringify(data)),/placa inválido/); f.system.dispose();
});
check('mesh preserves thin plate bounds and redraws on state change', () => {
  const f=fixture(); const before=chunkMesh(f.world,f.world.chunks.get('0,0')); f.system.step([actor()]);
  assert(f.world.dirty.has('0,0')); const after=chunkMesh(f.world,f.world.chunks.get('0,0')); assert.equal(after.length,before.length);
  assert(after.some((v,i)=>v!==before[i])); assert(Array.from(after).every(Number.isFinite)); f.system.dispose();
});
console.log(JSON.stringify({passed:checks,failed:0,scope:'Pressure-plate integration in the new web world'}));
