import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url), reference = JSON.parse(await readFile(new URL('provider-reference.json', root), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {})).instance.exports;
for (const entry of reference.cases) {
  assert.equal(entry.present ? api.brazilpe_chunk_available(entry.state, entry.mode) : 0, entry.available);
}
assert.equal(api.brazilpe_chunk_available(256, 0), -1);
const result = { combinations: reference.cases.length, failed: 0,
  scope: 'Original provider state/null checks; virtual chunk source and concurrency still not reconstructed' };
await writeFile(new URL('provider-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
