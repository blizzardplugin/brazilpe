"""Fingerprint resource declarations; never interpret asset tables as gameplay.
No IPA binary, images, model bodies or audio are copied into public output.
"""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile
from native_image import ROOT, load_image

def parse_jsonc(text):
    # Replace comments with whitespace while preserving strings and line positions.
    output = []; index = 0; quoted = False; escaped = False
    while index < len(text):
        character = text[index]
        if quoted:
            output.append(character)
            if escaped: escaped = False
            elif character == '\\': escaped = True
            elif character == '"': quoted = False
            index += 1; continue
        if character == '"': quoted = True
        elif text[index:index + 2] == '//':
            while index < len(text) and text[index] not in '\r\n': output.append(' '); index += 1
            continue
        elif text[index:index + 2] == '/*':
            end = text.find('*/', index + 2)
            if end < 0: raise ValueError('Unterminated JSON block comment')
            output.extend(c if c in '\r\n' else ' ' for c in text[index:end + 2]); index = end + 2; continue
        output.append(character); index += 1
    cleaned = ''.join(output); output = []; quoted = escaped = False
    for index, character in enumerate(cleaned):
        if quoted:
            output.append(character)
            if escaped: escaped = False
            elif character == '\\': escaped = True
            elif character == '"': quoted = False
            continue
        if character == '"': quoted = True
        if character == ',':
            next_index = index + 1
            while next_index < len(cleaned) and cleaned[next_index].isspace(): next_index += 1
            if next_index < len(cleaned) and cleaned[next_index] in '}]': character = ' '
        output.append(character)
    def reject_constant(value): raise ValueError(f'Non-finite JSON constant: {value}')
    return json.loads(''.join(output), parse_constant=reject_constant)

def generate():
    image, digest = load_image()
    registry = json.loads((Path(__file__).parent / 'registry-arguments.json').read_text())
    if registry['executable_sha256'] != digest: raise ValueError('Registry trace fingerprint mismatch')
    records = registry['records']
    if len(records) != 256 or {r['id'] for r in records} != set(range(256)): raise ValueError('Registry trace incomplete')
    for record in records:
        if image.read(int(record['name_address'], 16), len(record['name']) + 1) != record['name'].encode() + b'\0':
            raise ValueError('Registry name lost its native literal association')
    prefix = 'Payload/minecraftpe.app/data/'
    files = {}; manifests = []
    paths = ['resourcepacks/vanilla/blocks.json', 'resourcepacks/vanilla/items.json',
        'resourcepacks/vanilla/models/mobs.json', 'resourcepacks/vanilla/resources.json',
        'resourcepacks/vanilla/images/terrain_texture.json', 'resourcepacks/vanilla/images/item_texture.json', 'sounds/sounds.json']
    with ZipFile(ROOT / 'ipa/MCPE-0.15.10-hitbox-unsigned.ipa') as archive:
        for path in paths:
            raw = archive.read(prefix + path)
            files[path] = parse_jsonc(raw.decode('utf-8-sig'))
            manifests.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
        resource_files = [info for info in archive.infolist() if not info.is_dir() and info.filename.startswith(prefix)]
        extensions = {}
        for info in resource_files:
            extension = Path(info.filename).suffix.lower()
            extensions[extension] = extensions.get(extension, 0) + 1
    blocks = files[paths[0]]; items = files[paths[1]]; models = files[paths[2]]
    if not isinstance(blocks, dict) or not isinstance(items, list) or not isinstance(models, dict): raise ValueError('Unexpected original resource schemas')
    for item in items:
        if not isinstance(item.get('name'), str) or not isinstance(item.get('id'), int): raise ValueError('Unresolved item resource declaration')
    catalog = {'executable_sha256': digest, 'sources': manifests,
        'scope': 'Observed initializer arguments and resource declarations; not a full native runtime registry.',
        'blocks': [{'id': r['id'], 'name': r['name'], 'placeholder': r['placeholder'],
                    'visual_resource': blocks.get(r['name']), 'factory': r['factory']} for r in sorted(records, key=lambda r: r['id'])],
        'items': [{'name': item['name'], 'resource_id': item['id'],
            'declaration': {key: value for key, value in item.items() if key not in ('name', 'id')}} for item in items],
        'models': [{'name': name, 'texture_width': model.get('texturewidth'), 'texture_height': model.get('textureheight'),
            'bones': len(model.get('bones', []))} for name, model in sorted(models.items())],
        'resource_summary': {'files': len(resource_files), 'extensions': extensions, 'block_visual_entries': len(blocks)},
        'limitations': ['All registry callees modeled; construction and initialization pending.',
            'Item resource IDs retained verbatim; runtime item IDs and a possible offset are not inferred.',
            'Resource items table is not proof of a complete item registry or recipes.',
            'Models summary is not AI, animation or model rendering.',
            'FSB audio and texture assets inventoried, not decoded or distributed.']}
    (ROOT / 'BrazilPE/public/catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, separators=(',', ':')) + '\n')
    (Path(__file__).parent / 'resource-audit.json').write_text(json.dumps({'sources': manifests, 'schemas': {
        key: {'type': type(value).__name__, 'entries': len(value)} for key, value in files.items()},
        'summary': catalog['resource_summary']}, indent=2) + '\n')
    print(f'Catalog: {len(records)} block declarations; {len(items)} item resource declarations; {len(models)} model summaries')
if __name__ == '__main__': generate()
