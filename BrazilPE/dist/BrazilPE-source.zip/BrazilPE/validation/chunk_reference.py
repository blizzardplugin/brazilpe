"""Execute original block ID and metadata readers, substituting chunk providers."""
import json
import random
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X8,
    UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR)
from native_image import load_image, function_starts

OUT = Path(__file__).resolve().parent
image, digest = load_image(); starts = function_starts(image)
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for segment in image.segments:
    if not segment['va'] or not segment['vs']: continue
    uc.mem_map(segment['va'], (segment['vs'] + 4095) & ~4095)
    if segment['fs']: uc.mem_write(segment['va'], image.raw[segment['fo']:segment['fo'] + segment['fs']])
base, stop, chunk = 0x70000000, 0x71000000, 0x73000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096); uc.mem_map(chunk, 0x10000)
ids = bytes((i * 73 + 19) & 255 for i in range(32768))
metadata = bytes((i * 37 + 171) & 255 for i in range(16384))
uc.mem_write(chunk + 0xa88, ids); uc.mem_write(chunk + 0x8a88, metadata)
available = True
def provider(machine, pc, size, user):
    pair = bytes(machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 8))
    machine.mem_write(chunk + 0x28, pair)
    machine.reg_write(UC_ARM64_REG_X0, chunk if available else 0)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
for address in [0x10067301c, 0x100673638]: uc.hook_add(UC_HOOK_CODE, provider, begin=address, end=address)

def execute(entry, address):
    global available
    available = entry['available']
    uc.mem_write(base, bytes(256))
    uc.mem_write(base + 0x10, bytes([entry['provider_mode']]))
    uc.mem_write(base + 0x20, struct.pack('<Q', base + 0x800))
    pair = [entry['position'][0] >> 4, entry['position'][2] >> 4]
    if entry['cached'] and available:
        uc.mem_write(chunk + 0x28, struct.pack('<2i', *pair)); uc.mem_write(base + 0x58, struct.pack('<Q', chunk))
    uc.mem_write(base + 0x1000, struct.pack('<3i', *entry['position']))
    uc.mem_write(base + 0x2000, bytes(8))
    for reg, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x1000),
        (UC_ARM64_REG_X8, base + 0x2000), (UC_ARM64_REG_SP, base + 0x1f000), (UC_ARM64_REG_LR, stop)]: uc.reg_write(reg, value)
    uc.emu_start(address, stop, count=3000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
    return uc.mem_read(base + 0x2000, 1)[0] if address == 0x1005d9f4c else uc.reg_read(UC_ARM64_REG_X0)

entries = []
for x in [-33, -17, -16, -1, 0, 15, 16, 31]:
    for y in [-1, 0, 1, 126, 127, 128]:
        for available_value in [False, True]:
            entries.append({'position': [x, y, -x], 'available': available_value, 'cached': bool(x & 1), 'provider_mode': (y & 1)})
rng = random.Random(151007)
for _ in range(600):
    entries.append({'position': [rng.randrange(-1000, 1001), rng.randrange(-2, 130), rng.randrange(-1000, 1001)],
        'available': rng.random() > 0.2, 'cached': rng.random() > 0.5, 'provider_mode': rng.randrange(2)})
for entry in entries:
    entry['id'] = execute(entry, 0x1005d9f4c); entry['metadata'] = execute(entry, 0x1005da064)
(OUT / 'chunk-reference.json').write_text(json.dumps({'cases': entries}, indent=2) + '\n')
cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM); routines = {}
for address in [0x1005d9f4c, 0x1005da064, 0x1005e0934, 0x1005e09b0, 0x10067b990]:
    code = image.read(address, starts[starts.index(address) + 1] - address)
    routines[hex(address)] = {'bytes': code.hex(), 'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
(OUT / 'chunk-evidence.json').write_text(json.dumps({'executable_sha256': digest,
    'dimensions': [16, 128, 16], 'id_offset': '0xa88', 'metadata_offset': '0x8a88', 'chunk_coordinate_offset': '0x28',
    'index': 'y + ((x & 15) * 16 + (z & 15)) * 128',
    'substituted': ['0x10067301c', '0x100673638'], 'routines': routines,
    'limitations': ['Chunk provider/creation not executed.', 'Fallback block byte assumed image-initial zero.',
        'No disk chunk format, generation, lighting, or block metadata semantics reconstructed.']}, indent=2) + '\n')
print(f'Native chunk readers: {len(entries)} coordinates; IDs and metadata tested')
