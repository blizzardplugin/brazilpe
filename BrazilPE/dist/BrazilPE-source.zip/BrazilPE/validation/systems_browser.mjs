import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { connectPage } from './cdp.mjs';
const page = await connectPage(); let checks = 0;
async function text(selector) { return page.evaluate(`document.querySelector(${JSON.stringify(selector)})?.textContent ?? ''`); }
async function action(expression) { await page.evaluate(expression); }
async function check(selector, expected) { assert.equal(await text(selector), expected); checks++; }
try {
  await page.command('Runtime.enable'); await page.command('Page.enable');
  await page.command('Page.navigate', { url: 'http://127.0.0.1:8080/index.html' });
  for (let i = 0; i < 80 && await text('#status') !== 'Módulo WebAssembly carregado.'; i++) await delay(100);
  await check('#status', 'Módulo WebAssembly carregado.');
  await check('#sensor-result', 'Sinal detectado: 15 · Metadado: 0 · Tick: 0 · Próxima avaliação: nenhuma');
  await action("document.querySelector('#sensor-evaluate').click()");
  await check('#sensor-result', 'Sinal detectado: 15 · Metadado: 1 · Tick: 0 · Próxima avaliação: 20');
  await check('#sensor-trace', 'atualizar componente → escrever metadado → solicitar som → agendar avaliação');
  await action("document.querySelector('#sensor-x').value='2'; document.querySelector('#sensor-x').dispatchEvent(new Event('input')); for(let i=0;i<19;i++) document.querySelector('#sensor-advance').click()");
  await check('#sensor-result', 'Sinal detectado: 0 · Metadado: 1 · Tick: 19 · Próxima avaliação: 20');
  await action("document.querySelector('#sensor-advance').click()");
  await check('#sensor-result', 'Sinal detectado: 0 · Metadado: 0 · Tick: 20 · Próxima avaliação: nenhuma');
  await check('#sensor-trace', 'atualizar componente → escrever metadado → solicitar som');
  await action("document.querySelector('#sensor-reset').click(); document.querySelector('#sensor-x').value='0.5'; document.querySelector('#sensor-type').value='69'; document.querySelector('#sensor-x').dispatchEvent(new Event('input'))");
  await check('#sensor-result', 'Sinal detectado: 0 · Metadado: 0 · Tick: 0 · Próxima avaliação: nenhuma');
  await action("document.querySelector('#sensor-type').value='257'; document.querySelector('#sensor-variant').value='2'; document.querySelector('#sensor-x').dispatchEvent(new Event('input'))");
  await check('#sensor-result', 'Sinal detectado: 0 · Metadado: 0 · Tick: 0 · Próxima avaliação: nenhuma');
  await action("document.querySelector('#sensor-variant').value='1'; document.querySelector('#sensor-x').dispatchEvent(new Event('input'))");
  await check('#sensor-result', 'Sinal detectado: 15 · Metadado: 0 · Tick: 0 · Próxima avaliação: nenhuma');
  await action("document.querySelector('#sensor-mode').value='1'; document.querySelector('#sensor-mode').dispatchEvent(new Event('change')); document.querySelector('#sensor-evaluate').click()");
  await check('#sensor-result', 'Sinal detectado: 1 · Metadado: 1 · Tick: 0 · Próxima avaliação: 10');
  await action("for(let i=0;i<10;i++) document.querySelector('#sensor-advance').click()");
  await check('#sensor-result', 'Sinal detectado: 1 · Metadado: 1 · Tick: 10 · Próxima avaliação: 20');
  await check('#sensor-trace', 'atualizar componente → escrever metadado → agendar avaliação');
  await page.command('Page.navigate', { url: 'http://127.0.0.1:8080/catalog.html' });
  for (let i = 0; i < 80 && await text('#catalog-count') === ''; i++) await delay(100);
  await check('#catalog-count', '256 resultados');
  await action("document.querySelector('#catalog-search').value='stone_pressure_plate'; document.querySelector('#catalog-search').dispatchEvent(new Event('input'))");
  await check('#catalog-count', '1 resultados');
  assert.match(await text('#catalog-records'), /70 · stone_pressure_plate/); checks++;
  await action("document.querySelector('#catalog-kind').value='items'; document.querySelector('#catalog-search').value=''; document.querySelector('#catalog-kind').dispatchEvent(new Event('change'))");
  await check('#catalog-count', '40 resultados');
  await action("document.querySelector('#catalog-search').value='apple'; document.querySelector('#catalog-search').dispatchEvent(new Event('input'))");
  assert.match(await text('#catalog-records'), /nutrition/); checks++;
  await action("document.querySelector('#catalog-kind').value='models'; document.querySelector('#catalog-search').value=''; document.querySelector('#catalog-kind').dispatchEvent(new Event('change'))");
  await check('#catalog-count', '38 resultados');
  assert.equal(page.events.filter(event => event.method === 'Runtime.exceptionThrown').length, 0); checks++;
  const result = { passed: checks, failed: 0, scope: 'Sensor/tick laboratory and observed resource catalog; not complete original gameplay' };
  await writeFile(new URL('systems-browser-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
} finally { page.close(); }
