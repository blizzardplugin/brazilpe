import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url), reference = JSON.parse(await readFile(new URL('chunk-reference.json', root), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {})).instance.exports;
const data = new Uint8Array(api.memory.buffer, api.brazilpe_chunk_buffer(), 49152);
for (let i = 0; i < 32768; i++) data[i] = (i * 73 + 19) & 255;
for (let i = 0; i < 16384; i++) data[32768 + i] = (i * 37 + 171) & 255;
for (const entry of reference.cases) {
  assert.equal(api.brazilpe_chunk_read(...entry.position, Number(entry.available)), entry.id);
  assert.equal(api.brazilpe_chunk_metadata(...entry.position, Number(entry.available)), entry.metadata);
}
const result = { coordinates: reference.cases.length, comparisons: reference.cases.length * 2, failed: 0,
  method: 'Original readers with real cache/index/nibble paths vs Wasm; chunk providers substituted',
  scope: 'In-memory ID/metadata lookup only; not chunk disk format or original registry IDs' };
await writeFile(new URL('chunk-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
