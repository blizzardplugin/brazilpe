import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const ref = JSON.parse(await readFile(new URL('pressure-runtime-reference.json', import.meta.url), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', import.meta.url)), {})).instance.exports;
const positions = new Int32Array(api.memory.buffer, api.brazilpe_pressure_position(), 3);
const boxes = new Float32Array(api.memory.buffer, api.brazilpe_pressure_candidates(), 64 * 6);
const types = new Int32Array(api.memory.buffer, api.brazilpe_pressure_types(), 64);
const sensor = new Uint32Array(api.memory.buffer, api.brazilpe_pressure_sensor(), 6);
const events = new Int32Array(api.memory.buffer, api.brazilpe_pressure_events(), 8);
for (const item of ref.detections) {
  positions.set(item.position);
  item.entities.forEach((entity, i) => { types[i] = entity.type; boxes.set(entity.box, i * 6); });
  assert.equal(api.brazilpe_pressure_detect(0, item.variant, item.entities.length, 15), item.eligible > 0 ? 15 : 0);
  assert.deepEqual(Array.from(sensor), item.sensor_bits);
  if (item.variant === 0) assert.equal(api.brazilpe_pressure_detect(1, 0, item.entities.length, 15), api.brazilpe_pressure_signal(1, item.eligible, 15));
}
for (const item of ref.ticks) {
  assert.equal(api.brazilpe_pressure_tick(item.weighted, item.metadata, item.signal, item.remote), item.remote ? 0 : 1);
  assert.deepEqual(Array.from(events.slice(1, 1 + events[0])), item.events.map(event => event.kind));
  for (const event of item.events) {
    if (event.kind === 2) assert.equal(events[5], event.metadata);
    if (event.kind === 3) assert.equal(events[6], event.payload);
    if (event.kind === 4) assert.equal(events[7], event.delay);
  }
}
const before = Array.from(sensor);
assert.equal(api.brazilpe_pressure_detect(0, 0, 65, 15), -1);
assert.deepEqual(Array.from(sensor), before);
boxes[0] = NaN;
assert.equal(api.brazilpe_pressure_detect(0, 0, 1, 15), -1);
const beforeEvents = Array.from(events);
assert.equal(api.brazilpe_pressure_tick(0, 0, 16, 0), -1);
assert.deepEqual(Array.from(events), beforeEvents);
const result = { detections: ref.detections.length, tickSequences: ref.ticks.length, failed: 0, limitations: ref.limitations };
await writeFile(new URL('pressure-runtime-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
