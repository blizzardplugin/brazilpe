import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url), reference = JSON.parse(await readFile(new URL('shapes-reference.json', root), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {})).instance.exports;
const shape = new Float32Array(api.memory.buffer, api.brazilpe_shape_buffer(), 8);
const shapeBits = new Uint32Array(api.memory.buffer, api.brazilpe_shape_buffer(), 8);
const data = new Float32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const bits = new Uint32Array(api.memory.buffer, api.brazilpe_block_buffer(), 32);
const position = new Int32Array(api.memory.buffer, api.brazilpe_block_position(), 3);
for (const entry of reference.getters) {
  assert.equal(api.brazilpe_block_shape(entry.profile, entry.metadata), 1);
  assert.deepEqual(Array.from(shapeBits.slice(0, 6)), entry.expected.bits);
  assert.equal(shape[6], entry.expected.flag);
}
for (const entry of reference.collectors) {
  assert.equal(api.brazilpe_block_shape(1, entry.metadata), 1);
  data.set(shape.slice(0, 6), 0); data[24] = shape[6]; data.set(entry.query, 8); position.set(entry.position);
  assert.equal(api.brazilpe_thin_collect(entry.metadata), entry.accepted);
  if (entry.accepted) assert.deepEqual(Array.from(bits.slice(16, 22)), entry.bits);
}
assert.equal(api.brazilpe_block_shape(3, 0), 0); assert.equal(api.brazilpe_block_shape(1, -1), 0);
const result = { getters: reference.getters.length, thinCollectors: reference.collectors.length, failed: 0,
  scope: 'Native shape getter outputs and thin-profile collector path; not original block identities or other subclasses' };
await writeFile(new URL('shapes-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
