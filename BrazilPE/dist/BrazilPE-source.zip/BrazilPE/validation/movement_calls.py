"""Find direct ARM64 BL references; this does not resolve indirect calls."""
import bisect
import json
import struct
from pathlib import Path
from native_image import load_image, function_starts

image, digest = load_image()
starts = function_starts(image)
targets = {0x1006f6c08: 'clip_x', 0x1006f6cd8: 'clip_y',
           0x1006f6da8: 'clip_z', 0x1006f6720: 'translate'}
calls = []
for section in image.sections:
    if section['name'] != '__text':
        continue
    code = image.raw[section['offset']:section['offset'] + section['size']]
    for index, (word,) in enumerate(struct.iter_unpack('<I', code)):
        if word >> 26 != 0x25:
            continue
        delta = word & 0x3ffffff
        if delta & 0x2000000:
            delta -= 0x4000000
        site = section['va'] + index * 4
        target = site + delta * 4
        if target not in targets:
            continue
        owner = bisect.bisect_right(starts, site) - 1
        if owner < 0:
            raise ValueError('Caller outside known function boundaries')
        calls.append({'site': hex(site), 'target': targets[target], 'caller': hex(starts[owner])})
report = {'executable_sha256': digest, 'direct_calls': calls,
          'limitation': 'Indirect calls and tail branches are not enumerated.'}
Path(__file__).with_name('movement-calls.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
