import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const ref = JSON.parse(await readFile(new URL('scheduler-reference.json', import.meta.url), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', import.meta.url)), {})).instance.exports;
const clock = value => [Number(BigInt(value) & 0xffffffffn), Number(BigInt(value) >> 32n)];
function entries(pointer, count) {
  const data = new DataView(api.memory.buffer); const output = [];
  for (let i = 0; i < count; i++) {
    const p = pointer + i * 24;
    output.push({ position: [data.getInt32(p, true), data.getInt32(p + 4, true), data.getInt32(p + 8, true)],
      id: data.getUint8(p + 12), deadline: data.getBigUint64(p + 16, true).toString() });
  }
  return output;
}
let operations = 0;
for (const scenario of ref.scenarios) {
  api.brazilpe_scheduler_reset(...clock(scenario.initial));
  for (const op of scenario.operations) {
    if (op.kind === 'add') assert.equal(api.brazilpe_scheduler_add(...op.position, op.id, op.delay, op.available, op.current_id), op.available ? 1 : 0);
    else if (op.kind === 'cancel') api.brazilpe_scheduler_cancel(...op.position, op.id);
    else assert.equal(api.brazilpe_scheduler_process(...clock(op.now), op.budget, op.available, op.current_id), op.result);
    assert.deepEqual(entries(api.brazilpe_scheduler_buffer(), api.brazilpe_scheduler_count()), op.queue);
    const dispatched = entries(api.brazilpe_scheduler_dispatched(), api.brazilpe_scheduler_dispatch_count()).map(entry => ({ position: entry.position, id: entry.id, time: entry.deadline }));
    if (op.kind !== 'cancel') assert.deepEqual(dispatched, op.callbacks); operations++;
  }
}
api.brazilpe_scheduler_reset(0, 0);
for (let i = 0; i < 128; i++) assert.equal(api.brazilpe_scheduler_add(i, 0, 0, 70, 1, 1, 70), 1);
const before = entries(api.brazilpe_scheduler_buffer(), 128);
assert.equal(api.brazilpe_scheduler_add(0, 0, 0, 70, 1, 1, 70), -2);
assert.equal(api.brazilpe_scheduler_add(0, 0, 0, 256, 1, 1, 70), -1);
assert.equal(api.brazilpe_scheduler_process(1, 0, 129, 1, 70), -1);
assert.deepEqual(entries(api.brazilpe_scheduler_buffer(), 128), before);
const result = { scenarios: ref.scenarios.length, operations, failed: 0, scope: 'Native scheduler insert/heap/process with fixture world reads and callback sinks' };
await writeFile(new URL('scheduler-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
