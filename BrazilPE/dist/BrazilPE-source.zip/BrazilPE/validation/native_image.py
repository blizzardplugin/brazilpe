"""Load the repository artifact directly; generated Ghidra files are optional."""
import hashlib
import json
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.macho import MachO

def load_image():
    expected = json.loads((ROOT / 'VALIDATION.json').read_text())['output_executable_sha256']
    with zipfile.ZipFile(ROOT / 'ipa/MCPE-0.15.10-hitbox-unsigned.ipa') as archive:
        raw = archive.read('Payload/minecraftpe.app/minecraftpe')
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('Unexpected executable hash')
    return MachO(raw), expected

def function_starts(image):
    offset, size = struct.unpack_from('<II', image.command(0x26), 8)
    if offset + size > len(image.raw):
        raise ValueError('Function starts outside file')
    address = next(s['va'] for s in image.segments if s['name'] == '__TEXT')
    result, value, shift = [], 0, 0
    for byte in image.raw[offset:offset + size]:
        if shift > 63:
            raise ValueError('Invalid ULEB128 function offset')
        value |= (byte & 127) << shift
        if byte & 128:
            shift += 7
            continue
        if value == 0:
            return result
        address += value
        result.append(address)
        value, shift = 0, 0
    raise ValueError('Unterminated function starts')
