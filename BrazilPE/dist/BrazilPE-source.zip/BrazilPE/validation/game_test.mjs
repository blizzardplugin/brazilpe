import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { CONFIG } from '../public/game/config.js';
import { World, raycast, collectObstacles } from '../public/game/world.js';
import { createPlayer, stepPlayer, playerBox } from '../public/game/physics.js';
import { encodeSave, decodeSave, saveLocal, loadLocal } from '../public/game/save.js';
import { chunkMesh } from '../public/game/renderer.js';
const { instance } = await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', import.meta.url)), {});
const api = instance.exports;
let checks = 0;
function check(name, run) { run(); checks++; console.log(`PASS ${name}`); }
const world = new World();
check('four chunks and protected boundaries', () => {
  assert.equal(world.chunks.size, 4); assert.equal(world.get(8, 2, 8), 1);
  assert.equal(world.chunks.get('0,0').cells.length, 32768);
  assert.equal(world.set(8, 0, 8, 0), false); assert.equal(world.set(0, 3, 8, 0), false);
  assert.equal(world.set(100, 3, 8, 1), false);
});
check('world buffer uses recovered native column-major indexing', () => {
  for (const x of [0, 1, 15]) for (const z of [0, 3, 15]) for (const y of [0, 1, 63, 127]) {
    assert.equal(world.index(x, y, z), api.brazilpe_chunk_index(x, y, z));
  }
});
check('edits are reversible and dirty neighboring chunks', () => {
  world.dirty.clear(); assert(world.set(16, 3, 8, 5)); assert(world.dirty.has('0,0'));
  assert(world.set(16, 3, 8, 0)); assert.equal(world.edits.size, 0);
});
check('visible-face mesh has finite coordinates and complete triangles', () => {
  for (const chunk of world.chunks.values()) {
    const mesh = chunkMesh(world, chunk); assert(mesh.length > 0); assert.equal(mesh.length % 18, 0);
    assert(Array.from(mesh).every(Number.isFinite));
  }
});
check('world query includes floor and refuses oversized regions', () => {
  const player = createPlayer(); const obstacles = collectObstacles(api, world, playerBox(player), [0, -0.1, 0]);
  assert(obstacles.some(box => box[1] === 2 && box[4] === 3));
  assert.throws(() => collectObstacles(api, world, [0, 0, 0, 31, 15, 31], [0, 0, 0]), /região/);
});
check('standing on floor remains stable for 300 fixed steps', () => {
  const player = createPlayer(); for (let i = 0; i < 300; i++) stepPlayer(api, world, player, {});
  assert(Math.abs(player.position[1] - 3) < 0.0001); assert(player.ground); assert.equal(player.velocity[1], 0);
});
check('walking into wall clips movement', () => {
  const player = createPlayer([10, 3, 10.5]); player.yaw = Math.PI / 2;
  for (let i = 0; i < 180; i++) stepPlayer(api, world, player, { forward: true });
  assert(player.position[0] > 14); assert(player.position[0] <= 14.7001);
});
check('jump rises and returns to floor', () => {
  const player = createPlayer(); stepPlayer(api, world, player, {}); stepPlayer(api, world, player, { jump: true });
  let highest = player.position[1]; for (let i = 0; i < 160; i++) { stepPlayer(api, world, player, {}); highest = Math.max(highest, player.position[1]); }
  assert(highest > 3.5); assert(Math.abs(player.position[1] - 3) < 0.0001); assert(player.ground);
});
check('block raycast stops at terrain and has bounded reach', () => {
  const hit = raycast(world, [8.5, 4.6, 8.5], [0, -1, 0]); assert.deepEqual(hit.cell, [8, 2, 8]);
  assert.deepEqual(hit.previous, [8, 3, 8]); assert.equal(raycast(world, [8.5, 12, 8.5], [0, -1, 0]), null);
});
check('save/load preserves edits, pose and new format', () => {
  assert(world.set(9, 3, 9, 5)); const player = createPlayer(); player.yaw = 0.5;
  const restored = decodeSave(encodeSave(world, player)); assert.equal(restored.world.get(9, 3, 9), 5);
  assert.deepEqual(restored.player.position, player.position); assert.equal(restored.player.yaw, 0.5);
});
check('invalid saves are rejected before restore', () => {
  assert.throws(() => decodeSave('{'), /inválido/);
  const record = JSON.parse(encodeSave(world, createPlayer())); record.edits.push(record.edits[0]);
  assert.throws(() => decodeSave(JSON.stringify(record)), /duplicado/);
  record.edits = [[-1, 3, 2, 1]]; assert.throws(() => decodeSave(JSON.stringify(record)), /Bloco/);
  record.edits = [[8, 3, 8, 1]]; assert.throws(() => decodeSave(JSON.stringify(record)), /dentro de um bloco/);
  assert.throws(() => decodeSave('x'.repeat(CONFIG.maxSaveBytes + 1)), /grande/);
});
check('storage errors are visible and local save roundtrip works', () => {
  const memory = new Map(), storage = { setItem: (k, v) => memory.set(k, v), getItem: k => memory.get(k) ?? null };
  assert.equal(loadLocal(storage), null); saveLocal(storage, world, createPlayer()); assert.equal(loadLocal(storage).world.get(9, 3, 9), 5);
  assert.throws(() => saveLocal({ setItem() { throw new Error('quota'); } }, world, createPlayer()), /quota/);
});
console.log(JSON.stringify({ passed: checks, failed: 0, scope: 'New web prototype integration; not MCPE behavior equivalence' }));
