import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const pages = await (await fetch('http://127.0.0.1:9222/json/list')).json();
const page = pages.find(x => x.type === 'page');
assert(page, 'No Chromium page');
const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener('open', resolve, { once: true });
  socket.addEventListener('error', reject, { once: true });
});
let nextId = 0;
const pending = new Map();
socket.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  const task = pending.get(message.id);
  if (!task) return;
  pending.delete(message.id);
  clearTimeout(task.timer);
  if (message.error) task.reject(new Error(JSON.stringify(message.error)));
  else task.resolve(message.result);
});
function command(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++nextId;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`Timeout: ${method}`)); }, 10000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params }));
  });
}
async function evaluate(expression) {
  const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  assert(!result.exceptionDetails, JSON.stringify(result.exceptionDetails));
  return result.result.value;
}
try {
  await command('Page.enable');
  await command('Page.navigate', { url: 'http://127.0.0.1:8080/' });
  let loaded = false;
  for (let i = 0; i < 60; i++) {
    loaded = await evaluate("document.querySelector('#status')?.textContent === 'Módulo WebAssembly carregado.'");
    if (loaded) break;
    await delay(250);
  }
  assert(loaded, 'WebAssembly did not load');
  assert.equal(await evaluate("document.querySelector('#radius').textContent"), '0,300');
  assert.equal(await evaluate("document.querySelector('#dimension').disabled"), false);
  await evaluate("document.querySelector('#dimension').value='2'; document.querySelector('#dimension').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#radius').textContent"), '1,000');
  await evaluate("document.querySelector('#dimension').value='0'; document.querySelector('#dimension').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#radius').textContent"), '0,000');
  assert.equal(await evaluate("document.querySelector('#allowed').textContent"), '0.600');
  assert.equal(await evaluate("document.querySelector('#overlap').textContent"), 'Não');
  await evaluate("document.querySelector('#position').value='-0.6'; document.querySelector('#position').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#allowed').textContent"), '0.000');
  assert.equal(await evaluate("document.querySelector('#overlap').textContent"), 'Não');
  await evaluate("document.querySelector('#position').value='0.2'; document.querySelector('#position').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#overlap').textContent"), 'Sim');
  assert.equal(await evaluate("document.querySelector('#contained').textContent"), 'Sim');
  assert.equal(await evaluate("document.querySelector('#step-result').textContent"), '0.700 / -0.600 / 0.700');
  assert.equal(await evaluate("document.querySelector('#step-ground').textContent"), 'Sim');
  assert.equal(await evaluate("document.querySelector('#step-velocity').textContent"), '0.000 / 0.000 / 0.000');
  await evaluate("document.querySelector('#step-bypass').checked=true; document.querySelector('#step-bypass').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#step-result').textContent"), '2.000 / -1.000 / 2.000');
  assert.equal(await evaluate("document.querySelector('#step-ground').textContent"), 'Não');
  assert.equal(await evaluate("document.querySelector('#step-velocity').textContent"), '1.000 / -1.000 / 1.000');
  await evaluate("document.querySelector('#step-bypass').checked=false; document.querySelector('#step-bypass').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.06250');
  await evaluate("document.querySelector('#shape-metadata').value='1'; document.querySelector('#shape-metadata').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.03125');
  await evaluate("document.querySelector('#shape-profile').value='2'; document.querySelector('#shape-profile').dispatchEvent(new Event('change'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.12500');
  await evaluate("document.querySelector('#shape-metadata').value='2'; document.querySelector('#shape-metadata').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.62500');
  assert.equal(await evaluate("document.querySelector('#shape-source').options.length"), 9);
  await evaluate("document.querySelector('#shape-source').value='70'; document.querySelector('#shape-metadata').value='0'; document.querySelector('#shape-source').dispatchEvent(new Event('change'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.06250');
  await evaluate("document.querySelector('#shape-source').value='66'; document.querySelector('#shape-metadata').value='2'; document.querySelector('#shape-source').dispatchEvent(new Event('change'))");
  assert.equal(await evaluate("document.querySelector('#shape-height').textContent"), '0.62500');
  await command('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
  assert.equal(await evaluate("document.querySelector('#pressure-result').textContent"), 'Sinal: 15 · Metadado calculado: 1 · Sinal do metadado informado: 0 · Intervalo retornado: 20 ticks');
  await evaluate("document.querySelector('#pressure-weighted').value='1'; document.querySelector('#pressure-count').value='2'; document.querySelector('#pressure-capacity').value='150'; document.querySelector('#pressure-metadata').value='7'; document.querySelector('#pressure-count').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#pressure-result').textContent"), 'Sinal: 1 · Metadado calculado: 1 · Sinal do metadado informado: 7 · Intervalo retornado: 10 ticks');
  await evaluate("document.querySelector('#pressure-count').value='0'; document.querySelector('#pressure-count').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#pressure-result').textContent"), 'Sinal: 0 · Metadado calculado: 0 · Sinal do metadado informado: 7 · Intervalo retornado: 10 ticks');
  await evaluate("document.querySelector('#pressure-count').value='4097'; document.querySelector('#pressure-count').dispatchEvent(new Event('input'))");
  assert.equal(await evaluate("document.querySelector('#pressure-result').textContent"), 'Valores fora do intervalo do laboratório.');
  assert.equal(await evaluate("fetch('fidelity.html').then(async r => {if (!r.ok) throw new Error('Roadmap unavailable'); return new DOMParser().parseFromString(await r.text(), 'text/html').querySelectorAll('ol > li').length;})"), 12);
  assert(await evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Mobile horizontal overflow');
  await evaluate("document.querySelector('#dimension').value='0.6'; document.querySelector('#dimension').dispatchEvent(new Event('input'))");
  const screenshot = await command('Page.captureScreenshot', { format: 'png' });
  await writeFile(new URL('browser.png', import.meta.url), Buffer.from(screenshot.data, 'base64'));
  const result = { passed: 30, failed: 0, browser: 'Chromium headless', mobileViewport: '390x844',
    checks: ['Wasm loaded', 'initial radius', 'control enabled', 'input update', 'zero input', 'mobile width',
      'initial clipped movement', 'initial disjoint boxes', 'contact blocks movement',
      'contact is not overlap', 'overlap after moving', 'center containment',
      'movement blocked across XYZ', 'ground flag', 'blocked velocity reset',
      'bypass movement', 'bypass ground preserved', 'bypass velocity preserved',
      'thin shape metadata 0', 'thin shape metadata 1', 'variable shape low branch', 'variable shape high branch',
      'eight observed registry bindings', 'ID 70 getter routing', 'ID 66 getter routing',
      'normal plate signal', 'weighted plate signal and metadata', 'empty plate signal',
      'invalid plate input rejected', '12 fidelity stages available'],
    limitation: 'Mobile viewport emulation does not test Safari/iOS or physical Android.' };
  await writeFile(new URL('browser-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
} finally {
  socket.close();
}
