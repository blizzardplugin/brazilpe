"""Execute actual native shape getters and the thin-class collector dispatch."""
import json
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3,
    UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_PC, UC_ARM64_REG_SP, UC_ARM64_REG_LR)
from native_image import load_image, function_starts

OUT = Path(__file__).resolve().parent
image, digest = load_image(); starts = function_starts(image)
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for segment in image.segments:
    if not segment['va'] or not segment['vs']: continue
    uc.mem_map(segment['va'], (segment['vs'] + 4095) & ~4095)
    if segment['fs']: uc.mem_write(segment['va'], image.raw[segment['fo']:segment['fo'] + segment['fs']])
base, stop = 0x70000000, 0x71000000
uc.mem_map(base, 0x20000); uc.mem_map(stop, 4096)
output = base + 0x1000
def prepare():
    uc.reg_write(UC_ARM64_REG_SP, base + 0x1f000); uc.reg_write(UC_ARM64_REG_LR, stop)
def run(address):
    uc.emu_start(address, stop, count=3000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x1f000
def get_shape(profile, metadata):
    uc.mem_write(output, bytes(32)); prepare()
    uc.reg_write(UC_ARM64_REG_X0, output if profile == 0 else base)
    uc.reg_write(UC_ARM64_REG_X1, metadata); uc.reg_write(UC_ARM64_REG_X2, output)
    run([0x1006f6268, 0x1006063b8, 0x1006085f0][profile])
    data = bytes(uc.mem_read(output, 25))
    return {'bits': list(struct.unpack('<6I', data[:24])), 'flag': data[24]}

metadata_value = 0
def metadata_lookup(machine, pc, size, user):
    machine.reg_write(UC_ARM64_REG_X0, metadata_value)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
uc.hook_add(UC_HOOK_CODE, metadata_lookup, begin=0x1005da064, end=0x1005da064)
cases = [{'profile': profile, 'metadata': metadata, 'expected': get_shape(profile, metadata)}
         for profile in range(3) for metadata in range(256)]
collection = []
position, query, vector, box = base + 0x2000, base + 0x3000, base + 0x4000, base + 0x5000
uc.mem_write(base, struct.pack('<Q', 0x100e89d70))
for metadata in range(16):
    metadata_value = metadata
    for coordinates in [[0, 0, 0], [5, -2, 7], [-4, 3, -5]]:
        x, y, z = coordinates
        for low_y in [y - 0.1, y, y + 0.03125, y + 0.0625, y + 0.5]:
            bounds = [x, low_y, z, x + 1, y + 1, z + 1]
            uc.mem_write(position, struct.pack('<3i', *coordinates))
            uc.mem_write(query, struct.pack('<6f', *bounds) + bytes(4))
            uc.mem_write(vector, struct.pack('<3Q', box, box, box + 28)); uc.mem_write(box, bytes(28))
            prepare()
            for reg, value in [(UC_ARM64_REG_X0, base), (UC_ARM64_REG_X1, base + 0x800),
                (UC_ARM64_REG_X2, position), (UC_ARM64_REG_X3, query), (UC_ARM64_REG_X4, vector), (UC_ARM64_REG_X5, 0)]: uc.reg_write(reg, value)
            run(0x10060ff60)
            accepted = uc.reg_read(UC_ARM64_REG_X0)
            end = struct.unpack('<Q', bytes(uc.mem_read(vector + 8, 8)))[0]
            assert accepted in (0, 1) and end == box + accepted * 28
            collection.append({'metadata': metadata, 'position': coordinates, 'query': bounds,
                'accepted': accepted, 'bits': list(struct.unpack('<6I', bytes(uc.mem_read(box, 24)))) if accepted else None})
(OUT / 'shapes-reference.json').write_text(json.dumps({'getters': cases, 'collectors': collection}, indent=2) + '\n')
cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM); routines = {}
for address in [0x1006062c8, 0x100606364, 0x1006063b8, 0x100606444, 0x1006064b8, 0x100608554, 0x1006085f0, 0x1006f7e90]:
    code = image.read(address, starts[starts.index(address) + 1] - address)
    routines[hex(address)] = {'bytes': code.hex(), 'assembly': [f'{i.address:x}: {i.mnemonic} {i.op_str}' for i in cs.disasm(code, address)]}
(OUT / 'shapes-evidence.json').write_text(json.dumps({'executable_sha256': digest,
    'thin_vtable': '0x100e89d70', 'constructor_writes_vtable': '0x1006062e4..0x1006062f0', 'routines': routines,
    'limitations': ['Original class names and IDs unresolved.', 'Thin collector metadata lookup substituted.',
        'Observed thin collector uses local coordinates without BlockPos translation; not integrated as world-space collision.',
        'Variable-height getter is validated separately; its full class collision path is not established.',
        'Global zero vector assumed image-initial zero; no startup or allocator execution.']}, indent=2) + '\n')
print(f'Native shape getters: {len(cases)} cases; thin collector: {len(collection)} cases')
