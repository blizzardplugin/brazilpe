"""Whole native plate contact -> query -> write -> queue -> tick cycles.

Entity type and chunk source are external fixtures. Storage setter, redstone
component and sound sinks are adapters. Native metadata readers, query, vector
copy, contact/update, scheduler and reentrant plate callbacks actually execute.
"""
import json
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *
from native_image import load_image

image, digest = load_image()
profiles = json.loads((Path(__file__).resolve().parents[1] / 'public/pressure-profiles.json').read_text())['profiles']
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for seg in image.segments:
    if not seg['va'] or not seg['vs']: continue
    uc.mem_map(seg['va'], (seg['vs'] + 4095) & ~4095)
    if seg['fs']: uc.mem_write(seg['va'], image.raw[seg['fo']:seg['fo'] + seg['fs']])
base, stop, callback, chunk_base = 0x70000000, 0x71000000, 0x72000000, 0x73000000
uc.mem_map(base, 0x100000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096); uc.mem_map(chunk_base, 0x16000 * 4)
block, source, level, dimension, provider = base, base + 0x1000, base + 0x2000, base + 0x4000, base + 0x5000
position, scheduler, queue, clock = base + 0x6000, base + 0x9000, base + 0xa000, base + 0xd000
entity_base, entity_table, vector = base + 0x10000, base + 0x20000, base + 0x21000
coord = (8, 3, 8); column = lambda x,y,z: y + ((x & 15) * 16 + (z & 15)) * 128
chunks = {(x,z): chunk_base + (x * 2 + z) * 0x16000 for x in range(2) for z in range(2)}
events = []; signal_value = 0; region_available = True; heap_cursor = base + 0x80000
current_id = 70
def set_cell(identifier, metadata):
    index = column(*coord); chunk = chunks[(0,0)]
    uc.mem_write(chunk + 0xa88 + index, bytes([identifier]))
    address = chunk + 0x8a88 + (index >> 1); byte = uc.mem_read(address, 1)[0]; shift = (index & 1) * 4
    uc.mem_write(address, bytes([(byte & ~(15 << shift)) | (metadata << shift)]))
def metadata():
    index = column(*coord)
    return (uc.mem_read(chunks[(0,0)] + 0x8a88 + (index >> 1), 1)[0] >> ((index & 1) * 4)) & 15
def hook(machine, pc, size, user):
    global signal_value, heap_cursor
    if pc == callback:
        kind = struct.unpack('<I', machine.mem_read(machine.reg_read(UC_ARM64_REG_X0) + 8, 4))[0]
        machine.reg_write(UC_ARM64_REG_W0, kind)
    elif pc == callback + 4:
        cell = struct.unpack('<2i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 8))
        machine.reg_write(UC_ARM64_REG_X0, 0 if not region_available and cell == (1,1) else chunks.get(cell, 0))
    elif pc == 0x100682070: machine.reg_write(UC_ARM64_REG_X0, base + 0x30000)
    elif pc == 0x1006ff3b4:
        signal_value = machine.reg_read(UC_ARM64_REG_W2); events.append({'kind':1,'value':signal_value})
    elif pc == 0x1005db594:
        pos = struct.unpack('<3i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 12))
        data = machine.mem_read(machine.reg_read(UC_ARM64_REG_X2), 2)
        assert pos == coord and data[0] == current_id and machine.reg_read(UC_ARM64_REG_W3) == 3
        set_cell(data[0], data[1]); events.append({'kind':2,'value':data[1]}); machine.reg_write(UC_ARM64_REG_W0, 1)
    elif pc == 0x1005e66c8:
        assert machine.reg_read(UC_ARM64_REG_W2) == 3500
        events.append({'kind':3,'value':machine.reg_read(UC_ARM64_REG_W4)})
    elif pc == 0x1005df614:
        events.append({'kind':4,'value':machine.reg_read(UC_ARM64_REG_W4)})
        return # Observe but do not substitute the scheduler.
    elif pc == 0x100be3620:
        length = machine.reg_read(UC_ARM64_REG_X0)
        if length > 65536 or heap_cursor + length > base + 0xf0000: raise ValueError('Native fixture allocation bound')
        machine.reg_write(UC_ARM64_REG_X0, heap_cursor); heap_cursor += (length + 15) & ~15
    elif pc in (0x100be3d34, 0x100be3d40):
        destination, origin, length = [machine.reg_read(r) for r in (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2)]
        if length > 65536: raise ValueError('Native fixture copy bound')
        machine.mem_write(destination, bytes(machine.mem_read(origin, length)))
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
for address in (callback, callback + 4, 0x100682070, 0x1006ff3b4, 0x1005db594, 0x1005e66c8,
                0x1005df614, 0x100be3620, 0x100be3608, 0x100be3d34, 0x100be3d40):
    uc.hook_add(UC_HOOK_CODE, hook, begin=address, end=address)
def run(address, registers):
    uc.reg_write(UC_ARM64_REG_SP, base + 0x7f000); uc.reg_write(UC_ARM64_REG_LR, stop)
    for register, value in registers: uc.reg_write(register, value)
    uc.emu_start(address, stop, count=300000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x7f000
def initialize(profile):
    global current_id, signal_value, heap_cursor
    current_id = profile['id']; signal_value = 0; heap_cursor = base + 0x80000
    uc.mem_write(base, bytes(0x80000)); uc.mem_write(chunk_base, bytes(0x16000 * 4))
    for (cx,cz), chunk in chunks.items():
        uc.mem_write(chunk + 0x28, struct.pack('<2i',cx,cz)); uc.mem_write(chunk + 0x78,b'\4')
        uc.mem_write(chunk + 0x152e8, struct.pack('<3Q',vector,vector,vector + 64 * 8))
    table = 0x100ea48e0 if profile['weighted'] else 0x100e9b590
    uc.mem_write(block, struct.pack('<Q',table)); uc.mem_write(block + 8,bytes([current_id])); uc.mem_write(block + 0xb8,struct.pack('<I',profile['parameter']))
    uc.mem_write(0x100fc4680 + current_id * 8,struct.pack('<Q',block))
    uc.mem_write(source + 0x18,struct.pack('<Q',level)); uc.mem_write(source + 0x28,struct.pack('<Q',dimension))
    uc.mem_write(source + 0x20,struct.pack('<Q',provider)); uc.mem_write(source + 0x60,struct.pack('<Q',scheduler))
    uc.mem_write(source + 0x68,struct.pack('<3Q',base + 0x22000,base + 0x22000,base + 0x22000 + 64 * 8))
    uc.mem_write(provider,struct.pack('<Q',provider + 0x100)); uc.mem_write(provider + 8,struct.pack('<I',16))
    uc.mem_write(provider + 0x110,struct.pack('<Q',callback + 4)); uc.mem_write(entity_table + 0x2b0,struct.pack('<Q',callback))
    uc.mem_write(position,struct.pack('<3i',*coord)); uc.mem_write(scheduler,struct.pack('<4Q',0,queue,queue,queue + 128 * 24))
    set_cell(current_id,0)
def set_actors(actors):
    for i, actor in enumerate(actors):
        pointer = entity_base + i * 512
        uc.mem_write(pointer,struct.pack('<QI',entity_table,actor['type']))
        uc.mem_write(pointer + 0xb4,struct.pack('<6f',*actor['box']) + bytes(4))
        uc.mem_write(vector + i * 8,struct.pack('<Q',pointer))
    uc.mem_write(chunks[(0,0)] + 0x152e8,struct.pack('<3Q',vector,vector + len(actors) * 8,vector + 64 * 8))
def snapshot():
    begin,end = struct.unpack('<2Q',uc.mem_read(scheduler + 8,16))
    deadlines = [struct.unpack('<Q',uc.mem_read(p + 16,8))[0] for p in range(begin,end,24)]
    return {'metadata':metadata(),'signal':signal_value,'deadlines':deadlines,'events':list(events)}
cases = []
actor = lambda kind=319: {'type':kind,'box':[8.2,3,8.2,8.8,4.8,8.8]}
for profile in profiles:
    for variant in range(6):
        initialize(profile); tick = 0; accumulator = 0; sequence = []
        for step in range(100):
            events.clear(); heap_cursor = base + 0x80000
            actors = [actor()] if step < 40 else []
            if variant == 1: actors = [actor(1)] if step < 40 else []
            if variant == 2: actors = [actor(69)] if step < 40 else []
            if variant == 3 and 10 <= step < 40: actors = [actor()] * 16
            region_available = not (variant == 5 or variant == 4 and step >= 10)
            set_actors(actors)
            for i in range(len(actors)):
                run(0x100606628,[(UC_ARM64_REG_X0,block),(UC_ARM64_REG_X1,source),(UC_ARM64_REG_X2,position),(UC_ARM64_REG_X3,entity_base + i * 512)])
            accumulator += 1/60
            while accumulator + 1e-9 >= .05:
                accumulator -= .05; tick += 1; uc.mem_write(clock,struct.pack('<Q',tick))
                run(0x1005df794,[(UC_ARM64_REG_X0,scheduler),(UC_ARM64_REG_X1,source),(UC_ARM64_REG_X2,clock),(UC_ARM64_REG_W3,128),(UC_ARM64_REG_W4,0)])
            sequence.append({'actors':actors,'available':region_available,'tick':tick,**snapshot()})
        cases.append({'id':profile['id'],'variant':variant,'sequence':sequence})
out = Path(__file__).resolve().parent
(out / 'pressure-cycle-reference.json').write_text(json.dumps({'executable_sha256':digest,'cases':cases,
    'limitations':['World initialized by fixture; registry and constructor flow verified separately, not full native startup.',
        'Chunk-source/type virtuals, setter, component and sound destinations supplied; native reads and controllers execute.',
        'Allocator and memcpy/memmove implementations supplied; native vector-copy control executes.',
        'Cycle validates one plate with up to 16 supplied entities; shared-queue cross-plate effects and circuits excluded.']},indent=2)+'\n')
print('Complete native plate cycles:',len(cases),'frames:',sum(len(case['sequence']) for case in cases))
