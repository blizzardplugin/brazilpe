import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url);
const reference = JSON.parse(await readFile(new URL('movement-reference.json', root), 'utf8'));
const { instance } = await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {});
const api = instance.exports;
const floats = new Float32Array(api.memory.buffer, api.brazilpe_movement_buffer(), 544);
const integers = new Uint32Array(api.memory.buffer, api.brazilpe_movement_buffer(), 544);
let comparisons = 0;
for (const entry of reference.cases) {
  floats.fill(0);
  floats.set(entry.box, 0); floats.set(entry.velocity, 8); floats.set(entry.desired, 12);
  floats[24] = entry.ground;
  entry.obstacles.forEach((box, index) => floats.set(box, 32 + index * 8));
  assert.equal(api.brazilpe_move(entry.obstacles.length, entry.no_collision), 1);
  for (const [name, offset, length] of [['box', 0, 6], ['position', 16, 3], ['velocity', 8, 3], ['allowed', 20, 3]]) {
    assert.deepEqual(Array.from(integers.slice(offset, offset + length)), entry.expected[name], `${entry.name}: ${name}`);
    comparisons++;
  }
  assert.equal(floats[24], entry.expected.ground, `${entry.name}: ground`);
  comparisons++;
}
const before = Array.from(integers);
assert.equal(api.brazilpe_move(65, 0), 0);
assert.deepEqual(Array.from(integers), before, 'Invalid count changed state');
assert.equal(api.brazilpe_move(-1, 0), 0);
assert.equal(api.brazilpe_move(0, 2), 0);
floats[12] = NaN;
assert.equal(api.brazilpe_move(0, 0), 0);
const result = { scenarios: reference.cases.length, comparisons, failed: 0,
  method: 'Full ARM64 caller and native helpers vs reconstructed Wasm; candidate-world query stubbed',
  scope: 'Axis order, final box, center position, velocity resets, ground flag, and bypass branch',
  limitation: 'Does not validate real-world obstacle collection, chunks or full player physics.' };
await writeFile(new URL('movement-result.json', root), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
