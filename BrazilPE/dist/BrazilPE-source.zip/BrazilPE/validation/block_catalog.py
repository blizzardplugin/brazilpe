"""Catalog candidate vtables using the confirmed base collector slot.
RTTI is absent; candidates are addresses, not invented class names or block IDs.
"""
import collections
import json
import struct
from pathlib import Path
from native_image import load_image

image, digest = load_image()
def pointer(address): return struct.unpack('<Q', image.read(address, 8))[0]
candidates = []
for section in image.sections:
    if section['name'] != '__const' or section['segment'] != '__DATA': continue
    data = image.read(section['va'], section['size'])
    for offset in range(0x48, len(data) - 8, 8):
        if struct.unpack_from('<Q', data, offset)[0] != 0x10060ff60: continue
        table = section['va'] + offset - 0x48
        if pointer(table - 16) != 0: continue
        candidates.append({'vtable': hex(table), 'rtti': hex(pointer(table - 8)),
            'methods': {hex(slot): hex(pointer(table + slot)) for slot in [0x18, 0x40, 0x48, 0x2d8, 0x2e0]}})
base_path = [x for x in candidates if x['methods']['0x18'] == '0x100610b60' and
    x['methods']['0x40'] == '0x1006101b4' and x['methods']['0x2d8'] == '0x100610b08' and x['methods']['0x2e0'] == '0x100610b58']
report = {'executable_sha256': digest, 'registry_address': '0x100fc4680',
    'registry_writer_example': '0x1006111a4', 'base_constructor': '0x10060ed48',
    'candidate_count': len(candidates), 'base_path_candidate_count': len(base_path), 'candidates': candidates,
    'limitations': ['RTTI names are absent in these tables.', 'Candidate addresses are not a recovered block ID catalog.',
                   'Subclass overrides have not been reconstructed.']}
Path(__file__).with_name('block-catalog.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'{len(candidates)} candidate vtables; {len(base_path)} with the complete base path; names/IDs unresolved')
