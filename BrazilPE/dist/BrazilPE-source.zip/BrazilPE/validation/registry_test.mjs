import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('./', import.meta.url);
const registry = JSON.parse(await readFile(new URL('../public/registry-profiles.json', root), 'utf8'));
const native = JSON.parse(await readFile(new URL('shapes-reference.json', root), 'utf8'));
const api = (await WebAssembly.instantiate(await readFile(new URL('../public/core.wasm', root)), {})).instance.exports;
const actual = new Uint32Array(api.memory.buffer, api.brazilpe_shape_buffer(), 8);
const expectedNames = new Map([[27,'golden_rail'],[28,'detector_rail'],[66,'rail'],[70,'stone_pressure_plate'],
  [72,'wooden_pressure_plate'],[126,'activator_rail'],[147,'light_weighted_pressure_plate'],[148,'heavy_weighted_pressure_plate']]);
assert.equal(registry.bindings.length, expectedNames.size);
let comparisons = 0;
for (const binding of registry.bindings) {
  assert.equal(binding.name, expectedNames.get(binding.id));
  for (let metadata = 0; metadata < 16; metadata++) {
    const expected = native.getters.find(entry => entry.profile === binding.shape_profile && entry.metadata === metadata);
    assert.equal(api.brazilpe_registered_shape(binding.id, metadata), 1);
    assert.deepEqual(Array.from(actual.slice(0, 6)), expected.expected.bits);
    comparisons++;
  }
}
const before = Array.from(actual);
assert.equal(api.brazilpe_registered_shape(255, 0), 0);
assert.deepEqual(Array.from(actual), before);
const result = { bindings: 8, comparisons, failed: 0,
  scope: 'Declaration/static constructor linkage and getter routing; full native startup and gameplay not validated' };
await writeFile(new URL('registry-result.json', root), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify(result, null, 2));
