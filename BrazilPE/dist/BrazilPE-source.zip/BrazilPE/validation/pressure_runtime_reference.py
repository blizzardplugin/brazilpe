"""Actual client-query loops and server tick controller against bounded fixtures.
No reconstructed formulas are used to produce expected sensor/tick returns.
"""
import json
import math
import random
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *
from native_image import load_image

image, digest = load_image(); uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
for seg in image.segments:
    if not seg['va'] or not seg['vs']: continue
    uc.mem_map(seg['va'], (seg['vs'] + 4095) & ~4095)
    if seg['fs']: uc.mem_write(seg['va'], image.raw[seg['fo']:seg['fo'] + seg['fs']])
base, stop, callback = 0x70000000, 0x71000000, 0x72000000
uc.mem_map(base, 0x60000); uc.mem_map(stop, 4096); uc.mem_map(callback, 4096)
chunk_base = 0x73000000; uc.mem_map(chunk_base, 0x16000 * 16)
block, source, world, dimension = base, base + 0x1000, base + 0x2000, base + 0x4000
entities, nodes, entity_table = base + 0x10000, base + 0x20000, base + 0x30000
position, sensor, results, block_table = base + 0x6000, base + 0x7000, base + 0x8000, base + 0x40000
uc.mem_write(source + 0x18, struct.pack('<Q', world)); uc.mem_write(source + 0x28, struct.pack('<Q', dimension))
provider = base + 0x5000
uc.mem_write(source + 0x20, struct.pack('<Q', provider))
uc.mem_write(provider, struct.pack('<Q', provider + 0x100))
uc.mem_write(provider + 0x110, struct.pack('<Q', callback + 8))
uc.mem_write(world + 0x18, bytes(24))  # Empty separate player vector: no duplicate candidates.
uc.mem_write(entity_table + 0x2b0, struct.pack('<Q', callback))
uc.mem_write(source + 0x68, struct.pack('<3Q', results, results, results + 64 * 8))
output_events = []; current_metadata = 0; current_signal = 0; chunks = {}
def hook(machine, pc, size, user):
    if pc == callback:
        pointer = machine.reg_read(UC_ARM64_REG_X0)
        machine.reg_write(UC_ARM64_REG_W0, struct.unpack('<I', machine.mem_read(pointer + 8, 4))[0])
    elif pc == callback + 4: machine.reg_write(UC_ARM64_REG_W0, current_signal)
    elif pc == callback + 8:
        coordinate = struct.unpack('<2i', machine.mem_read(machine.reg_read(UC_ARM64_REG_X1), 8))
        machine.reg_write(UC_ARM64_REG_X0, chunks.get(coordinate, 0))
    elif pc == 0x1005da064: machine.reg_write(UC_ARM64_REG_W0, current_metadata)
    elif pc == 0x100682070: machine.reg_write(UC_ARM64_REG_X0, base + 0x9000)
    elif pc == 0x1006ff3b4: output_events.append({'kind': 1, 'signal': machine.reg_read(UC_ARM64_REG_W2)})
    elif pc == 0x1005db1cc:
        pointer = machine.reg_read(UC_ARM64_REG_X2)
        value = machine.mem_read(pointer, 2)
        assert value[0] == 70 and machine.reg_read(UC_ARM64_REG_W3) == 3
        output_events.append({'kind': 2, 'metadata': value[1]})
    elif pc == 0x1005e66c8:
        assert machine.reg_read(UC_ARM64_REG_W2) == 3500
        output_events.append({'kind': 3, 'payload': machine.reg_read(UC_ARM64_REG_W4)})
    elif pc == 0x1005df614: output_events.append({'kind': 4, 'delay': machine.reg_read(UC_ARM64_REG_W4)})
    elif pc == 0x1005d97fc: machine.reg_write(UC_ARM64_REG_X0, base + 0xa000)
    machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
for address in (callback, callback + 4, callback + 8, 0x1005da064, 0x100682070, 0x1006ff3b4, 0x1005db1cc, 0x1005e66c8, 0x1005df614, 0x1005d97fc):
    uc.hook_add(UC_HOOK_CODE, hook, begin=address, end=address)
def run(address, registers):
    uc.reg_write(UC_ARM64_REG_SP, base + 0x5f000); uc.reg_write(UC_ARM64_REG_LR, stop)
    for reg, value in registers: uc.reg_write(reg, value)
    uc.emu_start(address, stop, count=100000)
    assert uc.reg_read(UC_ARM64_REG_PC) == stop and uc.reg_read(UC_ARM64_REG_SP) == base + 0x5f000
    return uc.reg_read(UC_ARM64_REG_X0)
rng = random.Random(1510); detections = []
for case in range(160):
    pos = [rng.randint(-40, 40), rng.randint(-8, 40), rng.randint(-40, 40)]
    uc.mem_write(position, struct.pack('<3i', *pos))
    run(0x1006068ac, [(UC_ARM64_REG_X1, position), (UC_ARM64_REG_X8, sensor)])
    bounds = list(struct.unpack('<6f', uc.mem_read(sensor, 24)))
    specs = []
    for index in range(case % 25):
        kind = rng.choice([0x45, 0x13f, 0x100, 0x101, 0x201, 1])
        axis = index % 3; low = [float(p) + 0.1 for p in pos]; high = [p + 0.8 for p in low]
        if index % 4 == 0: low[axis] = bounds[axis + 3]; high[axis] = low[axis] + 1  # Face contact.
        elif index % 4 == 1: low[axis] -= 3; high[axis] -= 3
        pointer = entities + index * 512
        uc.mem_write(pointer, struct.pack('<QI', entity_table, kind)); uc.mem_write(pointer + 0xb4, struct.pack('<6f', *low, *high) + bytes(4))
        node = nodes + index * 32
        uc.mem_write(node, struct.pack('<Q', nodes + (index + 1) * 32 if index + 1 < case % 25 else 0))
        uc.mem_write(node + 0x18, struct.pack('<Q', pointer))
        specs.append({'type': kind, 'box': list(struct.unpack('<6f', struct.pack('<6f', *low, *high)))})
    uc.mem_write(dimension + 0x158, struct.pack('<Q', nodes if specs else 0))
    groups = {}
    for index, spec in enumerate(specs):
        coordinate = (math.floor((spec['box'][0] + spec['box'][3]) * 0.5 / 16), math.floor((spec['box'][2] + spec['box'][5]) * 0.5 / 16))
        groups.setdefault(coordinate, []).append(entities + index * 512)
    if len(groups) > 16: raise ValueError('Chunk fixture bound exceeded')
    chunks.clear()
    for index, (coordinate, pointers) in enumerate(groups.items()):
        chunk = chunk_base + index * 0x16000; chunks[coordinate] = chunk
        uc.mem_write(chunk + 0x28, struct.pack('<2i', *coordinate)); uc.mem_write(chunk + 0x78, b'\4')
        uc.mem_write(chunk + 0x15400, struct.pack('<' + 'Q' * len(pointers), *pointers))
        uc.mem_write(chunk + 0x152e8, struct.pack('<3Q', chunk + 0x15400, chunk + 0x15400 + len(pointers) * 8, chunk + 0x15800))
    for remote in (0, 1):
        uc.mem_write(world + 0x1628, bytes([remote])); uc.mem_write(source + 0x58, bytes(8))
        for variant in range(3):
            selector = 0x100 if variant == 1 else 0x13f
            address = 0x1005dc118 if variant == 0 else 0x1005dc3ec
            run(address, [(UC_ARM64_REG_X0, source), (UC_ARM64_REG_X1, 0 if variant == 0 else selector),
                (UC_ARM64_REG_X2, sensor), (UC_ARM64_REG_X3, 0)])
            begin, end = struct.unpack('<2Q', uc.mem_read(source + 0x68, 16))
            indices = [int((struct.unpack('<Q', uc.mem_read(pointer, 8))[0] - entities) // 512) for pointer in range(begin, end, 8)]
            eligible = [index for index in indices if specs[index]['type'] != 0x45]
            detections.append({'position': pos, 'sensor_bits': list(struct.unpack('<6I', uc.mem_read(sensor, 24))),
                'variant': variant, 'remote': remote, 'entities': specs, 'eligible': len(eligible)})
ticks = []
for weighted in (0, 1):
    table = 0x100ea48e0 if weighted else 0x100e9b590
    uc.mem_write(block_table, image.read(table, 0x3b0))
    uc.mem_write(block_table + 0x388, struct.pack('<Q', callback + 4))
    uc.mem_write(block, struct.pack('<Q', block_table)); uc.mem_write(block + 8, b'\x46')
    for remote in (0, 1):
        uc.mem_write(world + 0x1628, bytes([remote]))
        for metadata in range(16):
            for signal in range(16):
                current_metadata, current_signal = metadata, signal; output_events.clear()
                run(0x100606584, [(UC_ARM64_REG_X0, block), (UC_ARM64_REG_X1, source), (UC_ARM64_REG_X2, position)])
                ticks.append({'weighted': weighted, 'remote': remote, 'metadata': metadata, 'signal': signal, 'events': list(output_events)})
out = Path(__file__).resolve().parent
(out / 'pressure-runtime-reference.json').write_text(json.dumps({'executable_sha256': digest,
    'detections': detections, 'ticks': ticks, 'limitations': [
        'Actual client linked-list and server chunk query paths; chunk-source virtual slot supplied by fixture, native state providers execute.',
        'Separate player vector empty; entity ownership, live chunk lifecycle and concurrency not reconstructed.',
        'Entity type virtual method modeled; other query instructions and type matching execute natively.',
        'Tick signal/metadata reads substituted; component, storage, sound and scheduler sinks intercepted.',
        'Event intent/order verified, not actual world mutation, scheduler internals or redstone propagation.'
    ]}, indent=2) + '\n')
print(f'Native client/server detections: {len(detections)}; native tick/event sequences: {len(ticks)}')
