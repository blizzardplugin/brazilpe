# Etapa ativa: placas de pressão

Esta é a etapa ativa. Os demais sistemas não devem receber novas funcionalidades
enquanto esta etapa não atingir os critérios abaixo, salvo correções necessárias
para integrar e testar as próprias placas. Fotografar a versão atual não muda
o estado de conclusão de qualquer sistema.

## Critérios para encerrar a etapa

1. Confirmar no executável os parâmetros por ID das quatro placas: comum de
   pedra, comum de madeira, ponderada leve e ponderada pesada. Não assumir valores
   de versões mais recentes ou de listas externas.
2. Integrar detecção espacial e filtros de entidades ao mundo jogável, cobrindo
   entrada, permanência, saída e várias entidades em posições diferentes.
3. Aplicar as atualizações de metadado ao mundo, disponibilizar a saída de sinal
   e integrar agendamento, cancelamento e remoção da placa. Validar suporte,
   substituição do bloco, região indisponível e retorno sem atualização.
4. Fechar o ciclo de colocação, interação, quebra, reinício e salvamento no
   protótipo. O formato original de saves continua pertencendo à etapa de saves;
   não será confundido com o formato próprio já existente.
5. Comparar sequências completas com o executável ARM64, documentando as
   dependências que ainda sejam substituídas. Testes de helpers ou pedidos de
   atualização isolados não bastam para declarar a etapa original concluída.

## Resultado da integração funcional

As quatro placas estão integradas ao protótipo. Foram atendidos os cinco
critérios no domínio abaixo: parâmetros nativos verificados por ID, entrada/
permanência/saída com múltiplas entidades, metadados e sinal acessíveis no mundo,
reagendamento, remoção/substituição/suporte, seleção e renderização da forma baixa,
persistência de metadados e prazo restante, e comparação do ciclo completo.

- 24 ciclos completos de contato, consulta, escrita, agendamento e callback
  reentrante ARM64: 2.400 passos comparados com a integração JS/Wasm.
- 12 grupos de testes de integração: filtros, contagem ponderada, suporte,
  cancelamento, disponibilidade, colisão, seleção, saves e rejeição de entradas.
- 11 verificações no Chromium: colocação por UI, ativação, saída, salvamento,
  recarga, remoção do suporte, ponderada pesada e importação inválida.
- Cancelamento geral: comportamento observado comparado junto às 3.840
  operações do agendador. O original apresenta retenção inesperada de registros
  em filas com posições diferentes; o adaptador web usa uma fila isolada por
  placa para evitar interferência entre placas. Essa escolha é uma diferença de
  integração explicitamente conhecida, não prova de equivalência da fila global.

**Integração funcional encerrada no protótipo. A equivalência completa do
subsistema original ainda não está comprovada.** A etapa não inclui circuitos
de redstone, inventário/drops originais, áudio original ou formato original de
saves, que pertencem às suas respectivas etapas. Esses limites não foram
convertidos em alegações de fidelidade geral.

## Domínio e dependências da comparação

As instruções nativas executam o contato, o getter sensor, as consultas por
chunks, leitura de metadados, cópia de vetor, atualização, inserção/heap/despacho
e a chamada reentrante ao tick da placa. Fornecem-se: inicialização do mundo,
método virtual de chunk e tipo de entidade, alocador/memcpy e destinos de escrita,
componente e som. O teste compara metadados, sinais, filas e ordem dos eventos
em todas as quatro placas, incluindo vizinhança indisponível e até 16 entidades.

O adaptador é limitado a 64 placas e 64 candidatos, usa um mundo próprio com
suporte de cubos completos e cadência própria de 20 ticks por segundo. A saída
de sinal é observável por `world.signalAt`; não há propagação por circuitos ainda.
Não houve comparação em iOS/Android físico ou com uma referência não modificada.

## Estado na entrada desta etapa

Já existem rotina sensora, filtros, cálculo de sinal, conversão de metadados,
pedidos de atualização e inserção/despacho básico de ticks comparados com ARM64.
A integração ao mundo jogável, cancelamento e receptores das atualizações
ainda não estavam concluídos.

O visual atual foi capturado diretamente em Chromium/WebGL em
`dist/BrazilPE-atual.png`; é uma captura da aplicação real, não uma imagem gerada
ou uma previsão do visual final. Texturas, interface e terreno continuam próprios.

Após a integração, `dist/BrazilPE-placas.png` mostra as quatro placas na cena.

## Reproduzir a validação

```bash
.venv/bin/python BrazilPE/validation/registry_trace.py
.venv/bin/python BrazilPE/validation/registry_bindings.py
.venv/bin/python BrazilPE/validation/pressure_profiles.py
bash BrazilPE/build.sh
.venv/bin/python BrazilPE/validation/pressure_cycle_reference.py
node BrazilPE/validation/pressure_cycle_compare.mjs
node BrazilPE/validation/pressure_game_test.mjs
node BrazilPE/validation/pressure_browser.mjs
```

O último comando exige servidor HTTP e Chromium/CDP conforme o README.
