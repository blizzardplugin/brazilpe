"""Bundle only public web files; never include IPAs, analysis data or credentials."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
public = root / 'public'
artifact = root / 'dist/BrazilPE-web.zip'
if not (public / 'core.wasm').is_file():
    raise SystemExit('Build core.wasm with bash BrazilPE/build.sh first')
artifact.parent.mkdir(exist_ok=True)
manifest = []
with zipfile.ZipFile(artifact, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(public.rglob('*')):
        if not path.is_file() or path.suffix not in {'.html', '.js', '.css', '.wasm', '.json'}:
            continue
        if path.is_symlink():
            raise ValueError('Unexpected symbolic link in public files')
        data = path.read_bytes()
        name = path.relative_to(public).as_posix()
        info = zipfile.ZipInfo(name, (2020, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
        manifest.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
with zipfile.ZipFile(artifact) as archive:
    if archive.testzip() is not None or 'play.html' not in archive.namelist():
        raise ValueError('Invalid web package')
(artifact.parent / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'{artifact}: {artifact.stat().st_size} bytes; {len(manifest)} public files; ZIP CRC passed')
