# BrazilPE — protótipo web com módulos reconstruídos

As quatro placas de pressão agora funcionam no mundo jogável: escolha uma no
seletor, coloque sobre um bloco, caminhe por cima e observe o sinal no painel.
Há ativação/liberação, contagem ponderada, remoção por perda do suporte e
persistência de metadados/prazo restante no JSON próprio. Os parâmetros foram
confirmados no executável para IDs 70, 72, 147 e 148.

Passaram 24 ciclos completos ARM64 (2.400 passos), 12 grupos de integração e
11 verificações de UI. [STAGE_01.md](STAGE_01.md) registra critérios e limites.
A integração funcional está entregue; equivalência integral do subsistema
original ainda não foi comprovada. Cada placa usa uma fila isolada no adaptador
web, e o restante da simulação, os receptores e a persistência são próprios.

Inserção, heap e despacho de ticks foram reconstruídos em `src/scheduler.c`:
3.840 operações em 80 cenários comparadas com ARM64. O Experimento 06 agora usa
essas rotinas, com acesso ao mundo e execução dos eventos fornecidos pelo
laboratório. Cancelamento observado e callbacks reentrantes de uma placa foram
validados nesta etapa; persistência nativa e alocação dinâmica do agendador
continuam pendentes. Nenhum dos 11 sistemas originais tem equivalência integral comprovada.

`python3 BrazilPE/package_source.py` gera `dist/BrazilPE-source.zip` com os
fontes atuais e entradas de build, sem IPA nem relatórios de engenharia reversa.
O build usa Clang do WASI SDK configurado em `WASI_SDK_PATH`. Os testes nativos
também exigem o IPA fingerprintado no caminho do repositório; ele não é incluído
no pacote de fontes. Esse ZIP é uma cópia da implementação atual, não o fonte
original recuperado da MCPE.

O estado dos 11 sistemas solicitados está em [SYSTEMS.md](SYSTEMS.md).
O Experimento 06 adiciona região sensora e filtros de entidades, com 960
comparações de detecção e 1.024 sequências do controlador de tick ARM64.
Os destinos dos eventos e algumas dependências são substituídos nos testes;
a integração da interface fornece os acessos ao mundo e os destinos dos eventos. O catálogo em `public/catalog.html`
mostra declarações observadas: 256 blocos, 40 entradas do recurso de itens e
38 resumos de modelos. Nenhum desses números significa um sistema completo.

O roteiro de fidelidade atualizado está em [FIDELITY.md](FIDELITY.md) e no pacote
web em `fidelity.html`: 12 etapas com estados, limites e critérios de validação.
O Experimento 05 calcula sinais de placas com rotinas reconstruídas em Wasm.
Passaram 430 comparações com ARM64 de sinal, metadados e intervalo retornado.
Nos testes, a consulta de entidades, a cópia/liberação do vetor das placas
normais e o método virtual de tipo de entidade foram substituídos. Os filtros de
consulta foram observados pelos argumentos 0x100/0x13f, sem reconstruir a busca.
O Experimento 05 permanece isolado; a integração posterior ao mundo jogável
está descrita em STAGE_01.md. Circuitos completos de redstone seguem pendentes.
Para reproduzir: execute `pressure_reference.py`, `build.sh` e
`pressure_compare.mjs`, conforme o roteiro.

O projeto contém uma cena de blocos jogável em WebGL, com movimentação em
WebAssembly, quatro chunks, gravidade, salto, edição de blocos, controles de
teclado/toque e salvamento local com importação/exportação. Abra `public/play.html`
por um servidor HTTP. `public/index.html` mantém os experimentos de análise.

Isso é um **protótipo web novo**, integrado a rotinas reconstruídas do executável.
Não é um port completo do MCPE 0.15.10 nem recuperação do seu fonte original.
As regras de mundo, gravidade, controles, renderização e salvamento são novas.
Os formatos de mundo do Minecraft, inventário, crafting e multiplayer não foram
implementados. A compatibilidade física com Safari/iOS e Android não foi testada.

| Parte | Entrega e limite da evidência |
| --- | --- |
| Consulta ao mundo | Limites e ordem de visita reconstruídos de `0x1005dce10`; 85 caixas e 4.155 visitas comparadas com ARM64. Chunks originais e formas de blocos não reconstruídos. |
| Blocos/chunks | Mundo novo 32×32×128, quatro chunks com indexação em memória 16×128×16 reconstruída; provedores, geração, IDs e armazenamento em disco originais pendentes. |
| Atualização por frame | Loop de tempo fixo, controles, gravidade e salto novos; usa o chamador de movimento já reconstruído. |
| Renderização/salvamento | WebGL com cores e grade procedurais próprios; novo JSON versionado, localStorage e importação/exportação. |
| Plataformas | Validado em Chromium com GPU emulada e toque/viewport móvel. Safari, iPhone e Android físicos pendentes. |

Um pacote estático é gerado em `dist/BrazilPE-web.zip`. Ele inclui o Wasm e os
arquivos públicos, sem IPA, certificados, dados de engenharia reversa ou assets
do Minecraft. Não há dependências web baixadas durante o uso do pacote.

As rotinas reconstruídas são:

| Rotina ARM64 | Comportamento comprovado pelas instruções |
| --- | --- |
| `0x1004e4b64` | Lê float do objeto em `+0xd4` e multiplica por `0.5` |
| `0x1004e4cbc` | Retorna o float constante em `0x100be6b14` (`0.1`) |
| `0x1002cb9cc` | Retorna o inteiro `0x13f` |

O nome semântico do campo `+0xd4` não foi recuperado. A interface web o apresenta
como entrada numérica. Seu desenho usa Canvas 2D e é ilustrativo; não foi extraído
do renderizador do jogo. A margem portada é a original, não a configuração do
módulo de hitbox acrescentado ao IPA.

## Build e validação

O compilador WASI SDK 24 está em `/workspace/tools/wasi`. O alvo é WebAssembly
sem libc, imports, SDK Apple ou runtime WASI. Pode-se usar outra instalação por
`WASI_SDK_PATH`.

Na pasta `/workspace/brazilpe`:

```bash
bash BrazilPE/build.sh
.venv/bin/python BrazilPE/validation/reference.py
node BrazilPE/validation/compare.mjs
.venv/bin/python BrazilPE/validation/geometry_reference.py
node BrazilPE/validation/geometry_compare.mjs
.venv/bin/python BrazilPE/validation/movement_calls.py
.venv/bin/python BrazilPE/validation/movement_reference.py
node BrazilPE/validation/movement_compare.mjs
.venv/bin/python BrazilPE/validation/world_reference.py
node BrazilPE/validation/world_compare.mjs
.venv/bin/python BrazilPE/validation/block_catalog.py
.venv/bin/python BrazilPE/validation/block_reference.py
node BrazilPE/validation/block_compare.mjs
.venv/bin/python BrazilPE/validation/chunk_reference.py
node BrazilPE/validation/chunk_compare.mjs
.venv/bin/python BrazilPE/validation/provider_reference.py
node BrazilPE/validation/provider_compare.mjs
.venv/bin/python BrazilPE/validation/shapes_reference.py
node BrazilPE/validation/shapes_compare.mjs
.venv/bin/python BrazilPE/validation/registry_trace.py
.venv/bin/python BrazilPE/validation/registry_bindings.py
# Se o header gerado mudar, recompile antes do teste de roteamento:
bash BrazilPE/build.sh
node BrazilPE/validation/registry_test.mjs
.venv/bin/python BrazilPE/validation/block_world_reference.py
node BrazilPE/validation/block_world_compare.mjs
node BrazilPE/validation/game_test.mjs
python3 BrazilPE/package_web.py
```

`reference.py` verifica hash e bytes das rotinas antes de executar as instruções
ARM64 reais em Unicorn. `compare.mjs` instancia o Wasm e compara os resultados
bit a bit, incluindo zero negativo, subnormais, extremos e infinitos. Isso valida
essas rotinas e o pipeline de compilação, não execução física em iOS ou o jogo.

Resultado desta execução: 1.037 entradas do cálculo de sombra e duas verificações
de retorno constante passaram (1.039 comparações), sem divergências. A segunda
etapa passou em 8.310 comparações: 1.385 cenários executados em seis rotinas
geométricas. Os cenários incluem faces em contato, separação, sobreposição,
caixas degeneradas, pontos nas faces, movimento em ambos os sentidos, dois valores
do parâmetro de modo e entradas pseudoaleatórias com seed fixa. Também foram
verificadas três rejeições de entradas inválidas no adaptador JavaScript.

No Chromium, passaram 25 verificações dos experimentos: carregamento do Wasm, controles, cálculo
de sombra, interseção, contato, contenção de ponto e movimento limitado. A página
também passou na verificação de largura em viewport 390×844. Isso não comprova
funcionamento no Safari ou em aparelhos físicos.

Para repetir as verificações do navegador, com o servidor abaixo em execução,
inicie Chromium em um terminal separado:

```bash
chromium --headless --no-sandbox --disable-dev-shm-usage \
  --disable-background-networking --enable-unsafe-swiftshader \
  --remote-debugging-address=127.0.0.1 \
  --remote-debugging-port=9222 \
  --user-data-dir=/tmp/brazilpe-cdp-validation about:blank
```

Depois execute `node BrazilPE/validation/browser.mjs` a partir do repositório.
Para a cena 3D, execute também `node BrazilPE/validation/game_browser.mjs`.
O teste 3D usa SwiftShader para WebGL neste contêiner. Essa opção não é necessária
em aparelhos com uma implementação WebGL funcional.
O uso de `--no-sandbox` é específico ao navegador de teste neste contêiner; a
página não exige essa opção para usuários. O teste gera resumo e screenshot
em `validation`, ignorados pelo Git. Encerre o Chromium de teste ao terminar.

## Abrir a demonstração

```bash
cd /workspace/brazilpe/BrazilPE/public
python3 -m http.server 8080 --bind 127.0.0.1
```

Sirva a pasta `public` por HTTP/HTTPS e abra `play.html` para a cena 3D.
Ela contém somente HTML, CSS, JavaScript
e o Wasm gerado. Para acesso por outros aparelhos, hospede essa pasta num servidor
acessível a eles. Não há APK ou IPA sendo executado dentro da página.

Navegadores modernos de PC, Android e iOS suportam as APIs usadas. Compatibilidade
nessas plataformas exige testes reais; não é estabelecida pelos testes em Node.

## Segunda etapa: vetores e colisão entre caixas

| Rotina ARM64 | Comportamento reconstruído |
| --- | --- |
| `0x1006f6e78` | Interseção estrita entre duas caixas AABB |
| `0x1006f7644` | Contenção estrita de um ponto |
| `0x1006f6720` | Translação dos seis limites por um vetor XYZ |
| `0x1006f6c08` | Limitação/correção do deslocamento em X |
| `0x1006f6cd8` | Limitação/correção do deslocamento em Y |
| `0x1006f6da8` | Limitação/correção do deslocamento em Z |

As instruções indicam seis floats: mínimos XYZ em offsets 0, 4, 8 e máximos XYZ
em 12, 16, 20. A translação escreve também um byte em `+24`, verdadeiro quando
os seis limites resultantes são iguais ao vetor global zero. A identidade do
vetor é assumida a partir de armazenamento zero-fill na imagem inicial; a
inicialização completa do aplicativo não foi executada. O chamador da função
original retorna a estrutura pelo ponteiro em X8; o adaptador Wasm usa um buffer.

No buffer de 32 floats exposto por `brazilpe_geometry_buffer`, a primeira caixa
ocupa 0–5, a segunda 8–13, o ponto/vetor 16–18 e a caixa traduzida 24–29. O slot
30 contém o indicador zero convertido para float. O layout do buffer é uma API
nova do port; não é apresentado como uma estrutura recuperada do jogo.

Contato não conta como interseção e um ponto na face não conta como contido.
O bit baixo do parâmetro de modo evita a correção de penetração quando as caixas
já se sobrepõem. O nome e o significado original desse parâmetro não foram
recuperados. A rotina não é um resolvedor geral de física: ela calcula um eixo,
depende das caixas fornecidas e pode retornar uma correção de sobreposição.

`geometry-evidence.json` guarda bytes e disassembly das seis funções, com o hash
do executável analisado. `geometry-reference.json` guarda entradas e resultados
da emulação, e `geometry-result.json` registra a comparação. Os arquivos gerados
ficam ignorados no Git, mas os scripts de reprodução estão em `validation`.

A comparação de geometria cobre entradas finitas representáveis em float32.
Não estabelece equivalência para NaN/infinito, estruturas corrompidas, chamadas
com memória sobreposta ou integração com a física do jogo. O adaptador da página
rejeita entradas não finitas antes de chamar o Wasm.

## Terceira etapa: chamador de movimentação

O levantamento de chamadas BL diretas identificou `0x1002bd860`, que chama
as rotinas de limitação em Y, X e Z, nessa ordem. O código foi reconstruído em
`src/movement.c`, reutilizando a geometria da etapa anterior. O nome original
da função e sua classe proprietária não foram recuperados.

O comportamento observado no objeto é:

- A caixa ocupa `+0xd0`; as velocidades observadas ficam em `+0xa8..+0xb0`.
- A posição calculada é o centro da caixa e fica em `+0xb4..+0xbc`.
- O byte `+0xcc`, quando ativo, leva ao ramo de translação sem consulta ao mundo.
- O byte `+0xcd` é atualizado quando o deslocamento Y solicitado é negativo e
  difere do permitido; foi apresentado como indicador de chão.
- Quando uma componente solicitada difere da permitida, sua velocidade é zerada.
- No ramo sem colisão, os bytes/velocidades acima são preservados.

O chamador calcula uma caixa de busca e chama `0x1005dce10` para obter obstáculos.
A consulta ao mundo ainda **não foi portada**. No teste ARM64 ela é a única chamada
substituída: retorna uma lista fornecida pelo cenário, com caixas de stride 28
bytes. Todo o chamador e seus helpers de geometria, translação e centro executam
suas instruções reais. Não foi necessário substituir as rotinas matemáticas.

Foram executados 517 cenários, com 2.585 comparações de caixa final, posição,
velocidade, deslocamento permitido e indicador de chão. Os testes incluem chão,
paredes, cantos, diferentes ordens de obstáculos, sobreposição inicial, ramo sem
colisão, lista vazia e 64 obstáculos. A emulação verifica retorno, pilha e dois
registradores preservados. A comparação é exata nos bits float32 para as entradas
testadas. O centro preserva a operação FMADD do original por intermediários double.

O adaptador Wasm aceita no máximo 64 obstáculos, campos numéricos no intervalo
±1.000.000, caixas ordenadas e flags 0/1. Retorna 1 em sucesso e 0 para entrada
inválida, sem modificar o estado nesse caso. Seu buffer tem 544 floats: caixa em
0–5, velocidade em 8–10, solicitação em 12–14, posição em 16–18, deslocamento
permitido em 20–22, indicador em 24 e obstáculos a partir de 32, com stride de
8 floats. Esse layout é novo e pertence ao adaptador do port.

Os testes agora carregam o executável diretamente do IPA do repositório e leem
LC_FUNCTION_STARTS. Não exigem o projeto Ghidra ou os outputs de análise anteriores.
`movement-evidence.json` registra bytes/disassembly e limites da emulação.
`movement-reference.json` registra os cenários e resultados originais;
`movement-result.json` registra as comparações. A página demonstra um passo
isolado; a ilustração Canvas continua sendo nova, não o renderizador do jogo.

## Próximos marcos

1. Investigar `0x1005dce10` e suas dependências para reconstruir a coleta de
   obstáculos de blocos/entidades e a seleção da região do mundo consultada.
2. Reconstruir estruturas de blocos/chunks e um mundo mínimo que alimente essa
   coleta. Confirmar formatos e comportamentos por comparação com ARM64.
3. Investigar o fluxo por frame: controles, velocidade, gravidade e interação
   com a função de movimento. Não assumir constantes a partir de outros jogos.
4. Conectar o mundo e os módulos validados a uma visualização WebGL, depois
   implementar salvamento e interface móvel.
5. Validar em Safari/iOS e Android físicos; só depois ampliar inventário,
   crafting e multiplayer conforme a cobertura de reconstrução obtida.

A viabilidade do jogo completo ainda depende de recuperar e validar esses
subsistemas. A análise Ghidra existente é parcial e não equivale ao fonte do motor.

## Integração das etapas 4–7 no protótipo

`src/world_query.c` reconstrói o cálculo das coordenadas inteiras consultadas
pela função nativa quando `w4=0` e `x3=null`. As visitas seguem X externo, Z
intermediário, Y interno. O máximo de cada eixo é calculado com adição float32
antes do floor; o mínimo Y também subtrai um. Os testes executam a função nativa
com lookup de blocos retornando ar e método virtual de colisão retornando falso.
Isso isola o percurso; não comprova formas de blocos, disponibilidade de chunks,
barreiras abaixo do mundo ou registros de entidades. Esses callbacks seguem
necessários no teste da função original. O código-fonte de chunks do jogo não foi
recuperado por essa análise.

`public/game/world.js` usa chunks densos Uint8Array, agora com a indexação nativa
de 16×128×16, e um terreno inicial fixo,
com paredes e alguns obstáculos. A coleta calcula a caixa varrida, consulta os
limites do módulo Wasm e fornece cubos que intersectam essa região ao módulo
de movimento. O teste integrado confirma chão e paredes nesse modelo novo.
Consulta acima de 8.192 visitas ou mais de 64 obstáculos interrompe o movimento
com diagnóstico; não trunca a lista silenciosamente. A camada base e os limites
laterais do mundo são protegidos contra edição.

`public/game/physics.js` aplica gravidade e velocidade próprias em passos de
1/60 s; `main.js` limita a recuperação de frames atrasados. O fluxo de colisão
é o componente reconstruído de `0x1002bd860`, mas as constantes e as decisões de
controle/gravity não vieram do executável. Os parâmetros editáveis estão em
`public/game/config.js`. A reconstrução do loop original por frame continua
pendente; este protótipo não serve como prova de equivalência dessa física.

`renderer.js` emite somente faces visíveis, guarda buffers por chunk e refaz
chunks afetados por edições. Os shaders, as cores, a grade de blocos, a câmera e
o seletor por raio são novos. Não foram copiados do renderizador iOS. Há teste
de perda/restauração do contexto WebGL, além dos testes de carregamento e controles.

`save.js` salva apenas edições e pose no formato `BrazilPE-web-world`, versão 1.
Importações são limitadas a 1 MiB, 8.192 edições, coordenadas e IDs válidos, sem
blocos duplicados ou personagem dentro de um bloco. O arquivo inteiro é validado
antes de substituir o mundo atual. Erros de armazenamento e arquivos inválidos
aparecem na interface. O salvamento é manual; recarregar a página não restaura
automaticamente uma sessão, mas o botão Carregar restaura o último save local.

Os testes novos passaram em 12 grupos de integração em Node e 21 verificações
da cena no Chromium, incluindo salvamento após reload, arquivos reais de
importação/exportação, keyboard, toque emulado e restauração do contexto gráfico.
Esses resultados se somam aos testes dos módulos anteriores; não transformam
partes novas em rotinas comprovadamente iguais às do MCPE.

## Testar em aparelhos físicos

Extraia `dist/BrazilPE-web.zip` no seu computador e sirva a pasta extraída por
HTTP/HTTPS. Para teste na mesma rede local, use:

```bash
python3 -m http.server 8080 --bind 0.0.0.0
```

No aparelho na mesma rede, abra o endereço do computador com porta 8080 e caminho
`/play.html`. Uma hospedagem estática HTTPS também pode servir todos os arquivos
do pacote. Nenhuma hospedagem foi publicada nesta tarefa.

Em Safari/iOS e Chrome/Android físicos, verifique carregamento, olhar por arrasto,
movimento, salto, colisões, colocar/quebrar blocos, salvar/carregar após fechar a
página e importar/exportar um mundo. Registre modelo do aparelho, versão do sistema
e navegador, e qualquer erro mostrado. Viewport móvel em Chromium não substitui
essas verificações. Não há aparelhos físicos conectados a este ambiente.

## Reconstrução adicional: colisão de blocos e leitura de chunks

O coletor base foi localizado em `0x10060ff60`, no slot `0x48` da tabela virtual
confirmada em `0x100e8ac00`. Ele cria uma AABB temporária, chama o slot `0x18`,
verifica o bit baixo do indicador em `+24`, testa interseção estrita e acrescenta
a caixa num vetor com stride de 28 bytes. O caminho sem colisão em `0x100605dfc`
retorna zero. A tabela desse caminho é distinta, em `0x100e89628`.

No caminho base, o slot `0x18` chama `0x40`, que chama `0x2d8`, que por sua vez
obtém metadados e chama `0x2e0`. O getter base de forma retorna o objeto em `+0x84`.
A forma é copiada, as coordenadas inteiras são convertidas para float32 e somadas
aos seis limites. O indicador é preservado, mesmo após deslocar a forma.
O construtor em `0x10060ed48` inicializa essa forma por `0x1006f6268`, com caixa
unitária. Isso justifica a caixa padrão desse caminho; não estabelece as formas
ou regras de subclasses como escadas, cercas e portas.

`src/block_collision.c` reproduz esse comportamento para formas fornecidas,
incluindo rejeição por contato e pelo bit baixo do indicador. A API retorna
1 quando uma caixa foi coletada, 0 quando não foi e -1 para entrada fora do
domínio suportado. O protótipo agora usa esse módulo para coletar os obstáculos
cúbicos, substituindo o teste simplificado em JavaScript.

O teste `block_reference.py` executa o coletor e seus métodos virtuais reais,
substituindo somente a leitura de metadados (ignorada pelo getter base de forma).
São 960 casos, com comparação exata de aceitação, limites float32 e indicador.
Há formas parciais sintéticas para testar o mecanismo; elas não são apresentadas
como formas recuperadas de tipos específicos do jogo. A capacidade do vetor é
pré-reservada; o crescimento pelo alocador nativo não foi testado.

`block_catalog.py` encontra 121 tabelas virtuais candidatas com esse coletor,
59 das quais compartilham todo o caminho base. Os nomes RTTI estão ausentes
nessas tabelas. Os endereços candidatos não foram convertidos em nomes ou IDs
inventados. O registro é observado em `0x100fc4680`, com exemplo de escrita
em `0x1006111a4`; a inicialização completa desse registro continua pendente.

Os leitores em `0x1005d9f4c` e `0x1005da064` estabelecem:

- Altura válida de Y: 0 a 127; chunk horizontal de 16×16.
- Coordenada do chunk: X e Z com deslocamento aritmético de quatro bits.
- Coordenadas locais: X e Z mascarados com 15.
- Índice: `y + ((x & 15) * 16 + (z & 15)) * 128`.
- IDs de um byte em `chunk + 0xa88`, totalizando 32.768 bytes.
- Metadados de quatro bits em `chunk + 0x8a88`, dois por byte, totalizando 16.384.
- Coordenadas usadas pelo cache em `chunk + 0x28`.

`src/chunk_storage.c` reproduz a indexação e a leitura. O teste executa os leitores
nativos, inclusive o cache, a conversão de coordenadas negativas e a seleção de
nibbles, substituindo os provedores `0x10067301c` e `0x100673638` por chunks de
teste. Passaram 696 coordenadas, com 1.392 comparações de ID/metadados. A função
de leitura usa zero como fallback da imagem inicial; não foi executada toda a
inicialização do aplicativo. O layout é **em memória**, não o formato de saves
ou de banco de dados do Minecraft.

`block_world_reference.py` executa a consulta original `0x1005dce10` junto dos
leitores de ID/metadados, dos provedores e dos métodos virtuais de colisão originais.
Somente a busca virtual de chunks, slot `0x10` da fonte, é substituída. Em 123 regiões, foram comparadas as listas
de caixas, em ordem e com igualdade exata de bits. Os IDs das fixtures são
associações de teste, não um catálogo de IDs reconstruído do jogo.

Nesse teste, `w4=0` desativa o caminho de disponibilidade de chunks/barreiras,
e `x3=null` desativa a saída auxiliar por bloco. Portanto, ele ainda não comprova
a consulta inteira com os parâmetros usados pelo chamador de movimento original,
nem a geração/carregamento de chunks. Esses caminhos, as subclasses de blocos,
iluminação, atualização original por frame e formatos de disco continuam pendentes.

Os provedores em `0x100673638` e `0x10067301c` chamam o slot `0x10` da fonte
de chunks e retornam null se ele não encontrar um chunk. Quando existe um chunk,
leem com LDARB o byte em `+0x78`. O primeiro retorna o ponteiro somente se o estado
for maior que 3; o segundo, maior que 1. Os nomes originais desses estados não foram
recuperados. `brazilpe_chunk_available` reproduz a seleção para estados de um byte
e modo 0/1, retornando -1 para entrada inválida.

`provider_reference.py` executa ambos os provedores e seu getter de estado reais,
substituindo somente a chamada virtual da fonte. Passaram 1.024 combinações de
estado, presença do chunk e provedor. A leitura com semântica acquire foi observada
nas instruções, mas a concorrência e as transições assíncronas de estado não foram
reproduzidas no teste de emulação. A origem dos chunks e sua criação/carregamento
ainda não estão reconstruídas.

## Getters de formas dependentes de metadados

`src/block_shapes.c` porta três perfis: a caixa padrão e duas rotinas de forma
observadas no executável. Os números dos perfis são uma API nova, não IDs originais.

| Perfil | Rotina | Retorno local |
| --- | --- | --- |
| 0 | `0x1006f6268` | Caixa unitária padrão |
| 1 | `0x1006063b8` | X/Z de 1/16 a 15/16; Y de 0 a 1/16 quando metadado=0, ou 1/32 caso contrário |
| 2 | `0x1006085f0` | X/Z de 0 a 1; Y de 0 a 5/8 para metadados 2–5, ou 1/8 nos demais casos |

São 768 comparações exatas dos seis floats e do indicador: três getters, cada
um executado com metadados 0–255. Esse domínio cobre o parâmetro isolado; a leitura
de metadados do chunk continua sendo de quatro bits. Metadados fora de 0–255
e perfis desconhecidos são rejeitados pela API sem mudar a saída do getter.

A tabela em `0x100e89d70` foi vinculada a uma escrita no construtor
`0x1006062e4..0x1006062f0`. No caminho observado, o coletor base chama `0x100606444`,
que obtém a forma por `0x100606364` e `0x1006063b8`, copiando os limites locais
sem chamar o helper de translação. O teste inicial revelou essa diferença: somar
a posição como no caminho base produzia resultado diferente do nativo. A API
`brazilpe_thin_collect` preserva a ausência de translação, ignorando BlockPos para
essa operação. Passaram 240 comparações do caminho com 16 metadados, três posições
e cinco caixas de consulta. A leitura de metadados é o único callback substituído
nesse teste; os métodos virtuais e o coletor executam as instruções originais.

Isso, isoladamente, não estabelece qual classe concreta viva usa esse caminho
durante uma partida. A etapa de associação abaixo identifica declarações de nomes/IDs
e tabelas derivadas; chamadores e regras de ativação continuam pendentes. O perfil 2 foi validado somente como
getter; não foi confundido com a colisão de sua classe, que possui outro método
no slot `0x40`. Os perfis não foram atribuídos aos blocos do mundo jogável.

O Experimento 04 em `index.html` permite alterar perfil/metadado e observar os
retornos em Wasm. O desenho continua sendo uma ilustração nova. Os dados nativos,
bytes, disassembly e a diferença de translação estão registrados em
`shapes-reference.json` e `shapes-evidence.json`, reproduzíveis pelos scripts.

## Associações observadas do registro original

`registry_trace.py` executa as instruções do inicializador `0x10060aa68`, mas
substitui todos os seus callees e métodos virtuais fluent por objetos sintéticos.
Ele captura argumentos de fábricas antes das chamadas e verifica que cada nome
corresponde exatamente a uma string literal no executável original. Foram
capturados 256 argumentos de ID: 192 com nome e 64 placeholders de nome vazio.
O caminho de fallback usa a string vazia no arquivo em `0x100da535c`.

**Não foi executada a inicialização real completa.** Os objetos sintéticos são
registrados no modelo para permitir que o controle do inicializador continue.
Os números extraídos representam declarações observadas com essas substituições;
não comprovam 256 tipos de gameplay funcionais, overrides em runtime ou efeitos
dos construtores. O modelo tem limite de instruções/alocações e exige retorno
normal para aceitar o relatório.

`registry_bindings.py` verifica oito ligações estáticas entre a declaração, a
fábrica, o helper de criação, o construtor e uma escrita da tabela virtual no
ponteiro do objeto. Depois lê o slot `0x2e0` da tabela original para confirmar
que aponta para o getter já testado. Isso permite as seguintes associações:

| ID declarado | Nome literal | Perfil do getter | Tabela virtual final |
| --- | --- | --- | --- |
| 27 | golden_rail | 2 | `0x100e9b1f8` |
| 28 | detector_rail | 2 | `0x100e8ec70` |
| 66 | rail | 2 | `0x100e9c070` |
| 70 | stone_pressure_plate | 1 | `0x100e9b590` |
| 72 | wooden_pressure_plate | 1 | `0x100e9b590` |
| 126 | activator_rail | 2 | `0x100e89290` |
| 147 | light_weighted_pressure_plate | 1 | `0x100ea48e0` |
| 148 | heavy_weighted_pressure_plate | 1 | `0x100ea48e0` |

As placas normais são criadas por `0x10064d644`; as ponderadas por `0x10065eb54`.
Ambos chamam `0x1006062c8` antes de escrever a tabela derivada. Os oito vínculos
não foram obtidos de uma lista externa de IDs. Os endereços de chamadas e os
argumentos literais vieram desta imagem fingerprintada.

A etapa gera `src/registry_profiles.h` e `public/registry-profiles.json`.
`brazilpe_registered_shape(id, metadata)` usa somente esses oito vínculos para
rotear ao getter reconstruído. IDs desconhecidos são rejeitados sem mudar sua
saída. Passaram 128 comparações dos retornos desse roteamento com os getters
ARM64, usando os oito IDs e os 16 valores de metadado. O domínio validado é o
**parâmetro bruto do getter**; isso não implementa interpretação completa de
metadados, energia, sensores ou orientações pelo restante do jogo.

O Experimento 04 agora permite selecionar esses nomes/IDs observados. A paleta,
os IDs e os saves do protótipo jogável continuam sendo próprios; não foram
remapeados silenciosamente nem convertidos para o formato original. O caminho
sem translação observado nas placas ainda exige análise dos chamadores e do
uso runtime. Os trilhos continuam com validação de getter, não de colisão ou
simulação de veículos. Esses comportamentos são próximos alvos de reconstrução.
