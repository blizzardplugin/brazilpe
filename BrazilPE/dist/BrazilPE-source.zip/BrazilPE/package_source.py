"""Bundle explicit source extensions and build inputs, excluding IPA and reports."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

root = Path(__file__).resolve().parent
repo = root.parent
paths = []
for folder, suffixes in [('src', {'.c', '.h'}), ('validation', {'.py', '.mjs'}),
                         ('public', {'.html', '.js', '.css', '.json', '.wasm'})]:
    paths.extend(path for path in (root / folder).rglob('*') if path.is_file() and path.suffix in suffixes)
paths.extend(root / name for name in ['README.md', 'FIDELITY.md', 'SYSTEMS.md', 'build.sh',
                                     'package_web.py', 'package_source.py', '.gitignore'])
paths.extend(repo / name for name in ['src/macho.py', 'requirements.txt', 'requirements-test.txt', 'VALIDATION.json'])
artifact = root / 'dist/BrazilPE-source.zip'; artifact.parent.mkdir(exist_ok=True)
with ZipFile(artifact, 'w', compression=ZIP_DEFLATED) as archive:
    for path in sorted(set(paths)):
        if path.is_symlink(): raise ValueError('Symlink in source inputs')
        info = ZipInfo(path.relative_to(repo).as_posix(), (2020, 1, 1, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        archive.writestr(info, path.read_bytes())
with ZipFile(artifact) as archive:
    if archive.testzip() is not None: raise ValueError('Source ZIP CRC failed')
print(f'{artifact}: {artifact.stat().st_size} bytes; {len(paths)} source/build inputs; ZIP CRC passed')
