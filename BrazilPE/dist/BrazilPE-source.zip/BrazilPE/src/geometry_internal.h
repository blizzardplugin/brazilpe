#ifndef BRAZILPE_GEOMETRY_INTERNAL_H
#define BRAZILPE_GEOMETRY_INTERNAL_H
float brazilpe_clip_boxes(const float *obstacle, const float *moving,
                         int axis, float desired, int mode);
#endif
