/* Block traversal bounds inferred from 0x1005dce10, w4=0 and x3=null.
 * Chunk availability, below-world barriers and block virtual dispatch are not ported. */
static float query[6];
static int ranges[6];

unsigned long brazilpe_query_buffer(void) { return (unsigned long)query; }
unsigned long brazilpe_query_ranges(void) { return (unsigned long)ranges; }

static int floor_f32(float value) {
    int integer = (int)value;
    return (float)integer > value ? integer - 1 : integer;
}

int brazilpe_query_bounds(void) {
    for (int i = 0; i < 6; i++) {
        if (!(query[i] >= -1000000.0f && query[i] <= 1000000.0f)) return 0;
    }
    for (int axis = 0; axis < 3; axis++) if (query[axis] > query[axis + 3]) return 0;
    ranges[0] = floor_f32(query[0]);
    ranges[1] = floor_f32(query[1] - 1.0f);
    ranges[2] = floor_f32(query[2]);
    for (int axis = 0; axis < 3; axis++) ranges[axis + 3] = floor_f32(query[axis + 3] + 1.0f) + 1;
    return 1;
}
