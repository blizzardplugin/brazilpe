/* 0x1005df614 insertion, 0x1005df794 bounded dispatch, native heap helpers.
 * Availability and current ID are supplied by the caller. Dispatch returns
 * event records instead of entering a virtual block method inside Wasm. */
#include <stdint.h>
enum { scheduler_capacity = 128 };
typedef struct {
    int32_t x, y, z;
    uint8_t id, padding[3];
    uint64_t deadline;
} TickEntry;
_Static_assert(sizeof(TickEntry) == 24, "Native tick entry stride");
static TickEntry queue[scheduler_capacity], dispatched[scheduler_capacity];
static int size, dispatch_size;
static uint64_t current_time;
unsigned long brazilpe_scheduler_buffer(void) { return (unsigned long)queue; }
unsigned long brazilpe_scheduler_dispatched(void) { return (unsigned long)dispatched; }
int brazilpe_scheduler_count(void) { return size; }
int brazilpe_scheduler_dispatch_count(void) { return dispatch_size; }
void brazilpe_scheduler_reset(uint32_t low, uint32_t high) {
    size = 0; dispatch_size = 0; current_time = ((uint64_t)high << 32) | low;
}
static int valid(int x, int y, int z, int id, int available, int current_id) {
    return x >= -1000000 && x <= 1000000 && y >= -1000000 && y <= 1000000 &&
        z >= -1000000 && z <= 1000000 && id >= 0 && id <= 255 &&
        (available == 0 || available == 1) && current_id >= 0 && current_id <= 255;
}
int brazilpe_scheduler_add(int x, int y, int z, int id, int delay, int available, int current_id) {
    if (!valid(x, y, z, id, available, current_id)) return -1;
    if (available == 0) { dispatch_size = 0; return 0; }
    if (delay >= 0 && size == scheduler_capacity) return -2;
    dispatch_size = 0;
    TickEntry entry = {x, y, z, (uint8_t)id, {0, 0, 0}, current_time + (uint64_t)(uint32_t)delay};
    if (delay < 0) {
        if (current_id != 0 && current_id == id) { dispatched[0] = entry; dispatched[0].deadline = current_time; dispatch_size = 1; }
        return 1;
    }
    int hole = size++;
    while (hole > 0) {
        int parent = (hole - 1) / 2;
        if (queue[parent].deadline <= entry.deadline) break;
        queue[hole] = queue[parent]; hole = parent;
    }
    queue[hole] = entry;
    return 1;
}
static TickEntry pop(void) {
    TickEntry first = queue[0];
    size--;
    if (size == 0) return first;
    TickEntry replacement = queue[size];
    int hole = 0;
    while (hole * 2 + 1 < size) {
        int child = hole * 2 + 1;
        if (child + 1 < size && queue[child].deadline > queue[child + 1].deadline) child++;
        /* Original sift-down moves equal children as well, preferring left. */
        if (queue[child].deadline > replacement.deadline) break;
        queue[hole] = queue[child]; hole = child;
    }
    queue[hole] = replacement;
    return first;
}
int brazilpe_scheduler_process(uint32_t low, uint32_t high, int budget, int available, int current_id) {
    if (budget < 0 || budget > scheduler_capacity || (available != 0 && available != 1) || current_id < 0 || current_id > 255) return -1;
    uint64_t now = ((uint64_t)high << 32) | low;
    int maximum = size < budget ? size : budget, processed = 0;
    dispatch_size = 0;
    while (size > 0 && processed < maximum && queue[0].deadline <= now) {
        TickEntry entry = pop(); current_time = entry.deadline;
        if (available != 0 && current_id != 0 && current_id == entry.id) dispatched[dispatch_size++] = entry;
        processed++;
    }
    current_time = now;
    return processed > 0;
}
