/* Reconstructed from the fingerprinted ARM64 routines, not recovered source. */
float brazilpe_shadow_radius(float field_0xd4) {
    return field_0xd4 * 0.5f;
}

float brazilpe_original_pick_margin(void) {
    return 0.1f;
}

unsigned int brazilpe_player_type(void) {
    return 0x13fu;
}
