/* In-memory layout observed in 0x1005d9f4c and 0x1005da064.
 * This is not the disk/LevelDB representation or the chunk provider. */
static unsigned char chunk_bytes[32768 + 16384];
unsigned long brazilpe_chunk_buffer(void) { return (unsigned long)chunk_bytes; }
int brazilpe_chunk_available(int state, int provider_mode) {
    if (state < 0 || state > 255 || (provider_mode != 0 && provider_mode != 1)) return -1;
    return state > (provider_mode ? 1 : 3);
}
int brazilpe_chunk_index(int x, int y, int z) {
    if (y < 0 || y > 127) return -1;
    unsigned int local_x = (unsigned int)x & 15u;
    unsigned int local_z = (unsigned int)z & 15u;
    return y + (int)((local_x * 16u + local_z) * 128u);
}
int brazilpe_chunk_read(int x, int y, int z, int available) {
    int index = brazilpe_chunk_index(x, y, z);
    if (!available || index < 0) return 0;
    return (int)chunk_bytes[index];
}
int brazilpe_chunk_metadata(int x, int y, int z, int available) {
    int index = brazilpe_chunk_index(x, y, z);
    if (!available || index < 0) return 0;
    unsigned int packed = chunk_bytes[32768 + index / 2];
    return (int)((index & 1) == 0 ? packed & 15u : packed >> 4);
}
