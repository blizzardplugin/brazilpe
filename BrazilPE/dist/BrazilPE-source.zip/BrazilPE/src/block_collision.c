/* Base dispatch chain: 0x10060ff60 -> slots 0x18/0x40/0x2d8/0x2e0.
 * Local AABB lives at object +0x84; its flag byte is preserved on translation. */
#include "block_shapes_internal.h"
static float block_data[32];
static int block_position[3];
unsigned long brazilpe_block_buffer(void) { return (unsigned long)block_data; }
unsigned long brazilpe_block_position(void) { return (unsigned long)block_position; }

static int collect(int translated) {
    for (int i = 0; i < 6; i++) {
        if (!(block_data[i] >= -1000000.0f && block_data[i] <= 1000000.0f) ||
            !(block_data[8 + i] >= -1000000.0f && block_data[8 + i] <= 1000000.0f)) return -1;
    }
    for (int axis = 0; axis < 3; axis++) {
        if ((translated && (block_position[axis] < -1000000 || block_position[axis] > 1000000)) ||
            block_data[axis] > block_data[axis + 3] || block_data[8 + axis] > block_data[8 + axis + 3]) return -1;
    }
    if (!(block_data[24] >= 0.0f && block_data[24] <= 255.0f)) return -1;
    int flag = (int)block_data[24];
    if ((float)flag != block_data[24]) return -1;
    if ((flag & 1) != 0) return 0;
    float world_box[6];
    for (int axis = 0; axis < 3; axis++) {
        float offset = translated ? (float)block_position[axis] : 0.0f;
        world_box[axis] = block_data[axis] + offset;
        world_box[axis + 3] = block_data[axis + 3] + offset;
        /* Preserve branch semantics; boundary contact is excluded. */
        if (!(world_box[axis + 3] > block_data[8 + axis]) || world_box[axis] >= block_data[8 + axis + 3]) return 0;
    }
    for (int i = 0; i < 6; i++) block_data[16 + i] = world_box[i];
    block_data[25] = (float)flag;
    return 1;
}

int brazilpe_block_collect(int enabled) {
    if (enabled != 0 && enabled != 1) return -1;
    return enabled ? collect(1) : 0;
}

int brazilpe_thin_collect(int metadata) {
    if (!brazilpe_block_shape(1, metadata)) return -1;
    const float *local_shape = brazilpe_shape_values();
    for (int i = 0; i < 6; i++) block_data[i] = local_shape[i];
    block_data[24] = local_shape[6];
    /* 0x100606444 copies the local shape directly; unlike the base path,
     * it does not call the BlockPos translation helper. Preserve that behavior. */
    return collect(0);
}
