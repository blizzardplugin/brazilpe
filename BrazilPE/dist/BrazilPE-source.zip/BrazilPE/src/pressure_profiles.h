/* Generated from verified initializer/helper/constructor parameter flow. */
static const struct { int id, weighted, variant, capacity; } pressure_profiles[] = {
    {70, 0, 1, 1},
    {72, 0, 0, 1},
    {147, 1, 0, 15},
    {148, 1, 0, 150},
};
