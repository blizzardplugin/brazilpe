/* Sensor geometry 0x1006068ac, type matching 0x1004e94b4, and tick path
 * 0x100606584 -> 0x10060671c. Storage/queues receiving events remain external.
 * Flat candidate vectors model the observed client query, not chunk ownership. */
#include <stdint.h>
#include "pressure_profiles.h"
enum { candidate_limit = 64, coordinate_limit = 1000000 };
static int32_t position[3];
static float sensor[6], candidates[candidate_limit * 6];
static int32_t types[candidate_limit], events[8];
static int32_t profile_values[4];
extern int brazilpe_pressure_signal(int weighted, int count, int capacity);
extern int brazilpe_pressure_decode(int weighted, int metadata);
extern int brazilpe_pressure_encode(int weighted, int signal);
extern int brazilpe_pressure_delay(int weighted);
unsigned long brazilpe_pressure_position(void) { return (unsigned long)position; }
unsigned long brazilpe_pressure_sensor(void) { return (unsigned long)sensor; }
unsigned long brazilpe_pressure_candidates(void) { return (unsigned long)candidates; }
unsigned long brazilpe_pressure_types(void) { return (unsigned long)types; }
unsigned long brazilpe_pressure_events(void) { return (unsigned long)events; }
unsigned long brazilpe_pressure_profile_values(void) { return (unsigned long)profile_values; }
int brazilpe_pressure_profile(int id) {
    for (unsigned long i = 0; i < sizeof(pressure_profiles) / sizeof(pressure_profiles[0]); i++) {
        if (pressure_profiles[i].id != id) continue;
        profile_values[0] = pressure_profiles[i].weighted;
        profile_values[1] = pressure_profiles[i].variant;
        profile_values[2] = pressure_profiles[i].capacity;
        profile_values[3] = brazilpe_pressure_delay(pressure_profiles[i].weighted);
        return 1;
    }
    return 0;
}
int brazilpe_pressure_contact(int weighted, int metadata, int signal, int type, int remote) {
    if ((weighted != 0 && weighted != 1) || metadata < 0 || metadata > 15 || signal < 0 || signal > 15 ||
        type < 0 || type > 65535 || (remote != 0 && remote != 1)) return -1;
    return remote == 0 && type != 0x45 && brazilpe_pressure_decode(weighted, metadata) == 0 && signal > 0;
}
int brazilpe_entity_type_matches(int type, int selector) {
    if (type < 0 || type > 65535 || selector < 0 || selector > 65535) return -1;
    unsigned int mask = (unsigned int)selector & 0xffffff00U;
    if (mask != 0U && ((unsigned int)selector & 255U) == 0U)
        return ((unsigned int)type & mask) == mask;
    return type == selector;
}
int brazilpe_pressure_detect(int weighted, int variant, int count, int capacity) {
    if ((weighted != 0 && weighted != 1) || variant < 0 || variant > 2 ||
        count < 0 || count > candidate_limit || capacity < 1 || capacity > 4096) return -1;
    for (int axis = 0; axis < 3; axis++)
        if (position[axis] < -coordinate_limit || position[axis] > coordinate_limit) return -1;
    for (int i = 0; i < count; i++) {
        if (types[i] < 0 || types[i] > 65535) return -1;
        for (int axis = 0; axis < 3; axis++) {
            float low = candidates[i * 6 + axis], high = candidates[i * 6 + axis + 3];
            if (!(low >= -(float)coordinate_limit && high <= (float)coordinate_limit && low <= high)) return -1;
        }
    }
    for (int axis = 0; axis < 3; axis++) {
        float value = (float)position[axis];
        sensor[axis] = axis == 1 ? value : value + 0.0625f;
        sensor[axis + 3] = value + (axis == 1 ? 0.25f : 0.9375f);
    }
    int eligible = 0;
    for (int i = 0; i < count; i++) {
        if (types[i] == 0x45) continue;
        int selector = variant == 1 ? 0x100 : 0x13f;
        if (weighted == 0 && variant != 0 && !brazilpe_entity_type_matches(types[i], selector)) continue;
        int overlap = 1;
        for (int axis = 0; axis < 3; axis++)
            if (!(candidates[i * 6 + axis + 3] > sensor[axis]) ||
                candidates[i * 6 + axis] >= sensor[axis + 3]) overlap = 0;
        eligible += overlap;
    }
    return brazilpe_pressure_signal(weighted, eligible, capacity);
}
/* Events: 0 = count; 1..4 ordered kinds (component/write/sound/schedule);
 * 5 = encoded metadata; 6 = sound payload; 7 = scheduled tick delay.
 * remote corresponds to the world's original byte +0x1628: tick exits if bit 0 set. */
int brazilpe_pressure_tick(int weighted, int metadata, int signal, int remote) {
    if ((weighted != 0 && weighted != 1) || metadata < 0 || metadata > 15 ||
        signal < 0 || signal > 15 || (remote != 0 && remote != 1)) return -1;
    for (int i = 0; i < 8; i++) events[i] = 0;
    if (remote != 0) return 0;
    int old = brazilpe_pressure_decode(weighted, metadata), count = 0;
    events[++count] = 1;
    events[++count] = 2;
    events[5] = brazilpe_pressure_encode(weighted, signal);
    if ((old > 0) != (signal > 0)) {
        events[++count] = 3;
        events[6] = signal > 0 ? 600 : 500;
    }
    if (signal > 0) { events[++count] = 4; events[7] = brazilpe_pressure_delay(weighted); }
    events[0] = count;
    return 1;
}
