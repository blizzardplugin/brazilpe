#include "geometry_internal.h"

enum { MAX_OBSTACLES = 64, OBSTACLE_BASE = 32, OBSTACLE_STRIDE = 8 };
static float state[OBSTACLE_BASE + MAX_OBSTACLES * OBSTACLE_STRIDE];

unsigned long brazilpe_movement_buffer(void) { return (unsigned long)state; }

static int valid_number(float value) {
    /* The bounded adapter excludes overflow and non-finite native inputs. */
    return value >= -1000000.0f && value <= 1000000.0f;
}

int brazilpe_move(int count, int no_collision) {
    if (count < 0 || count > MAX_OBSTACLES || (no_collision != 0 && no_collision != 1)) return 0;
    for (int i = 0; i < 6; i++) if (!valid_number(state[i])) return 0;
    for (int axis = 0; axis < 3; axis++) {
        if (state[axis] > state[axis + 3] || !valid_number(state[8 + axis]) || !valid_number(state[12 + axis])) return 0;
    }
    if (state[24] != 0.0f && state[24] != 1.0f) return 0;
    for (int index = 0; index < count; index++) {
        const float *box = state + OBSTACLE_BASE + index * OBSTACLE_STRIDE;
        for (int i = 0; i < 6; i++) if (!valid_number(box[i])) return 0;
        for (int axis = 0; axis < 3; axis++) if (box[axis] > box[axis + 3]) return 0;
    }
    float allowed[3] = {state[12], state[13], state[14]};
    if (no_collision) {
        for (int axis = 0; axis < 3; axis++) {
            state[axis] = state[axis] + allowed[axis];
            state[axis + 3] = state[axis + 3] + allowed[axis];
        }
    } else {
        const int order[3] = {1, 0, 2};
        for (int step = 0; step < 3; step++) {
            int axis = order[step];
            for (int index = 0; index < count; index++) {
                allowed[axis] = brazilpe_clip_boxes(state + OBSTACLE_BASE + index * OBSTACLE_STRIDE,
                    state, axis, allowed[axis], 0);
            }
            /* The original calls the vector translator once per axis, including
             * zero components. Preserve those additions and their signed zeros. */
            for (int component = 0; component < 3; component++) {
                float delta = component == axis ? allowed[axis] : 0.0f;
                state[component] = delta + state[component];
                state[component + 3] = state[component + 3] + delta;
            }
        }
        state[24] = state[13] < 0.0f && state[13] != allowed[1] ? 1.0f : 0.0f;
        for (int axis = 0; axis < 3; axis++) {
            if (state[12 + axis] != allowed[axis]) state[8 + axis] = 0.0f;
        }
    }
    for (int axis = 0; axis < 3; axis++) {
        float width = state[axis + 3] - state[axis];
        /* FMADD multiplies a rounded float32 difference by 0.5 and adds min
         * with one rounding. Double intermediates reproduce that operation. */
        state[16 + axis] = (float)((double)width * 0.5 + (double)state[axis]);
        state[20 + axis] = allowed[axis];
    }
    return 1;
}
