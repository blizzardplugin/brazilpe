#ifndef BRAZILPE_BLOCK_SHAPES_INTERNAL_H
#define BRAZILPE_BLOCK_SHAPES_INTERNAL_H
int brazilpe_block_shape(int profile, int metadata);
const float *brazilpe_shape_values(void);
#endif
