/* Verified routine profiles; profile numbers are our API, not original block IDs.
 * Thin: 0x1006063b8. Variable height getter: 0x1006085f0.
 * The latter getter alone does not establish its class's collision behavior. */
#include "block_shapes_internal.h"
#include "registry_profiles.h"
static float shape[8];
unsigned long brazilpe_shape_buffer(void) { return (unsigned long)shape; }
const float *brazilpe_shape_values(void) { return shape; }
int brazilpe_block_shape(int profile, int metadata) {
    if (profile < 0 || profile > 2 || metadata < 0 || metadata > 255) return 0;
    shape[0] = 0.0f; shape[1] = 0.0f; shape[2] = 0.0f;
    shape[3] = 1.0f; shape[4] = 1.0f; shape[5] = 1.0f; shape[6] = 0.0f;
    if (profile == 1) {
        shape[0] = 0.0625f; shape[2] = 0.0625f;
        shape[3] = 0.9375f; shape[5] = 0.9375f;
        shape[4] = metadata == 0 ? 0.0625f : 0.03125f;
    } else if (profile == 2) {
        shape[4] = metadata >= 2 && metadata <= 5 ? 0.625f : 0.125f;
    }
    return 1;
}

int brazilpe_registered_shape(int identifier, int metadata) {
    for (unsigned long i = 0; i < sizeof(brazilpe_registry_profiles) / sizeof(brazilpe_registry_profiles[0]); i++) {
        if (brazilpe_registry_profiles[i].identifier == identifier)
            return brazilpe_block_shape(brazilpe_registry_profiles[i].profile, metadata);
    }
    return 0;
}
