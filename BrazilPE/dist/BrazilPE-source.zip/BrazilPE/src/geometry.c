/* Inferred AABB layout: min xyz at 0..8, max xyz at 12..20.
 * The source routines use strict face comparisons; contact is not overlap. */
#include "geometry_internal.h"
static float workspace[32];

unsigned long brazilpe_geometry_buffer(void) {
    return (unsigned long)workspace;
}

int brazilpe_aabb_intersects(void) {
    for (int axis = 0; axis < 3; axis++) {
        if (!(workspace[8 + axis + 3] > workspace[axis])) return 0;
        if (workspace[8 + axis] >= workspace[axis + 3]) return 0;
    }
    return 1;
}

int brazilpe_aabb_contains(void) {
    for (int axis = 0; axis < 3; axis++) {
        if (!(workspace[16 + axis] > workspace[axis])) return 0;
        if (workspace[16 + axis] >= workspace[axis + 3]) return 0;
    }
    return 1;
}

void brazilpe_aabb_translate(void) {
    int zero = 1;
    for (int axis = 0; axis < 3; axis++) {
        float minimum = workspace[axis] + workspace[16 + axis];
        float maximum = workspace[axis + 3] + workspace[16 + axis];
        workspace[24 + axis] = minimum;
        workspace[24 + axis + 3] = maximum;
        if (minimum != 0.0f || maximum != 0.0f) zero = 0;
    }
    workspace[30] = (float)zero;
}

float brazilpe_clip_boxes(const float *obstacle, const float *moving,
                         int axis, float desired, int mode) {
    for (int other = 0; other < 3; other++) {
        if (other == axis) continue;
        if (!(moving[other + 3] > obstacle[other])) return desired;
        if (moving[other] >= obstacle[other + 3]) return desired;
    }
    float positive_gap = obstacle[axis + 3] - moving[axis];
    if (!(positive_gap > 0.0f)) {
        float remainder = positive_gap - desired;
        return remainder > 0.0f ? positive_gap : desired;
    }
    float negative_gap = obstacle[axis] - moving[axis + 3];
    if (negative_gap >= 0.0f) {
        float remainder = negative_gap - desired;
        return remainder < 0.0f ? negative_gap : desired;
    }
    if ((mode & 1) != 0) return desired;
    /* In the finite input domain, this matches FMINNM followed by FCSEL. */
    float negative = negative_gap < 0.0f ? negative_gap : 0.0f;
    return positive_gap < -negative ? positive_gap : negative;
}

float brazilpe_clip_x(float desired, int mode) { return brazilpe_clip_boxes(workspace, workspace + 8, 0, desired, mode); }
float brazilpe_clip_y(float desired, int mode) { return brazilpe_clip_boxes(workspace, workspace + 8, 1, desired, mode); }
float brazilpe_clip_z(float desired, int mode) { return brazilpe_clip_boxes(workspace, workspace + 8, 2, desired, mode); }
