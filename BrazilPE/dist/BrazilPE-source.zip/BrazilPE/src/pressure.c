/* Signal stages only. Entity queries and redstone propagation are outside this API.
 * ARM64 0x10064d6c4 / 0x10065eb88 skip entity type 0x45 before counting.
 * eligible_count means the count AFTER query selection and that exclusion. */
enum { pressure_count_limit = 4096, pressure_signal_max = 15 };
int brazilpe_pressure_signal(int weighted, int eligible_count, int capacity) {
    if ((weighted != 0 && weighted != 1) || eligible_count < 0 ||
        eligible_count > pressure_count_limit || capacity < 1 || capacity > pressure_count_limit) return -1;
    if (weighted == 0) return eligible_count == 0 ? 0 : pressure_signal_max;
    int count = eligible_count < capacity ? eligible_count : capacity;
    if (count == 0) return 0;
    /* Preserve SCVTF -> FDIV -> FMUL -> FCVTPS; integer ceil division can differ. */
    float fraction = (float)count / (float)capacity;
    float scaled = fraction * (float)pressure_signal_max;
    int integral = (int)scaled;
    return (float)integral < scaled ? integral + 1 : integral;
}
int brazilpe_pressure_decode(int weighted, int metadata) {
    if ((weighted != 0 && weighted != 1) || metadata < 0 || metadata > 15) return -1;
    return weighted != 0 ? metadata : (metadata == 1 ? pressure_signal_max : 0);
}
int brazilpe_pressure_encode(int weighted, int signal) {
    if ((weighted != 0 && weighted != 1) || signal < 0 || signal > pressure_signal_max) return -1;
    return weighted != 0 ? signal : (signal > 0 ? 1 : 0);
}
int brazilpe_pressure_delay(int weighted) {
    if (weighted != 0 && weighted != 1) return -1;
    return weighted != 0 ? 10 : 20;
}
